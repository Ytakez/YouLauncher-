package com.youlauncher.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: LauncherViewModel) {
    val s = vm.settings
    val columns by s.columns.collectAsStateWithLifecycle()
    val iconSize by s.iconSize.collectAsStateWithLifecycle()
    val labels by s.showLabels.collectAsStateWithLifecycle()
    val themed by s.themedIcons.collectAsStateWithLifecycle()
    val dots by s.dots.collectAsStateWithLifecycle()
    val anim by s.animMode.collectAsStateWithLifecycle()

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.systemBars)
                .verticalScroll(rememberScrollState())
        ) {
            PageTopBar(stringResource(R.string.settings), onBack = vm::closeOverlay)

            SectionTitle(stringResource(R.string.home_screen))
            ChoiceRow(
                title = stringResource(R.string.columns),
                options = listOf(4, 5, 6).map { it to it.toString() },
                selected = columns,
                onSelect = s::setColumns
            )
            Column(Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) {
                Text("${stringResource(R.string.icon_size)}: $iconSize dp", style = MaterialTheme.typography.bodyLarge)
                Slider(
                    value = iconSize.toFloat(),
                    onValueChange = { s.setIconSize(it.roundToInt()) },
                    valueRange = 44f..72f
                )
            }
            SwitchRow(stringResource(R.string.show_labels), null, labels, s::setShowLabels)
            SwitchRow(stringResource(R.string.themed_icons), stringResource(R.string.themed_icons_hint), themed) {
                s.setThemedIcons(it)
            }

            SectionTitle(stringResource(R.string.animations))
            ChoiceRow(
                title = null,
                options = listOf(
                    AnimMode.AUTO to stringResource(R.string.anim_auto),
                    AnimMode.SYSTEM to stringResource(R.string.anim_system),
                    AnimMode.CUSTOM to stringResource(R.string.anim_custom),
                    AnimMode.OFF to stringResource(R.string.anim_off)
                ),
                selected = anim,
                onSelect = s::setAnimMode
            )
            Text(
                stringResource(R.string.anim_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
            )

            SectionTitle(stringResource(R.string.notifications))
            SwitchRow(stringResource(R.string.notif_dots), stringResource(R.string.notif_dots_hint), dots, s::setDots)
            TextButton(onClick = vm::openNotificationAccess, modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(stringResource(R.string.grant_access))
            }

            SectionTitle(stringResource(R.string.system))
            ActionRow(stringResource(R.string.widgets)) { vm.openOverlay(Overlay.WIDGETS) }
            ActionRow(stringResource(R.string.wallpaper), vm::openWallpaperPicker)
            ActionRow(stringResource(R.string.default_launcher), vm::openDefaultLauncherSettings)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 24.dp, bottom = 8.dp)
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun <T> ChoiceRow(
    title: String?,
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit
) {
    Column(Modifier.padding(horizontal = 24.dp, vertical = 4.dp)) {
        if (title != null) Text(title, style = MaterialTheme.typography.bodyLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (value, label) ->
                FilterChip(
                    selected = value == selected,
                    onClick = { onSelect(value) },
                    label = { Text(label) }
                )
            }
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ActionRow(title: String, onClick: () -> Unit) {
    Text(
        title,
        style = MaterialTheme.typography.bodyLarge,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 16.dp)
    )
}
