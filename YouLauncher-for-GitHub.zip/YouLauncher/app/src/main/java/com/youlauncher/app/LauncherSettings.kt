package com.youlauncher.app

import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

enum class AnimMode { AUTO, SYSTEM, CUSTOM, OFF }

class LauncherSettings(private val p: SharedPreferences) {
    val columns = MutableStateFlow(p.getInt("columns", 4))
    val iconSize = MutableStateFlow(p.getInt("iconSize", 56))
    val showLabels = MutableStateFlow(p.getBoolean("labels", true))
    val themedIcons = MutableStateFlow(p.getBoolean("themed", false))
    val dots = MutableStateFlow(p.getBoolean("dots", true))
    val animMode = MutableStateFlow(
        runCatching { AnimMode.valueOf(p.getString("anim", "AUTO") ?: "AUTO") }.getOrDefault(AnimMode.AUTO)
    )

    fun setColumns(v: Int) { columns.value = v; p.edit().putInt("columns", v).apply() }
    fun setIconSize(v: Int) { iconSize.value = v; p.edit().putInt("iconSize", v).apply() }
    fun setShowLabels(v: Boolean) { showLabels.value = v; p.edit().putBoolean("labels", v).apply() }
    fun setThemedIcons(v: Boolean) { themedIcons.value = v; p.edit().putBoolean("themed", v).apply() }
    fun setDots(v: Boolean) { dots.value = v; p.edit().putBoolean("dots", v).apply() }
    fun setAnimMode(v: AnimMode) { animMode.value = v; p.edit().putString("anim", v.name).apply() }
}
