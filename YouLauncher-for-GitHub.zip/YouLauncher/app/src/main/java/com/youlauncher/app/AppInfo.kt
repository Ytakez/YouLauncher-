package com.youlauncher.app

import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

/** key = flattened ComponentName ("pkg/Activity"). */
data class AppInfo(val label: String, val key: String) {
    val packageName: String get() = key.substringBefore('/')
}

object IconCache {
    private val cache = LruCache<String, ImageBitmap>(400)

    fun cacheKey(key: String, themed: Boolean, bg: Int, fg: Int, px: Int) =
        if (themed) "$key|t|$bg|$fg|$px" else "$key|n|$px"

    fun get(ck: String): ImageBitmap? = cache.get(ck)

    fun load(pm: PackageManager, key: String, themed: Boolean, bg: Int, fg: Int, px: Int): ImageBitmap? {
        val ck = cacheKey(key, themed, bg, fg, px)
        cache.get(ck)?.let { return it }
        return try {
            val cn = ComponentName.unflattenFromString(key) ?: return null
            var d = pm.getActivityIcon(cn)
            if (themed && Build.VERSION.SDK_INT >= 33 && d is AdaptiveIconDrawable) {
                val mono = d.monochrome
                if (mono != null) {
                    val m = mono.mutate()
                    m.setTint(fg)
                    d = AdaptiveIconDrawable(ColorDrawable(bg), m)
                }
            }
            val bmp = d.toBitmap(px, px).asImageBitmap()
            cache.put(ck, bmp)
            bmp
        } catch (e: Exception) {
            null
        }
    }
}
