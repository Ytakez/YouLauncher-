package com.youlauncher.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.roundToInt

/**
 * Built-in app-launch animation, used when the system animations are disabled
 * (or when the user forces it in settings). The tapped icon grows into a rounded
 * surface that fills the screen, the app is started on top of it, and when the
 * user comes back the surface collapses again.
 */
@Composable
fun LaunchOverlay(vm: LauncherViewModel) {
    val anim by vm.launchAnim.collectAsStateWithLifecycle()
    val themed by vm.settings.themedIcons.collectAsStateWithLifecycle()
    val progress = remember { Animatable(0f) }
    var last by remember { mutableStateOf<LaunchAnim?>(null) }

    LaunchedEffect(anim?.id) {
        val a = anim
        if (a != null) {
            last = a
            progress.snapTo(0f)
            progress.animateTo(1f, tween(durationMillis = 300, easing = FastOutSlowInEasing))
            vm.commitLaunch(a)
        } else {
            progress.animateTo(0f, tween(durationMillis = 240, easing = FastOutSlowInEasing))
        }
    }

    val a = last ?: return
    val p = progress.value.coerceIn(0f, 1f)
    if (p <= 0.001f) return

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val wPx = with(density) { maxWidth.toPx() }
        val hPx = with(density) { maxHeight.toPx() }
        val l = lerp(a.rect.left, 0f, p)
        val t = lerp(a.rect.top, 0f, p)
        val r = lerp(a.rect.right, wPx, p)
        val b = lerp(a.rect.bottom, hPx, p)
        val icon = rememberAppIcon(a.key, themed, 56.dp)

        Box(
            Modifier
                .offset { IntOffset(l.roundToInt(), t.roundToInt()) }
                .size(with(density) { (r - l).toDp() }, with(density) { (b - t).toDp() })
                .clip(RoundedCornerShape(lerp(22f, 0f, p).dp))
                .background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center
        ) {
            icon?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    modifier = Modifier
                        .size(56.dp)
                        .graphicsLayer {
                            val s = 1f + p * 0.5f
                            scaleX = s
                            scaleY = s
                            alpha = (1f - p * 1.5f).coerceIn(0f, 1f)
                        }
                )
            }
        }
    }
}
