package com.youlauncher.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.IntOffset
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {

    private val vm: LauncherViewModel by viewModels()
    private var pendingWidgetId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            YouLauncherTheme {
                LauncherRoot(vm, onAddWidget = ::beginAddWidget)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        try { vm.widgets.host.startListening() } catch (_: Exception) {}
    }

    override fun onStop() {
        try { vm.widgets.host.stopListening() } catch (_: Exception) {}
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        vm.refreshApps()
        vm.endLaunch() // we are back from an app: collapse the custom launch animation
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            vm.closeDrawer()
            vm.closeOverlay()
        }
    }

    // ---------- widgets: bind -> configure -> commit ----------
    private fun beginAddWidget(info: AppWidgetProviderInfo) {
        val host = vm.widgets.host
        val mgr = vm.widgets.manager
        val id = host.allocateAppWidgetId()
        pendingWidgetId = id
        if (mgr.bindAppWidgetIdIfAllowed(id, info.provider)) {
            configureOrCommit(id)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_BIND)
        }
    }

    private fun configureOrCommit(id: Int) {
        val info = vm.widgets.manager.getAppWidgetInfo(id)
        if (info?.configure != null) {
            vm.widgets.host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
        } else {
            finishAdd(id)
        }
    }

    private fun finishAdd(id: Int) {
        vm.widgets.commit(id)
        vm.closeOverlay()
        pendingWidgetId = -1
    }

    private fun cancelAdd() {
        if (pendingWidgetId != -1) {
            try { vm.widgets.host.deleteAppWidgetId(pendingWidgetId) } catch (_: Exception) {}
        }
        pendingWidgetId = -1
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val id = pendingWidgetId
        if (id == -1) return
        when (requestCode) {
            REQ_BIND -> if (resultCode == RESULT_OK) configureOrCommit(id) else cancelAdd()
            REQ_CONFIG -> if (resultCode == RESULT_OK) finishAdd(id) else cancelAdd()
        }
    }

    private companion object {
        const val REQ_BIND = 4101
        const val REQ_CONFIG = 4102
    }
}

@Composable
fun LauncherRoot(vm: LauncherViewModel, onAddWidget: (AppWidgetProviderInfo) -> Unit) {
    val open by vm.drawerOpen.collectAsStateWithLifecycle()
    val overlay by vm.overlay.collectAsStateWithLifecycle()

    BackHandler(enabled = overlay != null) { vm.closeOverlay() }
    BackHandler(enabled = open && overlay == null) { vm.closeDrawer() }

    Box(Modifier.fillMaxSize()) {
        HomeScreen(vm)

        AnimatedVisibility(
            visible = open,
            enter = slideInVertically(spring<IntOffset>(dampingRatio = 0.8f, stiffness = 400f)) { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) { AppDrawer(vm) }

        AnimatedVisibility(
            visible = overlay == Overlay.SETTINGS,
            enter = slideInVertically(spring<IntOffset>(dampingRatio = 0.85f, stiffness = 500f)) { it / 8 } + fadeIn(),
            exit = slideOutVertically { it / 8 } + fadeOut()
        ) { SettingsScreen(vm) }

        AnimatedVisibility(
            visible = overlay == Overlay.WIDGETS,
            enter = slideInVertically(spring<IntOffset>(dampingRatio = 0.85f, stiffness = 500f)) { it / 8 } + fadeIn(),
            exit = slideOutVertically { it / 8 } + fadeOut()
        ) { WidgetsScreen(vm, onAddWidget) }

        LaunchOverlay(vm)
    }
}
