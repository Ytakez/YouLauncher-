package com.youlauncher.app

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.appwidget.AppWidgetHostView
import kotlin.math.hypot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Widget view that reports a long-press on the widget itself. This replaces the old "three dots"
 * button that was drawn on top of every widget and covered e.g. the Google search bar.
 */
class LongPressHostView(context: Context) : AppWidgetHostView(context) {
    var onLongPress: (() -> Unit)? = null
    private var fired = false
    private var downX = 0f
    private var downY = 0f
    private val handler = Handler(Looper.getMainLooper())
    private val task = Runnable {
        fired = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        onLongPress?.invoke()
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                fired = false
                downX = ev.x; downY = ev.y
                handler.postDelayed(task, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE ->
                if (hypot(ev.x - downX, ev.y - downY) > ViewConfiguration.get(context).scaledTouchSlop) handler.removeCallbacks(task)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(task)
        }
        return fired || super.onInterceptTouchEvent(ev)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (fired) {
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                handler.removeCallbacks(task)
            }
            return true
        }
        return super.onTouchEvent(ev)
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(task)
        super.onDetachedFromWindow()
    }
}

class WidgetController(private val ctx: Context, private val prefs: SharedPreferences) {
    val host: AppWidgetHost = object : AppWidgetHost(ctx, 1024) {
        override fun onCreateView(context: Context, appWidgetId: Int, appWidget: AppWidgetProviderInfo?): AppWidgetHostView =
            LongPressHostView(context)
    }
    val manager: AppWidgetManager = AppWidgetManager.getInstance(ctx)

    private val _ids = MutableStateFlow(read())
    val ids: StateFlow<List<Int>> = _ids.asStateFlow()

    private fun read(): List<Int> =
        (prefs.getString("widgets", "") ?: "").split("|").mapNotNull { it.toIntOrNull() }

    private val _bottom = MutableStateFlow(readBottom())
    /** Widgets placed under the dock (the spot of the removed search bar). */
    val bottomIds: StateFlow<List<Int>> = _bottom.asStateFlow()

    private fun readBottom(): List<Int> =
        (prefs.getString("widgetsBottom", "") ?: "").split("|").mapNotNull { it.toIntOrNull() }

    private fun save() {
        prefs.edit()
            .putString("widgets", _ids.value.joinToString("|"))
            .putString("widgetsBottom", _bottom.value.joinToString("|"))
            .apply()
    }

    fun moveTo(id: Int, bottom: Boolean) {
        if (bottom) {
            _ids.value = _ids.value - id
            if (id !in _bottom.value) _bottom.value = _bottom.value + id
        } else {
            _bottom.value = _bottom.value - id
            if (id !in _ids.value) _ids.value = _ids.value + id
        }
        save()
    }

    fun commit(id: Int) {
        if (id !in _ids.value) {
            _ids.value = _ids.value + id
            save()
        }
    }

    fun remove(id: Int) {
        try { host.deleteAppWidgetId(id) } catch (_: Exception) {}
        _ids.value = _ids.value - id
        _bottom.value = _bottom.value - id
        save()
    }

    fun providers(): List<AppWidgetProviderInfo> =
        try { manager.installedProviders } catch (e: Exception) { emptyList() }

    @Suppress("DEPRECATION")
    fun label(info: AppWidgetProviderInfo): String =
        if (Build.VERSION.SDK_INT >= 30) info.loadLabel(ctx.packageManager) else (info.label ?: "")
}
