package com.youlauncher.app

import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

/** CUSTOM = built-in Material You animation (works on any phone). Old "AUTO" values fall back to CUSTOM. */
enum class AnimMode { CUSTOM, SYSTEM, OFF }

/** App theme: follow the system, or force light / dark. */
/** MATERIAL = Material You colors. BLUR = minimal frosted-glass look (iOS-like). LIQUID = Liquid Glass: everything drawn as lit glass (iOS 26-like). */
enum class LauncherTheme { MATERIAL, BLUR, LIQUID }

/** Look of the app launch animation. */
enum class AnimStyle { MORPH, ZOOM, FADE }

/** One whole-number setting kept in prefs; [flow] is observed by the UI. */
class IntSetting(private val p: SharedPreferences, private val key: String, val def: Int) {
    val flow = MutableStateFlow(p.getInt(key, def))
    fun set(v: Int) { flow.value = v; p.edit().putInt(key, v).apply() }
}

class BoolSetting(private val p: SharedPreferences, private val key: String, val def: Boolean) {
    val flow = MutableStateFlow(p.getBoolean(key, def))
    fun set(v: Boolean) { flow.value = v; p.edit().putBoolean(key, v).apply() }
}

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Accent color of the launcher UI. SYSTEM = Material You colors from the wallpaper (Android 12+). */
enum class AccentOption(val hue: Float, val labelRes: Int) {
    SYSTEM(-1f, R.string.accent_system),
    BLUE(215f, R.string.accent_blue),
    TEAL(175f, R.string.accent_teal),
    MINT(152f, R.string.accent_mint),
    SKY(200f, R.string.accent_sky),
    GREEN(125f, R.string.accent_green),
    YELLOW(48f, R.string.accent_yellow),
    RED(5f, R.string.accent_red),
    PINK(330f, R.string.accent_pink),
    PURPLE(272f, R.string.accent_purple),
    LAVENDER(255f, R.string.accent_lavender),
    PEACH(22f, R.string.accent_peach)
}

class LauncherSettings(private val p: SharedPreferences) {
    val columns = MutableStateFlow(p.getInt("columns", 5))
    val iconSize = MutableStateFlow(p.getInt("iconSize", 56))
    val showLabels = MutableStateFlow(p.getBoolean("labels", true))
    /**
     * Icon recolor palette. Default is ORIGINAL (app's own colors) so a fresh install never
     * starts with repainted icons. Old "themed = true" without a palette migrates to THEME.
     */
    val iconPalette = MutableStateFlow(
        p.getString("iconPalette", null)?.let { n -> runCatching { IconPalette.valueOf(n) }.getOrNull() }
            ?: if (p.contains("themed") && p.getBoolean("themed", false)) IconPalette.THEME
            else IconPalette.ORIGINAL
    )
    /** True only when a recolor palette is active — never on first launch with ORIGINAL. */
    val themedIcons = MutableStateFlow(iconPalette.value != IconPalette.ORIGINAL)
    /** Tonal Material 3 container behind home screen widgets. */
    val widgetCards = MutableStateFlow(p.getBoolean("widgetCards", true))
    val dots = MutableStateFlow(p.getBoolean("dots", true))
    val animMode = MutableStateFlow(
        runCatching { AnimMode.valueOf(p.getString("anim", "CUSTOM") ?: "CUSTOM") }.getOrDefault(AnimMode.CUSTOM)
    )
    /** true = app list (drawer) with letters; false = no drawer, every app lives on the home screen. */
    val drawerEnabled = MutableStateFlow(p.getBoolean("drawerOn", true))
    val showDate = MutableStateFlow(p.getBoolean("showDate", false))
    val homeClock = MutableStateFlow(
        runCatching { HomeClockStyle.valueOf(p.getString("homeClock", "FLOWER") ?: "FLOWER") }.getOrDefault(HomeClockStyle.FLOWER)
    )
    val showSearch = MutableStateFlow(p.getBoolean("showSearch", true))
    val blurAnim = MutableStateFlow(p.getBoolean("blurAnim", true))
    /** Launch / close animation tuning (ported from Expressive Launcher). */
    val animSpeed = MutableStateFlow(p.getFloat("animSpeed", 1f))      // 0.6..1.6
    val animBounce = MutableStateFlow(p.getFloat("animBounce", 1f))    // 0..1.5, 0 = no overshoot
    val animStyle = MutableStateFlow(
        runCatching { AnimStyle.valueOf(p.getString("animStyle", "MORPH") ?: "MORPH") }.getOrDefault(AnimStyle.MORPH)
    )
    val launcherTheme = MutableStateFlow(
        runCatching { LauncherTheme.valueOf(p.getString("launcherTheme", "MATERIAL") ?: "MATERIAL") }.getOrDefault(LauncherTheme.MATERIAL)
    )
    val blurStrength = IntSetting(p, "blurStrength", 60)    // blur of the wallpaper behind the app list and settings
    val glassAlpha = IntSetting(p, "glassAlpha", 55)        // how see-through the app list is, % opaque
    val blurIosShape = BoolSetting(p, "blurIosShape", true) // iOS squircle icons in the blur theme
    val liquidFill = IntSetting(p, "liquidFill", 16)         // Liquid Glass: how milky the glass is, %
    val liquidFringe = BoolSetting(p, "liquidFringe", true)  // Liquid Glass: rainbow light fringe on the edges
    val clockDx = IntSetting(p, "clockDx", 0)                // Liquid Glass home clock: where it was moved, dp from its normal place
    val clockDy = IntSetting(p, "clockDy", 0)
    val animDepth = IntSetting(p, "animDepth", 8)          // how far the home screen sinks back, %
    val pressScale = IntSetting(p, "pressScale", 86)       // icon size while pressed, %
    val labelAlpha = IntSetting(p, "labelAlpha", 100)      // opacity of app names, %
    val dockAlpha = IntSetting(p, "dockAlpha", 18)         // dock panel opacity, %
    val dockCorner = IntSetting(p, "dockCorner", 32)       // dock panel corner radius, dp
    val dockLabels = BoolSetting(p, "dockLabels", false)   // names under dock icons
    val searchHeight = IntSetting(p, "searchHeight", 56)   // search pill height, dp
    val searchAlpha = IntSetting(p, "searchAlpha", 94)     // search pill opacity, %
    val searchRound = IntSetting(p, "searchRound", 50)     // search pill corners, 0 = square, 50 = capsule
    val drawerAlpha = IntSetting(p, "drawerAlpha", 97)     // app list background opacity, %
    val drawerCorner = IntSetting(p, "drawerCorner", 32)   // app list top corners, dp
    val iconShape = MutableStateFlow(
        runCatching { IconShapeOption.valueOf(p.getString("shape", "CIRCLE") ?: "CIRCLE") }
            .getOrDefault(IconShapeOption.CIRCLE)
    )

    val customShape = MutableStateFlow(p.getString("customShape", "") ?: "")  // drawn icon shape: x,y;x,y… in ‰
    val customFont = MutableStateFlow(p.getString("customFont", "") ?: "")    // "" = system, else imported font file
    init { CustomShapeStore.raw = customShape.value }

    val labelSize = MutableStateFlow(p.getInt("labelSize", 1))          // 0 small, 1 normal, 2 large
    val folderAlpha = MutableStateFlow(p.getInt("folderAlpha", 22))    // folder tile opacity, %
    val dim = MutableStateFlow(p.getInt("dim", 0))                     // wallpaper darkening, %
    val pageDots = MutableStateFlow(p.getBoolean("pageDots", true))
    val dockBg = MutableStateFlow(p.getBoolean("dockBg", false))
    val drawerCols = MutableStateFlow(p.getInt("drawerCols", 0))       // 0 = same as home
    val themeMode = MutableStateFlow(
        runCatching { ThemeMode.valueOf(p.getString("themeMode", "SYSTEM") ?: "SYSTEM") }.getOrDefault(ThemeMode.SYSTEM)
    )
    val accent = MutableStateFlow(
        runCatching { AccentOption.valueOf(p.getString("accent", "SYSTEM") ?: "SYSTEM") }.getOrDefault(AccentOption.SYSTEM)
    )

    fun setLabelSize(v: Int) { labelSize.value = v; p.edit().putInt("labelSize", v).apply() }
    fun setFolderAlpha(v: Int) { folderAlpha.value = v; p.edit().putInt("folderAlpha", v).apply() }
    fun setDim(v: Int) { dim.value = v; p.edit().putInt("dim", v).apply() }
    fun setPageDots(v: Boolean) { pageDots.value = v; p.edit().putBoolean("pageDots", v).apply() }
    fun setDockBg(v: Boolean) { dockBg.value = v; p.edit().putBoolean("dockBg", v).apply() }
    fun setDrawerCols(v: Int) { drawerCols.value = v; p.edit().putInt("drawerCols", v).apply() }
    fun setThemeMode(v: ThemeMode) { themeMode.value = v; p.edit().putString("themeMode", v.name).apply() }
    fun setAccent(v: AccentOption) { accent.value = v; p.edit().putString("accent", v.name).apply() }

    fun setColumns(v: Int) { columns.value = v; p.edit().putInt("columns", v).apply() }
    fun setIconSize(v: Int) { iconSize.value = v; p.edit().putInt("iconSize", v).apply() }
    fun setShowLabels(v: Boolean) { showLabels.value = v; p.edit().putBoolean("labels", v).apply() }
    fun setThemedIcons(v: Boolean) {
        // Keep palette in sync: themed on → THEME, off → ORIGINAL (never leave themed=true with ORIGINAL)
        setIconPalette(if (v) IconPalette.THEME else IconPalette.ORIGINAL)
    }
    fun setIconPalette(v: IconPalette) {
        iconPalette.value = v
        themedIcons.value = v != IconPalette.ORIGINAL
        p.edit().putString("iconPalette", v.name).putBoolean("themed", v != IconPalette.ORIGINAL).apply()
    }
    fun setWidgetCards(v: Boolean) { widgetCards.value = v; p.edit().putBoolean("widgetCards", v).apply() }
    fun setDots(v: Boolean) { dots.value = v; p.edit().putBoolean("dots", v).apply() }
    fun setAnimMode(v: AnimMode) { animMode.value = v; p.edit().putString("anim", v.name).apply() }
    fun setHomeClock(v: HomeClockStyle) { homeClock.value = v; p.edit().putString("homeClock", v.name).apply() }
    fun setDrawerEnabled(v: Boolean) { drawerEnabled.value = v; p.edit().putBoolean("drawerOn", v).apply() }
    fun setShowDate(v: Boolean) { showDate.value = v; p.edit().putBoolean("showDate", v).apply() }
    fun setShowSearch(v: Boolean) { showSearch.value = v; p.edit().putBoolean("showSearch", v).apply() }
    fun setAnimSpeed(v: Float) { animSpeed.value = v; p.edit().putFloat("animSpeed", v).apply() }
    fun setAnimBounce(v: Float) { animBounce.value = v; p.edit().putFloat("animBounce", v).apply() }
    fun setLauncherTheme(v: LauncherTheme) { launcherTheme.value = v; p.edit().putString("launcherTheme", v.name).apply() }
    fun setAnimStyle(v: AnimStyle) { animStyle.value = v; p.edit().putString("animStyle", v.name).apply() }
    fun resetAnimation() {
        setAnimSpeed(1f); setAnimBounce(1f); setAnimStyle(AnimStyle.MORPH); animDepth.set(animDepth.def); setBlurAnim(true)
    }
    fun resetLook() {
        listOf(pressScale, labelAlpha, dockAlpha, dockCorner, searchHeight, searchAlpha, searchRound, drawerAlpha, drawerCorner)
            .forEach { it.set(it.def) }
        dockLabels.set(dockLabels.def)
    }
    fun setBlurAnim(v: Boolean) { blurAnim.value = v; p.edit().putBoolean("blurAnim", v).apply() }
    fun setIconShape(v: IconShapeOption) { iconShape.value = v; p.edit().putString("shape", v.name).apply() }
    fun setCustomShape(v: String) { customShape.value = v; CustomShapeStore.raw = v; p.edit().putString("customShape", v).apply() }
    fun setCustomFont(v: String) { customFont.value = v; p.edit().putString("customFont", v).apply() }
    fun resetClockPos() { clockDx.set(0); clockDy.set(0) }

    // ---------- lock screen / always-on display ----------
    private inline fun <reified E : Enum<E>> readEnum(key: String, def: E): E =
        runCatching { enumValueOf<E>(p.getString(key, def.name) ?: def.name) }.getOrDefault(def)

    val lockEnabled = MutableStateFlow(p.getBoolean("lockOn", false))
    val lockClock = MutableStateFlow(readEnum("lockClock", LockClockStyle.STACKED))
    val lockWeight = MutableStateFlow(p.getInt("lockWeight", 4))              // 0..4, thin..black
    val lockColor = MutableStateFlow(readEnum("lockColor", LockColor.WHITE))
    val lockShape = MutableStateFlow(p.getBoolean("lockShape", true))         // photo cut out in a blob
    val lockWall = MutableStateFlow(p.getString("lockWall", "") ?: "")        // "", built-in id or "gallery@..."
    val lockLeft = MutableStateFlow(readEnum("lockLeft", LockShortcut.TORCH))
    val lockRight = MutableStateFlow(readEnum("lockRight", LockShortcut.CAMERA))
    val lockNotifOn = MutableStateFlow(p.getBoolean("lockNotifOn", true))
    val lockNotifLayout = MutableStateFlow(readEnum("lockNotifLayout", LockNotifLayout.COMPACT))
    val lockHideText = MutableStateFlow(p.getBoolean("lockHideText", false))
    val lockDepth = MutableStateFlow(p.getBoolean("lockDepth", false))      // clock goes behind the subject of the photo
    val lockSwipe = MutableStateFlow(p.getBoolean("lockSwipe", true))       // swipe up to unlock
    val lockClockSize = IntSetting(p, "lockClockSize", 100)       // clock size, %
    val lockClockStretch = IntSetting(p, "lockClockStretch", 100) // extra stretch of the clock in height, %
    val lockClockBlur = IntSetting(p, "lockClockBlur", 0)         // soft blur of the clock, 0 = off
    val lockClockPlate = BoolSetting(p, "lockClockPlate", false)  // frosted glass plate behind the clock
    val lockClockCenter = BoolSetting(p, "lockClockCenter", false) // clock in the middle of the screen
    val aodEnabled = MutableStateFlow(p.getBoolean("aodOn", false))
    val aodDuration = MutableStateFlow(readEnum("aodDuration", AodDuration.S60))
    val aodNotif = MutableStateFlow(p.getBoolean("aodNotif", true))

    fun setLockEnabled(v: Boolean) { lockEnabled.value = v; p.edit().putBoolean("lockOn", v).apply() }
    fun setLockClock(v: LockClockStyle) { lockClock.value = v; p.edit().putString("lockClock", v.name).apply() }
    fun setLockWeight(v: Int) { lockWeight.value = v; p.edit().putInt("lockWeight", v).apply() }
    fun setLockColor(v: LockColor) { lockColor.value = v; p.edit().putString("lockColor", v.name).apply() }
    fun setLockShape(v: Boolean) { lockShape.value = v; p.edit().putBoolean("lockShape", v).apply() }
    fun setLockWall(v: String) { lockWall.value = v; p.edit().putString("lockWall", v).apply() }
    fun setLockLeft(v: LockShortcut) { lockLeft.value = v; p.edit().putString("lockLeft", v.name).apply() }
    fun setLockRight(v: LockShortcut) { lockRight.value = v; p.edit().putString("lockRight", v.name).apply() }
    fun setLockNotifOn(v: Boolean) { lockNotifOn.value = v; p.edit().putBoolean("lockNotifOn", v).apply() }
    fun setLockNotifLayout(v: LockNotifLayout) { lockNotifLayout.value = v; p.edit().putString("lockNotifLayout", v.name).apply() }
    fun setLockHideText(v: Boolean) { lockHideText.value = v; p.edit().putBoolean("lockHideText", v).apply() }
    fun setLockDepth(v: Boolean) { lockDepth.value = v; p.edit().putBoolean("lockDepth", v).apply() }
    fun setLockSwipe(v: Boolean) { lockSwipe.value = v; p.edit().putBoolean("lockSwipe", v).apply() }
    fun setAodEnabled(v: Boolean) { aodEnabled.value = v; p.edit().putBoolean("aodOn", v).apply() }
    fun setAodDuration(v: AodDuration) { aodDuration.value = v; p.edit().putString("aodDuration", v.name).apply() }
    fun setAodNotif(v: Boolean) { aodNotif.value = v; p.edit().putBoolean("aodNotif", v).apply() }
}
