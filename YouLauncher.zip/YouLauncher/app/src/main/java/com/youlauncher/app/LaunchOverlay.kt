package com.youlauncher.app

import android.graphics.Bitmap
import android.graphics.Matrix as AndroidMatrix
import android.graphics.Path as AndroidPath
import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.graphics.shapes.toPath
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Share of the way at which the app is actually started: the card already almost fills the screen. */
private const val LAUNCH_AT = 0.85f
/** Part of the path on which the icon shape becomes the rounded rectangle of the window. */
private const val MORPH_END = 0.25f
/** How much the icon grows on its own before it starts turning into the window. */
private const val GROW = 0.14f
/** Icon squash on the spring overshoot at the end of closing (progress below zero): the bounce. */
private const val DIP = 2.5f

private fun smooth(from: Float, to: Float, x: Float): Float {
    val k = ((x - from) / (to - from)).coerceIn(0f, 1f)
    return k * k * (3f - 2f * k)
}

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t

private fun averageColor(img: ImageBitmap): Color? = runCatching {
    val px = Bitmap.createScaledBitmap(img.asAndroidBitmap(), 1, 1, true).getPixel(0, 0)
    Color(px).copy(alpha = 1f)
}.getOrNull()

private class PortalTools {
    val path = AndroidPath()
    val iconPath = AndroidPath()
    val tmp = AndroidPath()
    val matrix = AndroidMatrix()
    val composePath = path.asComposePath()
    val composeIconPath = iconPath.asComposePath()
}

/**
 * Launch / close animation (ported from Expressive Launcher): the tapped icon first grows a little,
 * then its shape MORPHS into a rounded window that fills the screen, the colour of the icon turns into
 * the surface colour and the icon fades out. All of it is driven by one spring ([progress]), so speed and
 * bounciness are settings, and an interrupted animation continues smoothly from the current position.
 *
 * Open: the app starts when the card almost fills the screen ([LAUNCH_AT]).
 * Close: the window springs back into the icon (with a small bounce); if the app was started from the
 * app list, the window shrinks to the centre and fades instead (the icon is not on screen any more).
 *
 * [progress] is hoisted so the home screen can sink back / dim in sync.
 */
@Composable
fun LaunchOverlay(vm: LauncherViewModel, progress: Animatable<Float, AnimationVector1D>) {
    val anim by vm.launchAnim.collectAsStateWithLifecycle()
    val themed by vm.settings.themedIcons.collectAsStateWithLifecycle()
    val blurOn by vm.settings.blurAnim.collectAsStateWithLifecycle()
    val speed by vm.settings.animSpeed.collectAsStateWithLifecycle()
    val bounce by vm.settings.animBounce.collectAsStateWithLifecycle()
    val style by vm.settings.animStyle.collectAsStateWithLifecycle()
    var last by remember { mutableStateOf<LaunchAnim?>(null) }
    var toCenter by remember { mutableStateOf(false) }

    LaunchedEffect(anim?.id) {
        val a = anim
        val k = speed * speed
        if (a != null) {
            last = a
            toCenter = false
            progress.snapTo(0f)
            var started = false
            progress.animateTo(
                1f,
                spring(dampingRatio = tunedDamping(0.78f, bounce), stiffness = 300f * k, visibilityThreshold = 0.0005f)
            ) {
                if (!started && value >= LAUNCH_AT) {
                    started = true
                    vm.commitLaunch(a)
                }
            }
            if (!started) vm.commitLaunch(a)
        } else {
            // Change the target only when the window is almost full-screen: a jump mid-way would be visible
            toCenter = false // the drawer stays open, so the icon is still there to fly back into
            progress.animateTo(
                0f,
                spring(dampingRatio = tunedDamping(0.72f, bounce), stiffness = 280f * k, visibilityThreshold = 0.0005f)
            )
        }
    }

    val a = last ?: return
    if (anim == null && abs(progress.value) < 0.002f) return

    val surface = MaterialTheme.colorScheme.surface.copy(alpha = 1f)
    val fallback = MaterialTheme.colorScheme.primaryContainer
    val density = LocalDensity.current
    val view = LocalView.current
    val iconDp = with(density) { a.rect.width.toDp() }
    val icon = rememberAppIcon(a.key, themed, iconDp)
    val accent = remember(icon) { icon?.let { averageColor(it) } } ?: fallback
    val iconTargetPx = with(density) { 112.dp.toPx() }
    // The final card repeats the display's corner radius; if the system does not report it, use a phone-like one
    val cornerPx = remember(view, density) {
        val display = if (Build.VERSION.SDK_INT >= 31) {
            view.rootWindowInsets?.getRoundedCorner(android.view.RoundedCorner.POSITION_TOP_LEFT)?.radius?.toFloat()
        } else null
        val min = with(density) { 16.dp.toPx() }
        display?.takeIf { it >= min } ?: with(density) { 36.dp.toPx() }
    }
    val tools = remember { PortalTools() }
    val morph = remember(a.shape) { ShapeMorphs.window(a.shape) }
    val iconPolygon = remember(a.shape) { ShapeMorphs.polygon(a.shape) }

    Canvas(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                // soft, frosted middle of the motion (Android 12+)
                if (blurOn && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val br = (sin(progress.value.coerceIn(0f, 1f) * PI.toFloat()) * 8f * this.density).coerceAtLeast(0f)
                    renderEffect = if (br > 0.5f) BlurEffect(br, br, TileMode.Decal) else null
                }
            }
    ) {
        val p = progress.value
        val alpha = if (toCenter) smooth(0f, 0.35f, p) else 1f
        if (alpha <= 0f) return@Canvas
        if (style == AnimStyle.FADE) {
            // no movement: the surface just fades in over the screen and the icon dissolves into it
            val f = smooth(0f, 1f, p)
            drawRect(lerp(accent, surface, smooth(0.2f, 0.8f, p)), alpha = smooth(0f, 0.6f, p) * alpha)
            val img = icon ?: return@Canvas
            val ia = (1f - f * 2f).coerceIn(0f, 1f) * alpha
            if (ia > 0f) {
                val sz = a.rect.width * (1f + 0.6f * f)
                val c = a.rect.center
                val tl = Offset(c.x - sz / 2f, c.y - sz / 2f)
                tools.iconPath.rewind()
                tools.tmp.rewind()
                iconPolygon.toPath(tools.tmp)
                tools.matrix.reset()
                tools.matrix.setScale(sz, sz)
                tools.matrix.postTranslate(tl.x, tl.y)
                tools.tmp.transform(tools.matrix, tools.iconPath)
                clipPath(tools.composeIconPath) {
                    drawImage(
                        img,
                        dstOffset = IntOffset(tl.x.toInt(), tl.y.toInt()),
                        dstSize = IntSize(sz.toInt(), sz.toInt()),
                        alpha = ia,
                        filterQuality = FilterQuality.Medium
                    )
                }
            }
            return@Canvas
        }
        val anchor = if (toCenter) Rect(Offset(size.width / 2f, size.height / 2f), a.rect.width / 2f) else a.rect

        // 1. The icon grows a little on its own; on the overshoot at the end of closing it squashes (bounce)
        val grow = if (p >= 0f) 1f + GROW * smooth(0f, 0.25f, p) else (1f + p * DIP).coerceAtLeast(0.6f)
        val halfW = anchor.width / 2f * grow
        val halfH = anchor.height / 2f * grow
        val cx = anchor.center.x
        val cy = anchor.center.y

        // 2. Then position and size flow into the window; the power > 1 keeps the start behind the growth
        val m = ((p - 0.06f) / 0.94f).coerceIn(0f, 1.03f).pow(1.35f)
        val left = lerpF(cx - halfW, 0f, m)
        val top = lerpF(cy - halfH, 0f, m)
        val right = lerpF(cx + halfW, size.width, m)
        val bottom = lerpF(cy + halfH, size.height, m)
        val w = right - left
        val h = bottom - top
        if (w <= 0f || h <= 0f) return@Canvas

        // The colour of the icon turns into the surface the app window will appear on
        val container = lerp(accent, surface, smooth(0.2f, 0.8f, m))
        tools.path.rewind()
        if (style == AnimStyle.MORPH && m < MORPH_END) {
            morph.toPath(smooth(0f, 1f, m / MORPH_END), tools.path)
            tools.matrix.reset()
            tools.matrix.setScale(w, h)
            tools.matrix.postTranslate(left, top)
            tools.path.transform(tools.matrix)
        } else {
            // the window corner smoothly goes to the display corner: no sudden switch to a rectangle
            val kk = if (style == AnimStyle.MORPH) smooth(0f, 1f, (m - MORPH_END) / (1f - MORPH_END)) else smooth(0f, 1f, m)
            val rx = lerpF(w * ShapeMorphs.WINDOW_CORNER, cornerPx, kk)
            val ry = lerpF(h * ShapeMorphs.WINDOW_CORNER, cornerPx, kk)
            tools.path.addRoundRect(left, top, right, bottom, rx, ry, AndroidPath.Direction.CW)
        }
        drawPath(tools.composePath, container, alpha = alpha)

        // 3. The icon inside grows with the window and fades out; the same formula opens and closes
        val iconAlpha = (1f - smooth(0.2f, 0.6f, m)) * alpha
        val image = icon ?: return@Canvas
        if (iconAlpha <= 0f) return@Canvas
        val iconSize = min(min(w, h), lerpF(anchor.width * grow, iconTargetPx, smooth(0f, 1f, m)))
        val topLeft = Offset((left + right) / 2f - iconSize / 2f, (top + bottom) / 2f - iconSize / 2f)
        tools.iconPath.rewind()
        tools.tmp.rewind()
        iconPolygon.toPath(tools.tmp)
        tools.matrix.reset()
        tools.matrix.setScale(iconSize, iconSize)
        tools.matrix.postTranslate(topLeft.x, topLeft.y)
        tools.tmp.transform(tools.matrix, tools.iconPath)
        clipPath(tools.composeIconPath) {
            drawImage(
                image,
                srcOffset = IntOffset.Zero,
                srcSize = IntSize(image.width, image.height),
                dstOffset = IntOffset(topLeft.x.toInt(), topLeft.y.toInt()),
                dstSize = IntSize(iconSize.toInt(), iconSize.toInt()),
                alpha = iconAlpha,
                filterQuality = FilterQuality.Medium
            )
        }
    }
}
