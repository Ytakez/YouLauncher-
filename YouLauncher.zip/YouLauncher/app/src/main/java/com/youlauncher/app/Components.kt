package com.youlauncher.app
import androidx.compose.animation.core.tween

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

data class MenuAction(val label: String, val onClick: () -> Unit)

// ---------------- icons ----------------
@Composable
fun rememberAppIcon(key: String, themed: Boolean, size: Dp): ImageBitmap? {
    val pm = LocalContext.current.packageManager
    val density = LocalDensity.current.density
    val palette = LocalIconPalette.current
    val scheme = MaterialTheme.colorScheme
    val dark = scheme.surface.luminance() < 0.5f
    // Palette is the source of truth: ORIGINAL never recolors, even if the old themed flag is true
    val recolor = themed && palette != IconPalette.ORIGINAL
    val pair = if (recolor) palette.colorsFor(key, dark) else null
    val bg = pair?.first ?: scheme.secondaryContainer.toArgb()
    val fg = pair?.second ?: scheme.onSecondaryContainer.toArgb()
    val px = (size.value * density).roundToInt().coerceAtLeast(96)
    val ck = IconCache.cacheKey(key, recolor, bg, fg, px, dark)
    return produceState(IconCache.get(ck), ck) {
        if (value == null) value = withContext(Dispatchers.Default) { IconCache.load(pm, key, recolor, bg, fg, px, dark) }
    }.value
}

/** Long-press menu: app shortcuts + extra actions + info + uninstall. */
@Composable
fun rememberMenu(vm: LauncherViewModel, app: AppInfo, extra: List<MenuAction>): () -> List<MenuAction> {
    val info = stringResource(R.string.app_info)
    val uninstall = stringResource(R.string.uninstall)
    val customize = stringResource(R.string.customize_icon)
    return {
        vm.shortcutActions(app.packageName) + extra +
            MenuAction(customize) { vm.openAppStyle(app) } +
            MenuAction(info) { vm.openAppInfo(app.packageName) } +
            MenuAction(uninstall) { vm.uninstall(app.packageName) }
    }
}

@Composable
fun rememberLauncher(vm: LauncherViewModel): (String, Rect?) -> Unit {
    val view = LocalView.current
    return remember(vm, view) { { key: String, rect: Rect? -> vm.launch(key, rect, view) } }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(
    app: AppInfo,
    labelColor: Color,
    menu: () -> List<MenuAction>,
    onLaunch: (Rect) -> Unit,
    modifier: Modifier = Modifier,
    iconSize: Dp = 56.dp,
    themed: Boolean = false,
    showLabel: Boolean = true,
    labelShadow: Boolean = false,
    dot: Boolean = false,
    longPressEnabled: Boolean = true,
    onDragStart: (() -> Unit)? = null,
    onDragBy: (Offset) -> Unit = {},
    onDragEnd: () -> Unit = {}
) {
    var menuOpen by remember { mutableStateOf(false) }
    var items by remember { mutableStateOf(emptyList<MenuAction>()) }
    val bounds = remember { arrayOf(Rect.Zero) }
    val haptics = LocalHapticFeedback.current
    val icon = rememberAppIcon(app.key, themed, iconSize * maxOf(AppStyles.of(app.key)?.scale ?: 1f, 1f))
    val style = AppStyles.of(app.key)
    val iconShape = style?.shape?.toShape() ?: LocalIconShape.current
    val iconScale = style?.scale ?: 1f
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val isLiquid = LocalLiquid.current.on
    val glowAnim by animateFloatAsState(if (pressed && isLiquid) 1f else 0f, tween(160), label = "iconGlow")
    // Expressive-style bouncy press feedback
    val scale by animateFloatAsState(
        targetValue = if (pressed) LocalPressScale.current else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "iconScale"
    )

    val suppressClick = remember { booleanArrayOf(false) }
    val menuState = rememberUpdatedState(menu)
    val launchState = rememberUpdatedState(onLaunch)
    val startState = rememberUpdatedState(onDragStart)
    val byState = rememberUpdatedState(onDragBy)
    val endState = rememberUpdatedState(onDragEnd)
    LaunchedEffect(pressed) { if (pressed) suppressClick[0] = false }

    // Drag enabled (home grid): long-press + move = rearrange, long-press + release = menu.
    // Otherwise (drawer, dock): classic click / long-click menu.
    val gestures = if (onDragStart != null) {
        Modifier
            .clickable(interactionSource = interaction, indication = null) {
                if (suppressClick[0]) suppressClick[0] = false else launchState.value(bounds[0])
            }
            .pointerInput(Unit) {
                var dist = 0f
                detectDragGesturesAfterLongPress(
                    onDragStart = {
                        dist = 0f
                        suppressClick[0] = true
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        startState.value?.invoke()
                    },
                    onDrag = { change, amount ->
                        change.consume()
                        dist += amount.getDistance()
                        byState.value(amount)
                    },
                    onDragEnd = {
                        endState.value()
                        if (dist <= 16f) {
                            items = menuState.value()
                            menuOpen = true
                        }
                    },
                    onDragCancel = { endState.value() }
                )
            }
    } else {
        Modifier.combinedClickable(
            interactionSource = interaction,
            indication = null,
            onClick = { onLaunch(bounds[0]) },
            onLongClick = if (longPressEnabled) {
                {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    items = menu()
                    menuOpen = true
                }
            } else null
        )
    }

    Box(modifier) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .then(gestures)
                .padding(vertical = 8.dp, horizontal = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(iconSize), contentAlignment = Alignment.Center) {
              Box(
                Modifier
                    .size(iconSize * iconScale)
                    .onGloballyPositioned { bounds[0] = it.boundsInWindow() }
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .then(if (isLiquid) Modifier.liquidIcon(iconShape) { glowAnim } else Modifier)
              ) {
                icon?.let { Image(bitmap = it, contentDescription = app.label, modifier = Modifier.fillMaxSize().clip(iconShape)) }
                if (dot) {
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .size(11.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                }
              }
            }
            if (showLabel && style?.hideLabel != true) {
                Spacer(Modifier.height(4.dp))
                val base = MaterialTheme.typography.labelMedium.let { it.copy(fontSize = it.fontSize * LocalLabelScale.current) }
                Text(
                    text = style?.label ?: app.label,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = labelColor.copy(alpha = labelColor.alpha * LocalLabelAlpha.current),
                    style = if (labelShadow) base.copy(
                        shadow = Shadow(Color.Black.copy(alpha = 0.55f), Offset(0f, 2f), 6f)
                    ) else base
                )
            }
        }
        if (menuOpen) {
            val a = bounds[0]
            FloatingMenu(
                cx = a.center.x.toInt(), top = a.top.toInt(), bottom = a.bottom.toInt(),
                onDismiss = { menuOpen = false }
            ) { dismiss ->
                items.forEach { item -> FloatingMenuRow(item.label) { dismiss(); item.onClick() } }
            }
        }
    }
}

// ---------------- gestures ----------------
/** Swipe up / down on a plain area (dock, search pill). */
@Composable
fun Modifier.verticalSwipe(onUp: () -> Unit, onDown: () -> Unit): Modifier {
    var sum by remember { mutableFloatStateOf(0f) }
    val up by rememberUpdatedState(onUp)
    val down by rememberUpdatedState(onDown)
    return this.draggable(
        state = rememberDraggableState { sum += it },
        orientation = Orientation.Vertical,
        onDragStarted = { sum = 0f },
        onDragStopped = { v ->
            if (sum < -100f || v < -1400f) up() else if (sum > 100f || v > 1400f) down()
        }
    )
}

/** Fires when a scrollable is over-scrolled past its start/end (nothing left to consume). */
@Composable
fun rememberSwipeConnection(onUp: () -> Unit, onDown: () -> Unit): NestedScrollConnection {
    val up by rememberUpdatedState(onUp)
    val down by rememberUpdatedState(onDown)
    return remember {
        object : NestedScrollConnection {
            var sum = 0f
            var coolDownUntil = 0L
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (source != NestedScrollSource.UserInput) return Offset.Zero
                val now = System.currentTimeMillis()
                if (now < coolDownUntil) return Offset.Zero
                sum += available.y
                if (sum < -140f) { sum = 0f; coolDownUntil = now + 700; up() }
                else if (sum > 140f) { sum = 0f; coolDownUntil = now + 700; down() }
                return Offset.Zero
            }
        }
    }
}

// ---------------- shared bits for full-screen pages ----------------
@Composable
fun PageTopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = stringResource(R.string.back))
        }
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(start = 8.dp))
    }
}
