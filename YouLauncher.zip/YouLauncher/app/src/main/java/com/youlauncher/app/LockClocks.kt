package com.youlauncher.app

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.layout
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import kotlin.math.min
import kotlin.math.roundToInt
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

private val WEIGHTS = intArrayOf(200, 350, 500, 700, 900)
private fun weightOf(i: Int) = FontWeight(WEIGHTS[i.coerceIn(0, 4)])

/** Current time, refreshed on the second (lock screen) or on the minute (always-on display). */
@Composable
fun rememberNow(everySecond: Boolean): LocalDateTime {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(everySecond) {
        while (true) {
            now = LocalDateTime.now()
            val step = if (everySecond) 1000L else 60_000L
            delay(step - (System.currentTimeMillis() % step) + 5L)
        }
    }
    return now
}

/** One piece of clock text that can be a filled glyph, an outline, or a mix of both (used for the lock -> AOD morph). */
@Composable
private fun Glyph(
    text: String,
    size: TextUnit,
    weight: FontWeight,
    color: Color,
    fill: Float,
    stroke: Float,
    strokeDp: Float = 2.5f
) {
    val strokePx = with(LocalDensity.current) { strokeDp.dp.toPx() }
    val base = TextStyle(
        fontSize = size,
        fontWeight = weight,
        fontFamily = FontFamily.SansSerif,
        lineHeight = size * 0.9f,
        fontFeatureSettings = "tnum"
    )
    Box {
        if (fill > 0.01f) {
            Text(text, style = base.copy(color = color.copy(alpha = color.alpha * fill)))
        }
        if (stroke > 0.01f) {
            Text(
                text,
                style = base.copy(
                    color = color.copy(alpha = color.alpha * stroke),
                    drawStyle = Stroke(width = strokePx, join = StrokeJoin.Round)
                )
            )
        }
    }
}

/** A digit that rolls to the next one when the time changes. */
@Composable
private fun RollingDigit(ch: Char, size: TextUnit, weight: FontWeight, color: Color, fill: Float, stroke: Float) {
    AnimatedContent(
        targetState = ch,
        transitionSpec = {
            ((slideInVertically(tween<IntOffset>(380)) { -it / 2 } + fadeIn(tween(300))) togetherWith
                (slideOutVertically(tween<IntOffset>(380)) { it / 2 } + fadeOut(tween(220)))) using
                SizeTransform(clip = false)
        },
        label = "digit"
    ) { c -> Glyph(c.toString(), size, weight, color, fill, stroke) }
}

private fun Modifier.vertical(): Modifier = this
    .layout { measurable, constraints ->
        val p = measurable.measure(constraints)
        layout(p.height, p.width) {
            p.place(
                x = -(p.width / 2 - p.height / 2),
                y = -(p.height / 2 - p.width / 2)
            )
        }
    }
    .rotate(-90f)

/**
 * The clock itself. [aod] goes 0 -> 1 when the screen switches to the always-on display:
 * filled digits turn into outlines.
 */
@Composable
fun LockClock(
    style: LockClockStyle,
    weight: Int,
    color: LockColor,
    time: LocalDateTime,
    is24: Boolean,
    dateText: String,
    aod: Float,
    modifier: Modifier = Modifier
) {
    AnimatedContent(
        targetState = style,
        modifier = modifier,
        transitionSpec = {
            (fadeIn(tween(380)) + scaleIn(tween<Float>(380), initialScale = 0.88f)) togetherWith
                (fadeOut(tween(200)) + scaleOut(tween<Float>(260), targetScale = 1.08f)) using
                SizeTransform(clip = false)
        },
        label = "clockStyle"
    ) { st ->
        val h = if (is24) time.hour else (time.hour % 12).let { if (it == 0) 12 else it }
        val hh = String.format(Locale.ROOT, "%02d", h)
        val mm = String.format(Locale.ROOT, "%02d", time.minute)
        val w = weightOf(weight)
        val a = color.clock
        val b = color.clock.copy(alpha = color.clock.alpha * 0.42f)
        val fill = 1f - aod
        when (st) {
            LockClockStyle.STACKED -> Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy((-20).dp)
            ) {
                val sz = 132.sp
                Row(horizontalArrangement = Arrangement.spacedBy((-6).dp)) {
                    RollingDigit(hh[0], sz, w, a, fill, aod)
                    RollingDigit(hh[1], sz, w, b, fill, aod)
                }
                Row(horizontalArrangement = Arrangement.spacedBy((-6).dp)) {
                    RollingDigit(mm[0], sz, w, b, fill, aod)
                    RollingDigit(mm[1], sz, w, a, fill, aod)
                }
            }

            LockClockStyle.NUMERALS -> Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
                val hourAngle = Math.toRadians(((time.hour % 12) + time.minute / 60.0) * 30.0 - 90.0)
                val minAngle = Math.toRadians(time.minute * 6.0 - 90.0)
                Canvas(Modifier.size(250.dp)) {
                    val c = center
                    val r = size.minDimension / 2f
                    val handAlpha = 1f - 0.35f * aod
                    drawLine(
                        a.copy(alpha = a.alpha * handAlpha), c,
                        Offset(c.x + (r * 0.42f * cos(hourAngle)).toFloat(), c.y + (r * 0.42f * sin(hourAngle)).toFloat()),
                        strokeWidth = 10.dp.toPx(), cap = StrokeCap.Round
                    )
                    drawLine(
                        b.copy(alpha = (b.alpha * 1.6f).coerceAtMost(1f) * handAlpha), c,
                        Offset(c.x + (r * 0.66f * cos(minAngle)).toFloat(), c.y + (r * 0.66f * sin(minAngle)).toFloat()),
                        strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round
                    )
                }
                val sz = 62.sp
                Box(Modifier.align(Alignment.TopCenter)) { Glyph("12", sz, w, a, fill, aod) }
                Box(Modifier.align(Alignment.CenterEnd)) { Glyph("3", sz, w, b, fill, aod) }
                Box(Modifier.align(Alignment.BottomCenter)) { Glyph("6", sz, w, a, fill, aod) }
                Box(Modifier.align(Alignment.CenterStart)) { Glyph("9", sz, w, b, fill, aod) }
            }

            LockClockStyle.DIGITAL -> Row(verticalAlignment = Alignment.CenterVertically) {
                val sz = 76.sp
                RollingDigit(hh[0], sz, w, a, fill, aod)
                RollingDigit(hh[1], sz, w, a, fill, aod)
                val colon = if (aod > 0.5f || time.second % 2 == 0) 1f else 0.3f
                Glyph(":", sz, w, a.copy(alpha = colon), fill, aod)
                RollingDigit(mm[0], sz, w, a, fill, aod)
                RollingDigit(mm[1], sz, w, a, fill, aod)
                Spacer(Modifier.width(14.dp))
                Column {
                    Glyph(dateText, 15.sp, FontWeight.Medium, a, 1f, 0f)
                }
            }

            LockClockStyle.OUTLINE -> Row(verticalAlignment = Alignment.CenterVertically) {
                val sz = 84.sp
                val glass = 0.22f * fill
                Row(horizontalArrangement = Arrangement.spacedBy((-2).dp)) {
                    RollingDigit(hh[0], sz, w, a, glass, 1f)
                    RollingDigit(hh[1], sz, w, a, glass, 1f)
                    RollingDigit(mm[0], sz, w, a, glass, 1f)
                    RollingDigit(mm[1], sz, w, a, glass, 1f)
                }
                Spacer(Modifier.width(14.dp))
                Glyph(dateText, 15.sp, FontWeight.Medium, a, 1f, 0f)
            }

            LockClockStyle.VERTICAL -> Column {
                Glyph("$hh $mm", 44.sp, w, a, fill, aod)
                Spacer(Modifier.size(8.dp))
                Box(Modifier.vertical()) {
                    Glyph(dateText.uppercase(Locale.getDefault()), 38.sp, FontWeight.Bold, a, fill, aod)
                }
            }
        }
    }
}

/**
 * Makes the clock bigger and taller (iOS-style clock resize) and keeps it FULLY on screen:
 * the scale is capped so the clock never gets wider than its slot or taller than [maxHeight].
 * [size] and [stretch] are factors (1 = normal); the height is scaled by size * stretch.
 */
fun Modifier.stretchFit(size: Float, stretch: Float, maxHeight: Dp): Modifier = this.layout { measurable, constraints ->
    val p = measurable.measure(Constraints())
    val maxW = if (constraints.hasBoundedWidth) constraints.maxWidth else Int.MAX_VALUE
    val maxH = maxHeight.roundToPx()
    val sx = min(size, maxW / p.width.toFloat().coerceAtLeast(1f))
    val sy = min(size * stretch, maxH / p.height.toFloat().coerceAtLeast(1f))
    val w = (p.width * sx).roundToInt()
    val h = (p.height * sy).roundToInt()
    layout(w, h) {
        p.placeWithLayer(0, 0) {
            scaleX = sx
            scaleY = sy
            transformOrigin = TransformOrigin(0f, 0f)
        }
    }
}
