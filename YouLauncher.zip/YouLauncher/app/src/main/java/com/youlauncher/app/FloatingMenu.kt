package com.youlauncher.app
import androidx.compose.ui.graphics.Color

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import kotlinx.coroutines.launch

/**
 * Long-press menu ported from Material Launcher: it grows out of the tapped icon (scale + fade on a spring),
 * shrinks back on close, and changes height smoothly when items arrive later.
 * [content] receives a dismiss function: call it before running an item so the menu animates out.
 */
@Composable
fun FloatingMenu(
    cx: Int, top: Int, bottom: Int, onDismiss: () -> Unit,
    content: @Composable ColumnScope.(dismiss: () -> Unit) -> Unit
) {
    val scope = rememberCoroutineScope()
    val p = remember { Animatable(0f) }
    var originX by remember { mutableFloatStateOf(0.5f) }
    var originY by remember { mutableFloatStateOf(1f) }
    var closing by remember { mutableStateOf(false) }
    val dismiss: () -> Unit = {
        if (!closing) {
            closing = true
            scope.launch {
                p.animateTo(0f, tween(130, easing = FastOutLinearInEasing))
                onDismiss()
            }
        }
    }
    LaunchedEffect(Unit) { p.animateTo(1f, spring(dampingRatio = 0.9f, stiffness = 700f)) }
    val provider = remember(cx, top, bottom) {
        object : PopupPositionProvider {
            override fun calculatePosition(
                anchorBounds: IntRect, windowSize: IntSize,
                layoutDirection: LayoutDirection, popupContentSize: IntSize
            ): IntOffset {
                val m = 24
                val x = (cx - popupContentSize.width / 2)
                    .coerceIn(m, (windowSize.width - popupContentSize.width - m).coerceAtLeast(m))
                var y = top - popupContentSize.height - 12
                val above = y >= m
                if (!above) y = bottom + 12
                y = y.coerceIn(m, (windowSize.height - popupContentSize.height - m).coerceAtLeast(m))
                // grow from the icon: from the bottom edge if the menu sits above it, from the top edge if below
                originX = ((cx - x).toFloat() / popupContentSize.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                originY = if (above) 1f else 0f
                return IntOffset(x, y)
            }
        }
    }
    Popup(
        popupPositionProvider = provider,
        onDismissRequest = dismiss,
        properties = PopupProperties(focusable = true)
    ) {
        val liquidOn = LocalLiquid.current.on
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = if (liquidOn) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerHigh,
            shadowElevation = if (liquidOn) 0.dp else 10.dp,
            modifier = Modifier
                .graphicsLayer {
                    val v = p.value
                    alpha = v.coerceIn(0f, 1f)
                    val sc = (0.8f + 0.2f * v).coerceAtMost(1f)
                    scaleX = sc
                    scaleY = sc
                    transformOrigin = TransformOrigin(originX, originY)
                }
                .then(if (liquidOn) Modifier.liquidPanel(RoundedCornerShape(28.dp), shadow = false) else Modifier)
        ) {
            Column(
                Modifier.width(264.dp).animateContentSize(spring(dampingRatio = 1f, stiffness = 500f)).padding(8.dp)
            ) { content(dismiss) }
        }
    }
}

@Composable
fun FloatingMenuRow(text: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}
