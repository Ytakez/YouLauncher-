package com.youlauncher.app

import android.text.format.DateFormat
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------------------------
// Home clock in Liquid Glass: a glass plate with glass digits, picked up and moved like an iOS widget.
// ---------------------------------------------------------------------------------------------

@Composable
private fun GlassDigits(text: String) {
    val base = MaterialTheme.typography.displayLarge.copy(
        fontSize = 72.sp,
        lineHeight = 78.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = (-1.5).sp
    )
    Box {
        // smoky body with a soft shadow so the digits stay readable on a light wallpaper
        BasicText(
            text,
            style = base.copy(
                color = Color.Black.copy(alpha = 0.16f),
                shadow = Shadow(Color.Black.copy(alpha = 0.28f), Offset(0f, 5f), 16f)
            )
        )
        // milky glass: bright at the top, clearer at the bottom
        BasicText(
            text,
            style = base.copy(
                brush = Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.95f), Color.White.copy(alpha = 0.55f))
                )
            )
        )
        // specular edge of the glyphs
        BasicText(
            text,
            style = base.copy(
                brush = Brush.linearGradient(
                    listOf(Color.White, Color.White.copy(alpha = 0.25f), Color.White.copy(alpha = 0.9f))
                ),
                drawStyle = Stroke(width = 3f)
            )
        )
    }
}

@Composable
private fun GlassLabel(text: String) {
    BasicText(
        text,
        style = MaterialTheme.typography.titleMedium.copy(
            color = Color.White.copy(alpha = 0.92f),
            fontWeight = FontWeight.SemiBold,
            shadow = Shadow(Color.Black.copy(alpha = 0.35f), Offset(0f, 2f), 8f)
        )
    )
}

@Composable
private fun GlassBattery(level: Int, charging: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(width = 22.dp, height = 11.dp)) {
            val tip = 2.dp.toPx()
            val body = size.width - tip
            val line = 1.4.dp.toPx()
            drawRoundRect(
                Color.White.copy(alpha = 0.85f),
                size = Size(body, size.height),
                cornerRadius = CornerRadius(3.dp.toPx()),
                style = Stroke(line)
            )
            drawRoundRect(
                Color.White.copy(alpha = 0.85f),
                topLeft = Offset(body + 0.5.dp.toPx(), size.height * 0.3f),
                size = Size(1.5.dp.toPx(), size.height * 0.4f),
                cornerRadius = CornerRadius(1.dp.toPx())
            )
            val pad = 2.dp.toPx()
            val fillW = (body - pad * 2f) * (level.coerceIn(0, 100) / 100f)
            drawRoundRect(
                if (charging) Color(0xFF7CFFB2) else Color.White.copy(alpha = 0.85f),
                topLeft = Offset(pad, pad),
                size = Size(fillW.coerceAtLeast(1f), size.height - pad * 2f),
                cornerRadius = CornerRadius(1.5.dp.toPx())
            )
        }
        Spacer(Modifier.width(6.dp))
        GlassLabel("$level%")
    }
}

/** The clock itself. [glow] (0..1) lights the glass up while it is held. */
@Composable
fun LiquidClock(glow: () -> Float = { 0f }) {
    val ctx = LocalContext.current
    val liquid = LocalLiquid.current
    val is24 = remember { DateFormat.is24HourFormat(ctx) }
    val now = rememberNow(everySecond = false)
    val battery = rememberBattery()
    val hour = if (is24) "%02d".format(now.hour) else (if (now.hour % 12 == 0) 12 else now.hour % 12).toString()
    val time = hour + ":" + "%02d".format(now.minute)
    val day = now.toLocalDate()
    val date = remember(day) { DateTimeFormatter.ofPattern("EEE, d MMM", Locale.getDefault()).format(day) }
    Column(
        Modifier
            .liquidGlass(RoundedCornerShape(40.dp), fill = liquid.fill, glow = glow, fringe = liquid.fringe)
            .padding(horizontal = 30.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        GlassDigits(time)
        Row(
            Modifier.padding(vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassLabel(date)
            GlassBattery(battery.level, battery.charging)
        }
    }
}

/**
 * The clock the way iOS treats a widget: tap opens the clock app, hold to pick it up (it lights up, gets bigger and
 * stretches like jelly in the direction of the finger), drag anywhere, let go and it springs into place.
 * Hold without moving opens a small menu. The place is stored as dp offsets from the normal place.
 *
 * [originPx] is where the clock normally sits inside the page (left and top, px); [pageW]/[pageH] is the page size.
 */
@Composable
fun LiquidClockHost(
    dxDp: Int,
    dyDp: Int,
    pageW: Float,
    pageH: Float,
    originPx: Float,
    onMoved: (Int, Int) -> Unit,
    onSize: (IntSize) -> Unit,
    onTap: () -> Unit,
    onRemove: () -> Unit,
    onReset: () -> Unit,
    onHeld: (Boolean) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val d = LocalDensity.current.density
    val scope = rememberCoroutineScope()
    val haptics = LocalHapticFeedback.current
    var offX by remember { mutableFloatStateOf(dxDp * d) }
    var offY by remember { mutableFloatStateOf(dyDp * d) }
    var sx by remember { mutableFloatStateOf(0f) }    // jelly stretch along x (negative = squashed)
    var sy by remember { mutableFloatStateOf(0f) }    // jelly stretch along y
    var lift by remember { mutableFloatStateOf(0f) }  // 0 = lying on the screen, 1 = held up by the finger
    var box by remember { mutableStateOf(IntSize.Zero) }
    var menu by remember { mutableStateOf(false) }
    val coords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    val release = remember { arrayOfNulls<Job>(1) }
    val inMotion = remember { booleanArrayOf(false) }
    val tapCb by rememberUpdatedState(onTap)
    val movedCb by rememberUpdatedState(onMoved)
    val heldCb by rememberUpdatedState(onHeld)
    val pw by rememberUpdatedState(pageW)
    val ph by rememberUpdatedState(pageH)
    val origin by rememberUpdatedState(originPx)

    // the place was changed from outside (reset in the menu or in settings): glide there
    LaunchedEffect(dxDp, dyDp) {
        val tx = dxDp * d
        val ty = dyDp * d
        if (!inMotion[0] && (abs(tx - offX) > 0.5f || abs(ty - offY) > 0.5f)) {
            launch { animate(offX, tx, animationSpec = spring(0.72f, 320f)) { v, _ -> offX = v } }
            animate(offY, ty, animationSpec = spring(0.72f, 320f)) { v, _ -> offY = v }
        }
    }

    val margin = 8f * d
    fun clampX(v: Float): Float {
        val lo = margin - origin
        val hi = (pw - box.width - margin - origin).coerceAtLeast(lo)
        return v.coerceIn(lo, hi)
    }
    fun clampY(v: Float): Float {
        val lo = margin - origin
        val hi = (ph - box.height - 44f * d - origin).coerceAtLeast(lo)
        return v.coerceIn(lo, hi)
    }

    Box(
        modifier
            .graphicsLayer {
                translationX = offX
                translationY = offY
                val s = 1f + 0.06f * lift
                scaleX = s * (1f + sx - 0.45f * sy)
                scaleY = s * (1f + sy - 0.45f * sx)
            }
            .onSizeChanged { box = it; onSize(it) }
            .onGloballyPositioned { coords[0] = it }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    var tapped = false
                    val timedOut = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                        var go = true
                        while (go) {
                            val ev = awaitPointerEvent()
                            val c = ev.changes.firstOrNull { it.id == down.id }
                            if (c == null || c.isConsumed) {
                                go = false
                            } else if (!c.pressed) {
                                tapped = true
                                go = false
                            } else if ((c.position - down.position).getDistance() > viewConfiguration.touchSlop) {
                                go = false
                            }
                        }
                    } == null
                    if (!timedOut) {
                        if (tapped) tapCb()
                        return@awaitEachGesture
                    }

                    // held: pick the clock up
                    release[0]?.cancel()
                    inMotion[0] = true
                    heldCb(true)
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    scope.launch { animate(lift, 1f, animationSpec = spring(0.6f, 500f)) { v, _ -> lift = v } }
                    var travelled = 0f
                    var vx = 0f
                    var vy = 0f
                    while (true) {
                        val ev = awaitPointerEvent()
                        val c = ev.changes.firstOrNull { it.id == down.id }
                        ev.changes.forEach { it.consume() }
                        if (c == null || !c.pressed) break
                        // previousPosition is mapped into the same (moving) coordinates, so the difference is the real finger move
                        val delta = c.position - c.previousPosition
                        travelled += abs(delta.x) + abs(delta.y)
                        offX += delta.x
                        offY += delta.y
                        vx = vx * 0.7f + delta.x * 0.3f
                        vy = vy * 0.7f + delta.y * 0.3f
                        sx = (abs(vx) * 0.008f).coerceAtMost(0.16f)
                        sy = (abs(vy) * 0.008f).coerceAtMost(0.16f)
                    }

                    // let go: spring into the nearest allowed place, jelly wobble, put down
                    val tx = clampX(offX)
                    val ty = clampY(offY)
                    val startX = offX
                    val startY = offY
                    val startSx = sx
                    val startSy = sy
                    val startLift = lift
                    release[0] = scope.launch {
                        launch { animate(startSx, 0f, animationSpec = spring(0.28f, 240f)) { v, _ -> sx = v } }
                        launch { animate(startSy, 0f, animationSpec = spring(0.28f, 240f)) { v, _ -> sy = v } }
                        launch { animate(startLift, 0f, animationSpec = spring(0.7f, 300f)) { v, _ -> lift = v } }
                        launch { animate(startX, tx, animationSpec = spring(0.62f, 380f)) { v, _ -> offX = v } }
                        animate(startY, ty, animationSpec = spring(0.62f, 380f)) { v, _ -> offY = v }
                        inMotion[0] = false
                        movedCb((tx / d).roundToInt(), (ty / d).roundToInt())
                        heldCb(false)
                    }
                    if (travelled < 12f) menu = true
                }
            }
    ) {
        LiquidClock(glow = { lift })
        if (menu) {
            val a = coords[0]?.takeIf { it.isAttached }?.boundsInWindow() ?: Rect.Zero
            FloatingMenu(
                cx = a.center.x.toInt(), top = a.top.toInt(), bottom = a.bottom.toInt(),
                onDismiss = { menu = false }
            ) { dismiss ->
                if (dxDp != 0 || dyDp != 0) {
                    FloatingMenuRow(stringResource(R.string.clock_reset)) { dismiss(); onReset() }
                }
                FloatingMenuRow(stringResource(R.string.remove)) { dismiss(); onRemove() }
            }
        }
    }
}
