package com.youlauncher.app

import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialShapes
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.graphics.shapes.CornerRounding
import androidx.graphics.shapes.Morph
import androidx.graphics.shapes.RoundedPolygon
import androidx.graphics.shapes.rectangle
import androidx.graphics.shapes.toPath
import java.util.concurrent.ConcurrentHashMap

/** 0 = no overshoot at all, 1 = the original springiness. */
fun tunedDamping(damping: Float, bounce: Float): Float = (1f - (1f - damping) * bounce).coerceIn(0.3f, 1f)

private fun unitRect(rounding: Float): RoundedPolygon =
    RoundedPolygon.rectangle(width = 2f, height = 2f, rounding = CornerRounding(rounding)).normalized()

/** iOS-like icon mask: rounded square with continuous curvature. */
private val ContinuousSquircle: RoundedPolygon by lazy {
    RoundedPolygon.rectangle(width = 2f, height = 2f, rounding = CornerRounding(0.47f, smoothing = 0.62f)).normalized()
}

/** Icon shape as a polygon in the 0..1 square: the open animation morphs from it. */
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
fun IconShapeOption.polygon(): RoundedPolygon = rawPolygon().normalized()

/** Not every MaterialShapes version returns polygons in the 0..1 square, so [polygon] normalizes them. */
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
private fun IconShapeOption.rawPolygon(): RoundedPolygon = when (this) {
    IconShapeOption.CIRCLE -> MaterialShapes.Circle
    IconShapeOption.SQUIRCLE -> unitRect(0.68f)
    IconShapeOption.ROUNDED -> unitRect(0.6f)
    IconShapeOption.TEARDROP -> unitRect(0.9f)
    IconShapeOption.FLOWER -> MaterialShapes.Flower
    IconShapeOption.SCALLOP -> MaterialShapes.Cookie12Sided
    IconShapeOption.SQUARE -> unitRect(0.28f)
    IconShapeOption.HEXAGON -> RoundedPolygon(numVertices = 6, rounding = CornerRounding(0.1f)).normalized()
    IconShapeOption.CLOVER -> MaterialShapes.Clover4Leaf
    IconShapeOption.COOKIE9 -> MaterialShapes.Cookie9Sided
    IconShapeOption.COOKIE12 -> MaterialShapes.Cookie12Sided
    IconShapeOption.SUNNY -> MaterialShapes.Sunny
    IconShapeOption.PENTAGON -> MaterialShapes.Pentagon
    IconShapeOption.GEM -> MaterialShapes.Gem
    IconShapeOption.PILL -> MaterialShapes.Pill
    IconShapeOption.PUFFY -> MaterialShapes.Puffy
    IconShapeOption.CONTINUOUS -> ContinuousSquircle
}

/** Compose [Shape] built from a normalized polygon (used for the new icon shapes). */
class PolygonShape(private val polygon: RoundedPolygon) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val path = android.graphics.Path()
        polygon.toPath(path)
        val m = android.graphics.Matrix()
        m.setScale(size.width, size.height)
        path.transform(m)
        return Outline.Generic(path.asComposePath())
    }
}

/** Morphs are built once per shape: building a Morph costs more than a whole animation frame. */
object ShapeMorphs {
    private val polygons = ConcurrentHashMap<IconShapeOption, RoundedPolygon>()
    private val windows = ConcurrentHashMap<IconShapeOption, Morph>()

    /** Corner radius of the window when the morph ends, as a fraction of the side. */
    const val WINDOW_CORNER = 0.28f
    private val windowPolygon by lazy { unitRect(WINDOW_CORNER * 2f) }

    fun polygon(shape: IconShapeOption): RoundedPolygon = polygons.getOrPut(shape) { shape.polygon() }
    fun window(shape: IconShapeOption): Morph = windows.getOrPut(shape) { Morph(polygon(shape), windowPolygon) }
}
