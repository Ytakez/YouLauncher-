package com.youlauncher.app

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import kotlin.math.max

/**
 * State of the Liquid Glass theme, provided once at the root.
 * [on] = theme active, [fill] = how milky the glass body is (0..1), [fringe] = rainbow light fringe on the edges.
 */
data class LiquidStyle(val on: Boolean = false, val fill: Float = 0.16f, val fringe: Boolean = true)

val LocalLiquid = staticCompositionLocalOf { LiquidStyle() }

private fun Color.a(v: Float): Color = copy(alpha = v.coerceIn(0f, 1f))

private fun Outline.toPath(): Path {
    val o = this
    return when (o) {
        is Outline.Rectangle -> Path().apply { addRect(o.rect) }
        is Outline.Rounded -> Path().apply { addRoundRect(o.roundRect) }
        is Outline.Generic -> o.path
    }
}

private fun DrawScope.shapePath(shape: Shape): Path = shape.createOutline(size, layoutDirection, this).toPath()

/** Glass body: soft shadow outside, diagonal tint, top sheen, lens band along the inner edge, optional press glow. */
private fun DrawScope.drawBack(path: Path, tint: Color, fill: Float, glow: Float, shadow: Boolean) {
    val w = size.width
    val h = size.height
    if (shadow) {
        clipPath(path, ClipOp.Difference) {
            translate(top = 3.dp.toPx()) {
                for (i in 1..5) {
                    drawPath(
                        path,
                        Color.Black.a(0.055f * (6 - i) / 5f),
                        style = Stroke(width = (i * 3.5f).dp.toPx())
                    )
                }
            }
        }
    }
    drawPath(
        path,
        Brush.linearGradient(
            0f to tint.a(fill * 1.5f),
            0.5f to tint.a(fill * 0.6f),
            1f to tint.a(fill * 1.25f),
            start = Offset.Zero,
            end = Offset(w, h)
        )
    )
    clipPath(path) {
        drawRect(
            Brush.verticalGradient(
                0f to Color.White.a(0.20f + 0.15f * glow),
                0.5f to Color.Transparent,
                startY = 0f,
                endY = h
            )
        )
        drawPath(path, Color.White.a(0.09f + 0.08f * glow), style = Stroke(width = 12.dp.toPx()))
        drawPath(path, Color.White.a(0.10f), style = Stroke(width = 4.dp.toPx()))
        if (glow > 0.01f) {
            drawRect(
                Brush.radialGradient(
                    listOf(Color.White.a(0.30f * glow), Color.Transparent),
                    center = Offset(w / 2f, h / 2f),
                    radius = max(w, h) * 0.7f
                )
            )
        }
    }
}

/** Bright specular edge (strong top-left and bottom-right) with an optional rainbow fringe. Drawn only inside the shape. */
private fun DrawScope.drawRim(path: Path, glow: Float, fringe: Boolean) {
    val w = size.width
    val h = size.height
    val rim = 1.5.dp.toPx()
    clipPath(path) {
        if (fringe) {
            val d = 1.2.dp.toPx()
            translate(left = -d) { drawPath(path, Color(0xFF00E5FF).a(0.30f), style = Stroke(width = rim * 4f)) }
            translate(left = d) { drawPath(path, Color(0xFFFF3D8B).a(0.28f), style = Stroke(width = rim * 4f)) }
            translate(top = -d) { drawPath(path, Color(0xFFFFE14D).a(0.22f), style = Stroke(width = rim * 4f)) }
        }
        drawPath(
            path,
            Brush.linearGradient(
                0f to Color.White.a(0.95f),
                0.32f to Color.White.a(0.22f),
                0.62f to Color.White.a(0.14f),
                1f to Color.White.a(0.85f),
                start = Offset.Zero,
                end = Offset(w, h)
            ),
            style = Stroke(width = rim * 2f)
        )
        if (glow > 0.01f) drawPath(path, Color.White.a(0.55f * glow), style = Stroke(width = rim * 3.2f))
    }
}

/**
 * Liquid Glass surface: translucent body, specular rim, rainbow edge, soft shadow.
 * Android doesn't let an app read the pixels behind its window (the wallpaper), so real refraction isn't possible
 * here: the glass is built from lighting instead. [glow] (0..1) is read while drawing, so it can be animated for free.
 */
fun Modifier.liquidGlass(
    shape: Shape,
    tint: Color = Color.White,
    fill: Float = 0.16f,
    glow: () -> Float = { 0f },
    shadow: Boolean = true,
    fringe: Boolean = true
): Modifier = drawWithContent {
    val path = shapePath(shape)
    val g = glow()
    drawBack(path, tint, fill, g, shadow)
    drawContent()
    drawRim(path, g, fringe)
}

/** Only the edge light and a top sheen, for panels that already have their own fill. */
fun Modifier.liquidRim(shape: Shape, fringe: Boolean = true, sheen: Boolean = true): Modifier = drawWithContent {
    drawContent()
    val path = shapePath(shape)
    if (sheen) {
        clipPath(path) {
            drawRect(
                Brush.verticalGradient(
                    0f to Color.White.a(0.14f),
                    0.4f to Color.Transparent,
                    startY = 0f,
                    endY = size.height
                )
            )
        }
    }
    drawRim(path, 0f, fringe)
}

/** App icon on glass: diagonal sheen, lens band, darker bottom, thin edge light; brighter while pressed. */
fun Modifier.liquidIcon(shape: Shape, glow: () -> Float = { 0f }): Modifier = drawWithContent {
    drawContent()
    val path = shapePath(shape)
    val g = glow()
    clipPath(path) {
        drawRect(
            Brush.linearGradient(
                0f to Color.White.a(0.30f),
                0.42f to Color.Transparent,
                1f to Color.White.a(0.14f),
                start = Offset.Zero,
                end = Offset(size.width, size.height)
            )
        )
        drawRect(
            Brush.verticalGradient(
                0.6f to Color.Transparent,
                1f to Color.Black.a(0.16f),
                startY = 0f,
                endY = size.height
            )
        )
        drawPath(path, Color.White.a(0.14f + 0.18f * g), style = Stroke(width = size.minDimension * 0.10f))
        if (g > 0.01f) drawRect(Color.White.a(0.16f * g))
    }
    drawRim(path, g, false)
}

/** Glass for panels that carry text (folder window, menus): dark glass in the dark theme, milky glass in the light one. */
@Composable
fun Modifier.liquidPanel(shape: Shape, shadow: Boolean = true): Modifier {
    val st = LocalLiquid.current
    val dark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    return liquidGlass(
        shape,
        tint = if (dark) Color(0xFF1C1C1E) else Color.White,
        fill = if (dark) 0.62f else 0.72f,
        shadow = shadow,
        fringe = st.fringe
    )
}

/** Container colour for DropdownMenu: transparent in Liquid Glass (the glass is drawn by [liquidMenu]). */
@Composable
fun menuColor(): Color =
    if (LocalLiquid.current.on) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerHigh

/** Glass look for the DropdownMenu content; does nothing in the other themes. */
@Composable
fun Modifier.liquidMenu(): Modifier =
    if (LocalLiquid.current.on) liquidPanel(RoundedCornerShape(24.dp), shadow = false) else this
