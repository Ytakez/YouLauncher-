package com.youlauncher.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.roundToInt

/**
 * Settings of one app (long-press menu -> "Customize icon"): shape, size, own name, label on/off.
 * Everything applies instantly: the icon on the home screen changes while the sheet is open.
 */
@Composable
fun AppStyleSheet(vm: LauncherViewModel, app: AppInfo) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val globalShape by vm.settings.iconShape.collectAsStateWithLifecycle()
    val themed by vm.settings.themedIcons.collectAsStateWithLifecycle()
    val style = AppStyles.of(app.key) ?: AppStyle()
    fun update(f: (AppStyle) -> AppStyle) = AppStyles.set(context, app.key, f(AppStyles.of(app.key) ?: AppStyle()))
    val shape = (style.shape ?: globalShape).toShape()
    val icon = rememberAppIcon(app.key, themed, 64.dp)

    Box(
        Modifier.fillMaxSize().background(cs.scrim.copy(alpha = 0.32f)).clickable(interactionSource = null, indication = null) {
            vm.closeAppStyle()
        }
    )
    Box(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.navigationBars.union(WindowInsets.ime)),
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = cs.surfaceContainer,
            contentColor = cs.onSurface,
            shadowElevation = 3.dp,
            // swallow taps so the scrim behind does not close the sheet
            modifier = Modifier.padding(12.dp).fillMaxWidth().heightIn(max = 640.dp)
                .clickable(interactionSource = null, indication = null) {}
        ) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(vertical = 16.dp)) {
                Row(
                    Modifier.padding(horizontal = 20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
                        icon?.let {
                            Image(
                                bitmap = it,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp * style.scale).clip(shape)
                            )
                        }
                    }
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.app_style_title), style = MaterialTheme.typography.headlineSmall)
                        Text(app.label, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    }
                }

                SectionTitle(stringResource(R.string.app_style_shape))
                ShapePicker(selected = style.shape ?: globalShape, onSelect = { v -> update { it.copy(shape = v) } })
                if (style.shape != null) {
                    TextButton(
                        onClick = { update { it.copy(shape = null) } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    ) { Text(stringResource(R.string.app_style_shape_default)) }
                }
                SliderRow(
                    stringResource(R.string.app_style_size),
                    "${(style.scale * 100).roundToInt()}%",
                    style.scale,
                    0.6f..1.4f
                ) { v -> update { it.copy(scale = (v * 20f).roundToInt() / 20f) } }

                SectionTitle(stringResource(R.string.app_style_name))
                var text by remember(app.key) { mutableStateOf(style.label ?: "") }
                OutlinedTextField(
                    value = text,
                    onValueChange = { v -> text = v; update { it.copy(label = v.takeIf { s -> s.isNotBlank() }) } },
                    placeholder = { Text(app.label) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp)
                )
                SwitchRow(stringResource(R.string.app_style_show_label), null, !style.hideLabel) { on ->
                    update { it.copy(hideLabel = !on) }
                }

                if (!style.isDefault) {
                    TextButton(
                        onClick = { AppStyles.set(context, app.key, AppStyle()); text = "" },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    ) { Text(stringResource(R.string.app_style_reset)) }
                }
                TextButton(onClick = vm::closeAppStyle, modifier = Modifier.padding(horizontal = 12.dp)) {
                    Text(stringResource(R.string.done))
                }
            }
        }
    }
}
