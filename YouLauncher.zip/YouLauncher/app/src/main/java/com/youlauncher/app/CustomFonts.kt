package com.youlauncher.app

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Own TTF / OTF fonts: copied into the app's private storage and chosen by file name. */
object CustomFonts {
    private const val MAX_BYTES = 25L * 1024 * 1024
    private lateinit var app: Context
    private val cache = HashMap<String, FontFamily>()

    fun init(c: Context) { app = c.applicationContext }

    private fun dir() = File(app.filesDir, "fonts").apply { mkdirs() }

    fun list(): List<String> =
        dir().listFiles()
            ?.filter { it.isFile && (it.extension.equals("ttf", true) || it.extension.equals("otf", true)) }
            ?.map { it.name }?.sortedBy { it.lowercase() } ?: emptyList()

    fun label(file: String) = file.substringBeforeLast('.')

    /** Font family for Compose, or null if the file is missing or unreadable. */
    fun family(file: String): FontFamily? {
        cache[file]?.let { return it }
        val f = File(dir(), file)
        if (!f.exists()) return null
        val tf = try { Typeface.Builder(f).build() } catch (e: Throwable) { null } ?: return null
        return FontFamily(tf).also { cache[file] = it }
    }

    /** Copies the chosen font. Returns the stored file name, or null if the file is not a font. */
    fun import(uri: Uri): String? {
        val cr = app.contentResolver
        var display = uri.lastPathSegment ?: "font"
        cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0)?.let { n -> display = n }
        }
        val base = display.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N} _.-]"), "_").trim().take(40).ifEmpty { "font" }

        val tmp = File(dir(), ".import.tmp")
        var total = 0L
        val input = cr.openInputStream(uri) ?: return null
        input.use { inp ->
            tmp.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_BYTES) { tmp.delete(); return null }
                    out.write(buf, 0, n)
                }
            }
        }
        val head = ByteArray(4)
        val got = tmp.inputStream().use { it.read(head) }
        val sig = String(head, Charsets.ISO_8859_1)
        val isTrueType = got == 4 && (head.contentEquals(byteArrayOf(0, 1, 0, 0)) || sig == "true" || sig == "ttcf")
        val isOpenType = got == 4 && sig == "OTTO"
        if (!isTrueType && !isOpenType) { tmp.delete(); return null }

        val name = "$base." + if (isOpenType) "otf" else "ttf"
        val dst = File(dir(), name)
        if (dst.exists()) dst.delete()
        if (!tmp.renameTo(dst)) { tmp.delete(); return null }
        cache.remove(name)
        val ok = try { Typeface.Builder(dst).build() != null } catch (e: Throwable) { false }
        if (!ok) { dst.delete(); return null }
        return name
    }
}

/** Same typography, every style switched to [f]. */
fun Typography.withFamily(f: FontFamily) = Typography(
    displayLarge = displayLarge.copy(fontFamily = f),
    displayMedium = displayMedium.copy(fontFamily = f),
    displaySmall = displaySmall.copy(fontFamily = f),
    headlineLarge = headlineLarge.copy(fontFamily = f),
    headlineMedium = headlineMedium.copy(fontFamily = f),
    headlineSmall = headlineSmall.copy(fontFamily = f),
    titleLarge = titleLarge.copy(fontFamily = f),
    titleMedium = titleMedium.copy(fontFamily = f),
    titleSmall = titleSmall.copy(fontFamily = f),
    bodyLarge = bodyLarge.copy(fontFamily = f),
    bodyMedium = bodyMedium.copy(fontFamily = f),
    bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f),
    labelMedium = labelMedium.copy(fontFamily = f),
    labelSmall = labelSmall.copy(fontFamily = f)
)

/** Settings: system font, imported fonts, and a button to import another one. */
@Composable
fun FontPicker(s: LauncherSettings) {
    val ctx = LocalContext.current
    CustomFonts.init(ctx)
    val scope = rememberCoroutineScope()
    val current by s.customFont.collectAsStateWithLifecycle()
    var files by remember { mutableStateOf(CustomFonts.list()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val name = withContext(Dispatchers.IO) { CustomFonts.import(uri) }
            if (name != null) {
                files = CustomFonts.list()
                s.setCustomFont(name)
            }
        }
    }
    ChoiceRow(
        title = stringResource(R.string.font_title),
        options = listOf("" to stringResource(R.string.font_system)) + files.map { it to CustomFonts.label(it) },
        selected = current,
        onSelect = s::setCustomFont
    )
    ActionRow(stringResource(R.string.font_add)) { picker.launch(arrayOf("*/*")) }
}
