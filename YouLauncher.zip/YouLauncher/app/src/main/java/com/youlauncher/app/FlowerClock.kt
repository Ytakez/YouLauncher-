package com.youlauncher.app

import android.content.Intent
import android.provider.AlarmClock
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.cos

/** Home clock look: plain date text (old) or two flower-shaped blobs with date and battery pills. */
enum class HomeClockStyle { DATE, FLOWER }

private val FlowerBlobShape = polarShape { t -> 0.91 + 0.09 * cos(10 * t) }

@Composable
private fun Blob(text: String, container: Color, content: Color, size: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier.size(size).clip(FlowerBlobShape).background(container),
        contentAlignment = Alignment.Center
    ) {
        AnimatedContent(
            targetState = text,
            transitionSpec = { (slideInVertically { it / 2 } + fadeIn()) togetherWith (slideOutVertically { -it / 2 } + fadeOut()) },
            label = "blobDigits"
        ) { t ->
            Text(
                t, color = content, fontSize = (size.value * 0.5f).sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, maxLines = 1, softWrap = false
            )
        }
    }
}

@Composable
private fun BatteryGlyph(color: Color) {
    Canvas(Modifier.size(width = 10.dp, height = 18.dp)) {
        drawRoundRect(color, Offset(size.width * 0.3f, 0f), Size(size.width * 0.4f, size.height * 0.14f), CornerRadius(2f, 2f))
        drawRoundRect(color, Offset(0f, size.height * 0.12f), Size(size.width, size.height * 0.88f), CornerRadius(4f, 4f))
    }
}

/** Material You flower clock: hours and minutes in scalloped blobs, date pill, battery pill. Colors follow the theme. */
@Composable
fun FlowerClock() {
    val ctx = LocalContext.current
    val s = MaterialTheme.colorScheme
    val is24 = remember { android.text.format.DateFormat.is24HourFormat(ctx) }
    val now = rememberNow(everySecond = false)
    val battery = rememberBattery()
    val hours = if (is24) "%02d".format(now.hour) else (if (now.hour % 12 == 0) 12 else now.hour % 12).toString()
    val minutes = "%02d".format(now.minute)
    val day = now.toLocalDate()
    val date = remember(day) { DateTimeFormatter.ofPattern("EEE, d MMM", Locale.getDefault()).format(day) }

    Column(Modifier.padding(bottom = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Blob(hours, s.primaryContainer, s.onPrimaryContainer, 136.dp)
            Blob(minutes, s.tertiaryContainer, s.onTertiaryContainer, 136.dp, Modifier.offset(x = (-10).dp))
        }
        Spacer(Modifier.size(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                date, color = s.onPrimary, style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.clip(RoundedCornerShape(50)).background(s.primary)
                    .padding(horizontal = 18.dp, vertical = 9.dp)
            )
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(s.surfaceContainerHighest.copy(alpha = 0.88f))
                    .padding(horizontal = 16.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BatteryGlyph(if (battery.charging) s.tertiary else s.primary)
                Spacer(Modifier.width(8.dp))
                Text("${battery.level}%", color = s.primary, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

fun openClockApp(ctx: android.content.Context) {
    try {
        ctx.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {}
}
