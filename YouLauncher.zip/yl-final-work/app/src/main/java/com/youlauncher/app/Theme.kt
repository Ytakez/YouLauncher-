package com.youlauncher.app
import androidx.compose.material3.Typography
import androidx.compose.runtime.remember

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

/** Soft tone: HSL gives calm pastel surfaces and clean contrast, unlike saturated HSV colors. */
private fun tone(h: Float, s: Float, l: Float): Color =
    Color(androidx.core.graphics.ColorUtils.HSLToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s, l)))

/** Builds a Material 3 scheme around one hue (used when the user picks a fixed accent instead of wallpaper colors). */
fun accentScheme(hue: Float, dark: Boolean): ColorScheme {
    val h = hue
    val t = hue + 50f // harmonious second hue for tertiary
    return if (dark) {
        darkColorScheme(
            primary = tone(h, 0.70f, 0.80f), onPrimary = tone(h, 0.60f, 0.20f),
            primaryContainer = tone(h, 0.40f, 0.30f), onPrimaryContainer = tone(h, 0.80f, 0.90f),
            secondary = tone(h, 0.35f, 0.80f), onSecondary = tone(h, 0.30f, 0.20f),
            secondaryContainer = tone(h, 0.22f, 0.30f), onSecondaryContainer = tone(h, 0.45f, 0.90f),
            tertiary = tone(t, 0.55f, 0.80f), onTertiary = tone(t, 0.40f, 0.20f),
            tertiaryContainer = tone(t, 0.30f, 0.30f), onTertiaryContainer = tone(t, 0.60f, 0.90f),
            background = tone(h, 0.12f, 0.09f), onBackground = tone(h, 0.12f, 0.90f),
            surface = tone(h, 0.12f, 0.09f), onSurface = tone(h, 0.12f, 0.90f),
            surfaceVariant = tone(h, 0.12f, 0.25f), onSurfaceVariant = tone(h, 0.12f, 0.78f),
            surfaceDim = tone(h, 0.12f, 0.08f), surfaceBright = tone(h, 0.12f, 0.25f),
            surfaceContainerLowest = tone(h, 0.12f, 0.06f), surfaceContainerLow = tone(h, 0.12f, 0.11f),
            surfaceContainer = tone(h, 0.12f, 0.13f), surfaceContainerHigh = tone(h, 0.12f, 0.17f),
            surfaceContainerHighest = tone(h, 0.12f, 0.21f),
            outline = tone(h, 0.08f, 0.60f), outlineVariant = tone(h, 0.10f, 0.30f)
        )
    } else {
        lightColorScheme(
            primary = tone(h, 0.45f, 0.40f), onPrimary = Color.White,
            primaryContainer = tone(h, 0.75f, 0.90f), onPrimaryContainer = tone(h, 0.60f, 0.15f),
            secondary = tone(h, 0.22f, 0.40f), onSecondary = Color.White,
            secondaryContainer = tone(h, 0.35f, 0.90f), onSecondaryContainer = tone(h, 0.35f, 0.15f),
            tertiary = tone(t, 0.35f, 0.40f), onTertiary = Color.White,
            tertiaryContainer = tone(t, 0.60f, 0.90f), onTertiaryContainer = tone(t, 0.50f, 0.15f),
            background = tone(h, 0.25f, 0.98f), onBackground = tone(h, 0.15f, 0.10f),
            surface = tone(h, 0.25f, 0.98f), onSurface = tone(h, 0.15f, 0.10f),
            surfaceVariant = tone(h, 0.25f, 0.90f), onSurfaceVariant = tone(h, 0.12f, 0.30f),
            surfaceDim = tone(h, 0.18f, 0.87f), surfaceBright = tone(h, 0.25f, 0.98f),
            surfaceContainerLowest = Color.White, surfaceContainerLow = tone(h, 0.25f, 0.96f),
            surfaceContainer = tone(h, 0.22f, 0.94f), surfaceContainerHigh = tone(h, 0.20f, 0.92f),
            surfaceContainerHighest = tone(h, 0.18f, 0.90f),
            outline = tone(h, 0.10f, 0.48f), outlineVariant = tone(h, 0.18f, 0.80f)
        )
    }
}


/** Neutral Liquid Glass palette: glass is the visual identity, never wallpaper/accent tinted. */
fun liquidScheme(dark: Boolean): ColorScheme = if (dark) {
    darkColorScheme(
        primary = Color(0xFFF5F5F7), onPrimary = Color(0xFF17171A),
        primaryContainer = Color(0x33FFFFFF), onPrimaryContainer = Color.White,
        secondary = Color(0xFFBFC0C8), onSecondary = Color(0xFF17171A),
        secondaryContainer = Color(0x26FFFFFF), onSecondaryContainer = Color.White,
        tertiary = Color(0xFFE2E2E8), onTertiary = Color(0xFF17171A),
        tertiaryContainer = Color(0x22FFFFFF), onTertiaryContainer = Color.White,
        background = Color(0xE6101014), onBackground = Color.White,
        surface = Color(0xCC202027), onSurface = Color.White,
        surfaceVariant = Color(0x44FFFFFF), onSurfaceVariant = Color(0xFFDADAE2),
        surfaceDim = Color(0xE6000000), surfaceBright = Color(0x55FFFFFF),
        surfaceContainerLowest = Color(0x18181820), surfaceContainerLow = Color(0x242A2A32),
        surfaceContainer = Color(0x33383842), surfaceContainerHigh = Color(0x55484854),
        surfaceContainerHighest = Color(0x66585864),
        outline = Color(0x66FFFFFF), outlineVariant = Color(0x33FFFFFF)
    )
} else {
    lightColorScheme(
        primary = Color(0xFF202027), onPrimary = Color.White,
        primaryContainer = Color(0x33FFFFFF), onPrimaryContainer = Color(0xFF202027),
        secondary = Color(0xFF55555D), onSecondary = Color.White,
        secondaryContainer = Color(0x26FFFFFF), onSecondaryContainer = Color(0xFF202027),
        tertiary = Color(0xFF686871), onTertiary = Color.White,
        tertiaryContainer = Color(0x22FFFFFF), onTertiaryContainer = Color(0xFF202027),
        background = Color(0xDDF2F2F5), onBackground = Color(0xFF17171B),
        surface = Color(0xCCFFFFFF), onSurface = Color(0xFF17171B),
        surfaceVariant = Color(0x44FFFFFF), onSurfaceVariant = Color(0xFF55555D),
        surfaceDim = Color(0xDDE5E5EA), surfaceBright = Color(0xDDFFFFFF),
        surfaceContainerLowest = Color(0x66FFFFFF), surfaceContainerLow = Color(0x80FFFFFF),
        surfaceContainer = Color(0x99FFFFFF), surfaceContainerHigh = Color(0xBBFFFFFF),
        surfaceContainerHighest = Color(0xDDE5E5EA),
        outline = Color(0x663C3C43), outlineVariant = Color(0x33FFFFFF)
    )
}

/** Alpha-aware replacement of Color.copy(alpha = x): keeps the translucency of glass colors. */
fun Color.mulAlpha(a: Float): Color = copy(alpha = alpha * a)

/** Legacy theme id now resolves to the neutral Liquid Glass palette. */
fun blurScheme(dark: Boolean): ColorScheme = liquidScheme(dark)

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun YouLauncherTheme(
    mode: ThemeMode = ThemeMode.SYSTEM,
    accent: AccentOption = AccentOption.SYSTEM,
    launcherTheme: LauncherTheme = LauncherTheme.MATERIAL,
    fontFile: String = "",
    content: @Composable () -> Unit
) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val ctx = LocalContext.current
    val scheme = when (launcherTheme) {
        LauncherTheme.LIQUID -> liquidScheme(dark)
        LauncherTheme.BLUR -> liquidScheme(dark)
        LauncherTheme.MATERIAL -> when {
            accent != AccentOption.SYSTEM -> accentScheme(accent.hue, dark)
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
                if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
            else -> accentScheme(250f, dark)
        }
    }
    CustomFonts.init(ctx)
    val customFamily = remember(fontFile) { if (fontFile.isEmpty()) null else CustomFonts.family(fontFile) }
    MaterialExpressiveTheme(
        colorScheme = scheme,
        typography = customFamily?.let { Typography().withFamily(it) } ?: Typography(),
        motionScheme = MotionScheme.expressive(),
        content = content
    )
}
