# YouLauncher — технические заметки

- `LaunchOverlay.kt` и `LaunchMorph.kt`: анимация открытия и возврата приложения, морфинг иконки в окно, геометрия скругления и пружинное завершение.
- `LiquidGlass.kt`: отрисовка стеклянных поверхностей, бликов и световой каймы.
- `LockScreen.kt`, `LockClocks.kt`, `LiquidClock.kt`, `LockSettingsScreen.kt`: экран блокировки, настройка размера и растяжения часов.
- `IconPalette.kt`, `Components.kt`, `LauncherSettings.kt`, `SettingsScreen.kt`: режимы перекраски иконок.

## Сборка

Сборка APK в исходной среде не подтверждена. Для проверки откройте проект в Android Studio с JDK 17, Android SDK 35 и Gradle 8.9, выполните Gradle Sync и соберите `app`.

## Automatic launcher refresh after settings changes

Launcher preferences are observed by `MainActivity`. Changes are applied live while the settings page is open; when the user exits Settings or Lock Screen settings, the activity is recreated once if any preference changed. This refreshes launcher resources and system surfaces without interrupting sliders, dialogs, or wallpaper selection. The setting values remain in SharedPreferences and the launcher ViewModel is retained across the activity recreation.
