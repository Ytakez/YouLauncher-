#!/bin/sh
# Сборка debug APK через Gradle с минимальным расходом памяти.
# Нужны: JDK 17, Android SDK (ANDROID_HOME), Gradle 8.9 (команда `gradle`).
# Если RAM меньше 2 ГБ, включи swap (1-2 ГБ), иначе сборку убьёт система.
exec gradle :app:assembleDebug \
  --no-daemon --max-workers=1 --no-parallel --no-build-cache \
  -Dorg.gradle.jvmargs="-Xmx768m -XX:MaxMetaspaceSize=256m -XX:+UseSerialGC" \
  -Pkotlin.compiler.execution.strategy=in-process \
  -Pandroid.enableJetifier=false
