package com.youlauncher.app

import android.appwidget.AppWidgetProviderInfo
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

private data class WidgetGroup(val pkg: String, val label: String, val items: List<AppWidgetProviderInfo>)

/** Widget picker in Material 3 style: widgets are grouped by app into expandable tonal cards with big previews. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WidgetsScreen(vm: LauncherViewModel, onAdd: (AppWidgetProviderInfo) -> Unit) {
    val ctl = vm.widgets
    val pm = LocalContext.current.packageManager
    val topIds by ctl.ids.collectAsStateWithLifecycle()
    val bottomIds by ctl.bottomIds.collectAsStateWithLifecycle()
    val ids = topIds + bottomIds
    val groups = remember {
        ctl.providers().groupBy { it.provider.packageName }.map { (pkg, list) ->
            val label = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
            WidgetGroup(pkg, label, list.sortedBy { ctl.label(it).lowercase() })
        }.sortedBy { it.label.lowercase() }
    }
    var expanded by remember { mutableStateOf<String?>(null) }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
            PageTopBar(stringResource(R.string.widgets), onBack = vm::closeOverlay)
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (ids.isNotEmpty()) {
                    item { WidgetSectionLabel(stringResource(R.string.added_widgets)) }
                    items(ids, key = { "added$it" }) { id -> AddedWidgetCard(ctl, id) }
                }
                item { WidgetSectionLabel(stringResource(R.string.add_widget)) }
                items(groups, key = { it.pkg }) { g ->
                    WidgetGroupCard(
                        ctl = ctl,
                        group = g,
                        expanded = expanded == g.pkg,
                        onToggle = { expanded = if (expanded == g.pkg) null else g.pkg },
                        onAdd = onAdd
                    )
                }
            }
        }
    }
}

@Composable
private fun WidgetSectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 12.dp, top = 12.dp, bottom = 4.dp)
    )
}

@Composable
private fun AddedWidgetCard(ctl: WidgetController, id: Int) {
    val info = ctl.manager.getAppWidgetInfo(id)
    Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.primaryContainer) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                if (info != null) ctl.label(info) else "#$id",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            FilledTonalIconButton(onClick = { ctl.remove(id) }) {
                Icon(Icons.Rounded.Delete, contentDescription = stringResource(R.string.remove))
            }
        }
    }
}

@Composable
private fun WidgetGroupCard(
    ctl: WidgetController,
    group: WidgetGroup,
    expanded: Boolean,
    onToggle: () -> Unit,
    onAdd: (AppWidgetProviderInfo) -> Unit
) {
    val pm = LocalContext.current.packageManager
    val appIcon: ImageBitmap? by produceState<ImageBitmap?>(null, group.pkg) {
        value = withContext(Dispatchers.Default) {
            try { pm.getApplicationIcon(group.pkg).toBitmap(96, 96).asImageBitmap() } catch (_: Exception) { null }
        }
    }
    val arrow by animateFloatAsState(if (expanded) 180f else 0f, label = "widgetArrow")
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.fillMaxWidth().animateContentSize()
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceContainerHighest)) {
                    appIcon?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(group.label, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        stringResource(R.string.widgets_count, group.items.size),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(
                    Icons.Rounded.ArrowDropDown,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.rotate(arrow)
                )
            }
            AnimatedVisibility(expanded) {
                Column(
                    Modifier.padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    group.items.forEach { info -> WidgetPreviewCard(ctl, info) { onAdd(info) } }
                }
            }
        }
    }
}

@Composable
private fun WidgetPreviewCard(ctl: WidgetController, info: AppWidgetProviderInfo, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val density = ctx.resources.displayMetrics.density
    fun cells(px: Int) = (((px / density) + 30f) / 70f).toInt().coerceIn(1, 8)
    val preview: ImageBitmap? by produceState<ImageBitmap?>(null, info) {
        value = withContext(Dispatchers.Default) {
            try {
                val d = info.loadPreviewImage(ctx, 0) ?: info.loadIcon(ctx, 0)
                if (d == null) null else {
                    val iw = d.intrinsicWidth.takeIf { it > 0 } ?: 192
                    val ih = d.intrinsicHeight.takeIf { it > 0 } ?: 192
                    val k = min(1f, 640f / max(iw, ih))
                    d.toBitmap((iw * k).toInt().coerceAtLeast(1), (ih * k).toInt().coerceAtLeast(1)).asImageBitmap()
                }
            } catch (_: Exception) { null }
        }
    }
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(12.dp)) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 72.dp, max = 160.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainer),
                contentAlignment = Alignment.Center
            ) {
                preview?.let {
                    Image(
                        bitmap = it,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 160.dp).padding(8.dp)
                    )
                }
            }
            Spacer(Modifier.size(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(ctl.label(info), style = MaterialTheme.typography.bodyLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.size(4.dp))
                    Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
                        Text(
                            "${cells(info.minWidth)}×${cells(info.minHeight)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
                FilledTonalIconButton(onClick = onClick) {
                    Icon(Icons.Rounded.Add, contentDescription = stringResource(R.string.add_widget))
                }
            }
        }
    }
}
