package com.youlauncher.app

import android.appwidget.AppWidgetProviderInfo
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun WidgetsScreen(vm: LauncherViewModel, onAdd: (AppWidgetProviderInfo) -> Unit) {
    val ctl = vm.widgets
    val ids by ctl.ids.collectAsStateWithLifecycle()
    val providers = remember { ctl.providers().sortedBy { ctl.label(it).lowercase() } }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
            PageTopBar(stringResource(R.string.widgets), onBack = vm::closeOverlay)
            LazyColumn(Modifier.weight(1f)) {
                if (ids.isNotEmpty()) {
                    item {
                        Text(
                            stringResource(R.string.added_widgets),
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(start = 24.dp, top = 8.dp, bottom = 8.dp)
                        )
                    }
                    items(ids, key = { "added$it" }) { id ->
                        val info = ctl.manager.getAppWidgetInfo(id)
                        Row(
                            Modifier.fillMaxWidth().padding(start = 24.dp, end = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                if (info != null) ctl.label(info) else "#$id",
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { ctl.remove(id) }) {
                                Icon(Icons.Rounded.Delete, contentDescription = stringResource(R.string.remove))
                            }
                        }
                    }
                }
                item {
                    Text(
                        stringResource(R.string.add_widget),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 24.dp, top = 20.dp, bottom = 8.dp)
                    )
                }
                items(providers, key = { it.provider.flattenToString() }) { info ->
                    ProviderRow(ctl, info) { onAdd(info) }
                }
            }
        }
    }
}

@Composable
private fun ProviderRow(ctl: WidgetController, info: AppWidgetProviderInfo, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val preview: ImageBitmap? by produceState<ImageBitmap?>(null, info) {
        value = withContext(Dispatchers.Default) {
            try {
                val d = info.loadPreviewImage(ctx, 0) ?: info.loadIcon(ctx, 0)
                d?.toBitmap(192, 192)?.asImageBitmap()
            } catch (_: Exception) { null }
        }
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.size(64.dp)
        ) {
            preview?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(16.dp))
                )
            }
        }
        Spacer(Modifier.width(16.dp))
        Text(ctl.label(info), style = MaterialTheme.typography.bodyLarge)
    }
}
