package com.youlauncher.app

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

/** Soft tone: HSL gives calm pastel surfaces and clean contrast, unlike saturated HSV colors. */
private fun tone(h: Float, s: Float, l: Float): Color =
    Color(androidx.core.graphics.ColorUtils.HSLToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s, l)))

/** Builds a Material 3 scheme around one hue (used when the user picks a fixed accent instead of wallpaper colors). */
fun accentScheme(hue: Float, dark: Boolean): ColorScheme {
    val h = hue
    val t = hue + 50f // harmonious second hue for tertiary
    return if (dark) {
        darkColorScheme(
            primary = tone(h, 0.70f, 0.80f), onPrimary = tone(h, 0.60f, 0.20f),
            primaryContainer = tone(h, 0.40f, 0.30f), onPrimaryContainer = tone(h, 0.80f, 0.90f),
            secondary = tone(h, 0.35f, 0.80f), onSecondary = tone(h, 0.30f, 0.20f),
            secondaryContainer = tone(h, 0.22f, 0.30f), onSecondaryContainer = tone(h, 0.45f, 0.90f),
            tertiary = tone(t, 0.55f, 0.80f), onTertiary = tone(t, 0.40f, 0.20f),
            tertiaryContainer = tone(t, 0.30f, 0.30f), onTertiaryContainer = tone(t, 0.60f, 0.90f),
            background = tone(h, 0.12f, 0.09f), onBackground = tone(h, 0.12f, 0.90f),
            surface = tone(h, 0.12f, 0.09f), onSurface = tone(h, 0.12f, 0.90f),
            surfaceVariant = tone(h, 0.12f, 0.25f), onSurfaceVariant = tone(h, 0.12f, 0.78f),
            surfaceDim = tone(h, 0.12f, 0.08f), surfaceBright = tone(h, 0.12f, 0.25f),
            surfaceContainerLowest = tone(h, 0.12f, 0.06f), surfaceContainerLow = tone(h, 0.12f, 0.11f),
            surfaceContainer = tone(h, 0.12f, 0.13f), surfaceContainerHigh = tone(h, 0.12f, 0.17f),
            surfaceContainerHighest = tone(h, 0.12f, 0.21f),
            outline = tone(h, 0.08f, 0.60f), outlineVariant = tone(h, 0.10f, 0.30f)
        )
    } else {
        lightColorScheme(
            primary = tone(h, 0.45f, 0.40f), onPrimary = Color.White,
            primaryContainer = tone(h, 0.75f, 0.90f), onPrimaryContainer = tone(h, 0.60f, 0.15f),
            secondary = tone(h, 0.22f, 0.40f), onSecondary = Color.White,
            secondaryContainer = tone(h, 0.35f, 0.90f), onSecondaryContainer = tone(h, 0.35f, 0.15f),
            tertiary = tone(t, 0.35f, 0.40f), onTertiary = Color.White,
            tertiaryContainer = tone(t, 0.60f, 0.90f), onTertiaryContainer = tone(t, 0.50f, 0.15f),
            background = tone(h, 0.25f, 0.98f), onBackground = tone(h, 0.15f, 0.10f),
            surface = tone(h, 0.25f, 0.98f), onSurface = tone(h, 0.15f, 0.10f),
            surfaceVariant = tone(h, 0.25f, 0.90f), onSurfaceVariant = tone(h, 0.12f, 0.30f),
            surfaceDim = tone(h, 0.18f, 0.87f), surfaceBright = tone(h, 0.25f, 0.98f),
            surfaceContainerLowest = Color.White, surfaceContainerLow = tone(h, 0.25f, 0.96f),
            surfaceContainer = tone(h, 0.22f, 0.94f), surfaceContainerHigh = tone(h, 0.20f, 0.92f),
            surfaceContainerHighest = tone(h, 0.18f, 0.90f),
            outline = tone(h, 0.10f, 0.48f), outlineVariant = tone(h, 0.18f, 0.80f)
        )
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun YouLauncherTheme(
    mode: ThemeMode = ThemeMode.SYSTEM,
    accent: AccentOption = AccentOption.SYSTEM,
    content: @Composable () -> Unit
) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val ctx = LocalContext.current
    val scheme = when {
        accent != AccentOption.SYSTEM -> accentScheme(accent.hue, dark)
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        else -> accentScheme(250f, dark) // pre-Android 12: soft periwinkle instead of the stock purple
    }
    MaterialExpressiveTheme(
        colorScheme = scheme,
        motionScheme = MotionScheme.expressive(),
        content = content
    )
}
