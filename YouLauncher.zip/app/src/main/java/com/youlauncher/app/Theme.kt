package com.youlauncher.app

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private fun hsv(h: Float, s: Float, v: Float) =
    Color(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))

/** Builds a scheme around one hue (used when the user picks a fixed accent instead of wallpaper colors). */
fun accentScheme(hue: Float, dark: Boolean): ColorScheme {
    return if (dark) {
        darkColorScheme(
            primary = hsv(hue, 0.45f, 0.98f),
            onPrimary = hsv(hue, 0.85f, 0.25f),
            primaryContainer = hsv(hue, 0.75f, 0.45f),
            onPrimaryContainer = hsv(hue, 0.15f, 1f),
            secondary = hsv(hue, 0.25f, 0.88f),
            onSecondary = hsv(hue, 0.6f, 0.2f),
            secondaryContainer = hsv(hue, 0.4f, 0.38f),
            onSecondaryContainer = hsv(hue, 0.12f, 0.95f),
            tertiary = hsv((hue + 40f) % 360f, 0.4f, 0.95f),
            surface = hsv(hue, 0.15f, 0.12f),
            surfaceVariant = hsv(hue, 0.2f, 0.3f),
            surfaceContainer = hsv(hue, 0.15f, 0.16f),
            surfaceContainerHigh = hsv(hue, 0.15f, 0.2f),
            surfaceContainerHighest = hsv(hue, 0.15f, 0.25f)
        )
    } else {
        lightColorScheme(
            primary = hsv(hue, 0.85f, 0.65f),
            onPrimary = Color.White,
            primaryContainer = hsv(hue, 0.2f, 1f),
            onPrimaryContainer = hsv(hue, 0.9f, 0.25f),
            secondary = hsv(hue, 0.6f, 0.5f),
            onSecondary = Color.White,
            secondaryContainer = hsv(hue, 0.14f, 0.97f),
            onSecondaryContainer = hsv(hue, 0.8f, 0.25f),
            tertiary = hsv((hue + 40f) % 360f, 0.6f, 0.6f),
            surface = hsv(hue, 0.04f, 0.99f),
            surfaceVariant = hsv(hue, 0.1f, 0.92f),
            surfaceContainer = hsv(hue, 0.06f, 0.96f),
            surfaceContainerHigh = hsv(hue, 0.08f, 0.94f),
            surfaceContainerHighest = hsv(hue, 0.1f, 0.91f)
        )
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun YouLauncherTheme(
    mode: ThemeMode = ThemeMode.SYSTEM,
    accent: AccentOption = AccentOption.SYSTEM,
    content: @Composable () -> Unit
) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val ctx = LocalContext.current
    val scheme = when {
        accent != AccentOption.SYSTEM -> accentScheme(accent.hue, dark)
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialExpressiveTheme(
        colorScheme = scheme,
        motionScheme = MotionScheme.expressive(),
        content = content
    )
}
