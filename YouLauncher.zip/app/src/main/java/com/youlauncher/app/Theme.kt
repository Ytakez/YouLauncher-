package com.youlauncher.app

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.ColorUtils
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private fun hsl(h: Float, s: Float, l: Float): Color =
    Color(ColorUtils.HSLToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s, l)))

/** Material 3 tonal scheme generated from a single hue (primary / secondary / tertiary + neutral surfaces). */
fun accentScheme(hue: Float, dark: Boolean): ColorScheme = if (!dark) lightColorScheme(
    primary = hsl(hue, 0.55f, 0.40f), onPrimary = Color.White,
    primaryContainer = hsl(hue, 0.80f, 0.89f), onPrimaryContainer = hsl(hue, 0.75f, 0.12f),
    secondary = hsl(hue, 0.25f, 0.40f), onSecondary = Color.White,
    secondaryContainer = hsl(hue, 0.38f, 0.88f), onSecondaryContainer = hsl(hue, 0.40f, 0.12f),
    tertiary = hsl(hue + 60f, 0.35f, 0.40f), onTertiary = Color.White,
    tertiaryContainer = hsl(hue + 60f, 0.50f, 0.88f), onTertiaryContainer = hsl(hue + 60f, 0.50f, 0.12f),
    background = hsl(hue, 0.25f, 0.98f), onBackground = hsl(hue, 0.10f, 0.10f),
    surface = hsl(hue, 0.25f, 0.98f), onSurface = hsl(hue, 0.10f, 0.10f),
    surfaceVariant = hsl(hue, 0.22f, 0.90f), onSurfaceVariant = hsl(hue, 0.12f, 0.30f),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = hsl(hue, 0.25f, 0.96f),
    surfaceContainer = hsl(hue, 0.25f, 0.94f),
    surfaceContainerHigh = hsl(hue, 0.24f, 0.92f),
    surfaceContainerHighest = hsl(hue, 0.22f, 0.90f),
    outline = hsl(hue, 0.10f, 0.50f), outlineVariant = hsl(hue, 0.16f, 0.80f)
) else darkColorScheme(
    primary = hsl(hue, 0.75f, 0.78f), onPrimary = hsl(hue, 0.80f, 0.16f),
    primaryContainer = hsl(hue, 0.50f, 0.28f), onPrimaryContainer = hsl(hue, 0.85f, 0.90f),
    secondary = hsl(hue, 0.35f, 0.78f), onSecondary = hsl(hue, 0.35f, 0.16f),
    secondaryContainer = hsl(hue, 0.25f, 0.28f), onSecondaryContainer = hsl(hue, 0.40f, 0.90f),
    tertiary = hsl(hue + 60f, 0.45f, 0.78f), onTertiary = hsl(hue + 60f, 0.45f, 0.16f),
    tertiaryContainer = hsl(hue + 60f, 0.30f, 0.28f), onTertiaryContainer = hsl(hue + 60f, 0.50f, 0.90f),
    background = hsl(hue, 0.15f, 0.08f), onBackground = hsl(hue, 0.10f, 0.90f),
    surface = hsl(hue, 0.15f, 0.08f), onSurface = hsl(hue, 0.10f, 0.90f),
    surfaceVariant = hsl(hue, 0.12f, 0.26f), onSurfaceVariant = hsl(hue, 0.12f, 0.80f),
    surfaceContainerLowest = hsl(hue, 0.15f, 0.05f),
    surfaceContainerLow = hsl(hue, 0.15f, 0.10f),
    surfaceContainer = hsl(hue, 0.14f, 0.13f),
    surfaceContainerHigh = hsl(hue, 0.13f, 0.17f),
    surfaceContainerHighest = hsl(hue, 0.12f, 0.21f),
    outline = hsl(hue, 0.08f, 0.60f), outlineVariant = hsl(hue, 0.12f, 0.30f)
)

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun YouLauncherTheme(settings: LauncherSettings, content: @Composable () -> Unit) {
    val mode by settings.themeMode.collectAsStateWithLifecycle()
    val dynamic by settings.dynamicColor.collectAsStateWithLifecycle()
    val accent by settings.accent.collectAsStateWithLifecycle()
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val ctx = LocalContext.current
    val scheme = if (dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else accentScheme(accent.hue, dark)
    MaterialExpressiveTheme(
        colorScheme = scheme,
        motionScheme = MotionScheme.expressive(),
        content = content
    )
}
