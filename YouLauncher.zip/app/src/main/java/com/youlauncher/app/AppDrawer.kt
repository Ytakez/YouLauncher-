package com.youlauncher.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

@Composable
fun AppDrawer(vm: LauncherViewModel) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val suggestions by vm.suggestions.collectAsStateWithLifecycle()
    val focus by vm.focusSearch.collectAsStateWithLifecycle()
    val homeCols by vm.settings.columns.collectAsStateWithLifecycle()
    val drawerCols by vm.settings.drawerCols.collectAsStateWithLifecycle()
    val cols = if (drawerCols > 0) drawerCols else homeCols
    val iconSize by vm.settings.iconSize.collectAsStateWithLifecycle()
    val themed by vm.settings.themedIcons.collectAsStateWithLifecycle()
    val dotsOn by vm.settings.dots.collectAsStateWithLifecycle()
    val dotPkgs by NotificationDots.packages.collectAsStateWithLifecycle()
    val launch = rememberLauncher(vm)
    val connection = rememberSwipeConnection(onUp = {}, onDown = vm::closeDrawer)
    val focusRequester = remember { FocusRequester() }

    val filtered = remember(apps, query) {
        val q = query.trim()
        if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
    }

    LaunchedEffect(focus) {
        if (focus) {
            delay(250)
            try { focusRequester.requestFocus() } catch (_: Exception) {}
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f),
        shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
    ) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars)) {
            Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .width(36.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.outlineVariant)
                )
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(cols),
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp).nestedScroll(connection),
                contentPadding = PaddingValues(bottom = 8.dp)
            ) {
                if (query.isBlank() && suggestions.isNotEmpty()) {
                    item(key = "suggested", span = { GridItemSpan(maxLineSpan) }) {
                        Surface(
                            shape = RoundedCornerShape(28.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        ) {
                            Column(Modifier.padding(vertical = 8.dp)) {
                                Text(
                                    stringResource(R.string.suggested),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(start = 20.dp, top = 6.dp)
                                )
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                    suggestions.forEach { app ->
                                        AppIcon(
                                            app = app,
                                            labelColor = MaterialTheme.colorScheme.onSurface,
                                            showLabel = false,
                                            iconSize = iconSize.dp,
                                            themed = themed,
                                            dot = dotsOn && app.packageName in dotPkgs,
                                            modifier = Modifier.weight(1f),
                                            onLaunch = { r -> launch(app.key, r) },
                                            menu = rememberMenu(vm, app, emptyList())
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                items(filtered, key = { it.key }) { app ->
                    AppIcon(
                        app = app,
                        labelColor = MaterialTheme.colorScheme.onSurface,
                        iconSize = iconSize.dp,
                        themed = themed,
                        dot = dotsOn && app.packageName in dotPkgs,
                        onLaunch = { r -> launch(app.key, r) },
                        menu = rememberMenu(
                            vm, app,
                            listOf(
                                MenuAction(stringResource(R.string.add_to_home)) { vm.addToHome(app.key) },
                                MenuAction(stringResource(R.string.add_to_dock)) { vm.addToDock(app.key) }
                            )
                        )
                    )
                }
            }

            TextField(
                value = query,
                onValueChange = vm::setQuery,
                placeholder = { Text(stringResource(R.string.search_apps)) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                shape = CircleShape,
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    filtered.firstOrNull()?.let { launch(it.key, null) }
                }),
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .imePadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .focusRequester(focusRequester)
            )
        }
    }
}
