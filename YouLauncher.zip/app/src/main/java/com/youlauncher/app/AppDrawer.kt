package com.youlauncher.app

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

@Composable
fun AppDrawer(vm: LauncherViewModel) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val suggestions by vm.suggestions.collectAsStateWithLifecycle()
    val focus by vm.focusSearch.collectAsStateWithLifecycle()
    val homeCols by vm.settings.columns.collectAsStateWithLifecycle()
    val drawerCols by vm.settings.drawerCols.collectAsStateWithLifecycle()
    val cols = if (drawerCols > 0) drawerCols else homeCols
    val iconSize by vm.settings.iconSize.collectAsStateWithLifecycle()
    val themed by vm.settings.themedIcons.collectAsStateWithLifecycle()
    val dotsOn by vm.settings.dots.collectAsStateWithLifecycle()
    val dotPkgs by NotificationDots.packages.collectAsStateWithLifecycle()
    val launch = rememberLauncher(vm)
    val connection = rememberSwipeConnection(onUp = {}, onDown = vm::closeDrawer)
    val focusRequester = remember { FocusRequester() }

    val drawerOn by vm.settings.drawerEnabled.collectAsStateWithLifecycle()
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()
    var activeLetter by remember { mutableStateOf<String?>(null) }

    val filtered = remember(apps, query, drawerOn) {
        val q = query.trim()
        when {
            q.isNotEmpty() -> apps.filter { it.label.contains(q, ignoreCase = true) }
            drawerOn -> apps
            else -> emptyList() // no app list: this screen is only a search
        }
    }
    // letter sections (only the full list, not search results)
    val showSections = drawerOn && query.isBlank()
    val sections = remember(filtered, showSections) {
        if (!showSections) emptyList()
        else filtered.groupBy { letterOf(it.label) }.toList().sortedWith(compareBy({ it.first == "#" }, { it.first }))
    }
    val showSuggested = query.isBlank() && suggestions.isNotEmpty()
    val headerIdx = remember(sections, showSuggested) {
        var i = if (showSuggested) 1 else 0
        sections.map { (_, list) -> i.also { i += 1 + list.size } }
    }

    LaunchedEffect(focus) {
        if (focus) {
            delay(250)
            try { focusRequester.requestFocus() } catch (_: Exception) {}
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f),
        shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
    ) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars)) {
            Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .width(36.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.outlineVariant)
                )
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(cols),
                state = gridState,
                modifier = Modifier.fillMaxSize()
                    .padding(start = 12.dp, end = if (showSections && sections.size > 1) 30.dp else 12.dp)
                    .nestedScroll(connection),
                contentPadding = PaddingValues(bottom = 8.dp)
            ) {
                if (showSuggested) {
                    item(key = "suggested", span = { GridItemSpan(maxLineSpan) }) {
                        Surface(
                            shape = RoundedCornerShape(28.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        ) {
                            Column(Modifier.padding(vertical = 8.dp)) {
                                Text(
                                    stringResource(R.string.suggested),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(start = 20.dp, top = 6.dp)
                                )
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                    suggestions.forEach { app ->
                                        AppIcon(
                                            app = app,
                                            labelColor = MaterialTheme.colorScheme.onSurface,
                                            showLabel = false,
                                            iconSize = iconSize.dp,
                                            themed = themed,
                                            dot = dotsOn && app.packageName in dotPkgs,
                                            modifier = Modifier.weight(1f),
                                            onLaunch = { r -> launch(app.key, r) },
                                            menu = rememberMenu(vm, app, emptyList())
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                if (showSections) {
                    sections.forEach { (letter, list) ->
                        item(key = "h$letter", span = { GridItemSpan(maxLineSpan) }) {
                            Text(
                                letter,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(start = 10.dp, top = 14.dp, bottom = 2.dp)
                            )
                        }
                        items(list, key = { it.key }) { app -> DrawerApp(vm, app, iconSize, themed, dotsOn, dotPkgs, launch) }
                    }
                } else {
                    items(filtered, key = { it.key }) { app -> DrawerApp(vm, app, iconSize, themed, dotsOn, dotPkgs, launch) }
                }
            }
            if (showSections && sections.size > 1) {
                LetterIndex(
                    letters = sections.map { it.first },
                    active = activeLetter,
                    onPick = { i -> scope.launch { gridState.scrollToItem(headerIdx[i]) } },
                    onActive = { activeLetter = it },
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 4.dp)
                )
            }
            activeLetter?.let { l ->
                Box(
                    Modifier.align(Alignment.Center).size(84.dp).clip(LocalIconShape.current)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(l, fontSize = 38.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            }

            TextField(
                value = query,
                onValueChange = vm::setQuery,
                placeholder = { Text(stringResource(R.string.search_apps)) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                shape = CircleShape,
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    filtered.firstOrNull()?.let { launch(it.key, null) }
                }),
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .imePadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .focusRequester(focusRequester)
            )
        }
    }
}

private fun letterOf(label: String): String {
    val c = label.trim().firstOrNull() ?: return "#"
    val u = c.uppercaseChar()
    return if (u.isLetter()) u.toString() else "#"
}

@Composable
private fun DrawerApp(
    vm: LauncherViewModel,
    app: AppInfo,
    iconSize: Int,
    themed: Boolean,
    dotsOn: Boolean,
    dotPkgs: Set<String>,
    launch: (String, androidx.compose.ui.geometry.Rect?) -> Unit
) {
    AppIcon(
        app = app,
        labelColor = MaterialTheme.colorScheme.onSurface,
        iconSize = iconSize.dp,
        themed = themed,
        dot = dotsOn && app.packageName in dotPkgs,
        onLaunch = { r -> launch(app.key, r) },
        menu = rememberMenu(
            vm, app,
            listOf(
                MenuAction(stringResource(R.string.add_to_home)) { vm.addToHome(app.key) },
                MenuAction(stringResource(R.string.add_to_dock)) { vm.addToDock(app.key) }
            )
        )
    )
}

/** Fast scroll bar with the letters: tap or slide a finger along it to jump to a letter. */
@Composable
private fun LetterIndex(
    letters: List<String>,
    active: String?,
    onPick: (Int) -> Unit,
    onActive: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    var h by remember { mutableIntStateOf(1) }
    val pick = { y: Float ->
        val i = ((y / h) * letters.size).toInt().coerceIn(0, letters.size - 1)
        onPick(i)
        onActive(letters[i])
    }
    Column(
        modifier
            .width(24.dp)
            .fillMaxHeight()
            .padding(vertical = 8.dp)
            .onSizeChanged { h = it.height.coerceAtLeast(1) }
            .pointerInput(letters) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    down.consume()
                    pick(down.position.y)
                    do {
                        val ev = awaitPointerEvent()
                        val c = ev.changes.firstOrNull()
                        if (c != null && c.pressed) { c.consume(); pick(c.position.y) }
                    } while (ev.changes.any { it.pressed })
                    onActive(null)
                }
            },
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        letters.forEach {
            Text(
                it, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                color = if (it == active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
