package com.youlauncher.app

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Shape
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/** Shapes the user can pick for app icons (like the Pixel "icon shape" setting). */
enum class IconShapeOption(val labelRes: Int) {
    CIRCLE(R.string.shape_circle),
    SQUIRCLE(R.string.shape_squircle),
    ROUNDED(R.string.shape_rounded),
    TEARDROP(R.string.shape_teardrop),
    FLOWER(R.string.shape_flower),
    SCALLOP(R.string.shape_scallop),
    SQUARE(R.string.shape_square),
    HEXAGON(R.string.shape_hexagon),
    CLOVER(R.string.shape_clover)
}

/** Closed curve described in polar form: radius(angle) in 0..1, scaled to the bounds. */
private fun polarShape(steps: Int = 360, radius: (Double) -> Double): Shape = GenericShape { size, _ ->
    val cx = size.width / 2f
    val cy = size.height / 2f
    for (i in 0..steps) {
        val t = 2.0 * Math.PI * i / steps
        val r = radius(t)
        val x = cx + cx * (r * cos(t)).toFloat()
        val y = cy + cy * (r * sin(t)).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

private val SquircleShape = polarShape { t ->
    (abs(cos(t)).pow(4.0) + abs(sin(t)).pow(4.0)).pow(-0.25)
}
private val FlowerShape = polarShape { t -> 0.88 + 0.12 * cos(8 * t) }
private val ScallopShape = polarShape { t -> 0.93 + 0.07 * cos(12 * t) }
private val SquareShape = RoundedCornerShape(percent = 14)
private val CloverShape = polarShape { t -> 0.86 + 0.14 * cos(4 * t) }
private val HexagonShape = GenericShape { size, _ ->
    val cx = size.width / 2f
    val cy = size.height / 2f
    for (i in 0 until 6) {
        val t = Math.PI / 3.0 * i - Math.PI / 2.0
        val x = cx + cx * 0.98f * cos(t).toFloat()
        val y = cy + cy * 0.98f * sin(t).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}
private val RoundedSquareShape = RoundedCornerShape(percent = 30)
private val TeardropShape = RoundedCornerShape(
    topStartPercent = 50, topEndPercent = 8, bottomEndPercent = 50, bottomStartPercent = 50
)

fun IconShapeOption.toShape(): Shape = when (this) {
    IconShapeOption.CIRCLE -> CircleShape
    IconShapeOption.SQUIRCLE -> SquircleShape
    IconShapeOption.ROUNDED -> RoundedSquareShape
    IconShapeOption.TEARDROP -> TeardropShape
    IconShapeOption.FLOWER -> FlowerShape
    IconShapeOption.SCALLOP -> ScallopShape
    IconShapeOption.SQUARE -> SquareShape
    IconShapeOption.HEXAGON -> HexagonShape
    IconShapeOption.CLOVER -> CloverShape
}

/** Current icon shape, provided once at the root. */
val LocalIconShape = staticCompositionLocalOf<Shape> { CircleShape }

/** Label size multiplier (settings: small / normal / large). */
val LocalLabelScale = staticCompositionLocalOf { 1f }

/** Opacity of the folder tile background, 0..1. */
val LocalFolderAlpha = staticCompositionLocalOf { 0.22f }
