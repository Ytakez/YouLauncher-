package com.youlauncher.app

import android.os.Build
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.clipPath
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Hold the fingerprint this long (ms) to unlock (the sensor is a fake: it only measures the hold). */
const val UNLOCK_HOLD_MS = 300

private val DarkInk = Color(0xFF1B1F2A)
private val TorchOn = Color(0xFFFFD866)

// ------------------------------------------------------------------------------------------------
// Settings -> config
// ------------------------------------------------------------------------------------------------

@Composable
fun rememberLockConfig(s: LauncherSettings): LockConfig {
    val clock by s.lockClock.collectAsStateWithLifecycle()
    val weight by s.lockWeight.collectAsStateWithLifecycle()
    val color by s.lockColor.collectAsStateWithLifecycle()
    val shape by s.lockShape.collectAsStateWithLifecycle()
    val wall by s.lockWall.collectAsStateWithLifecycle()
    val left by s.lockLeft.collectAsStateWithLifecycle()
    val right by s.lockRight.collectAsStateWithLifecycle()
    val notifOn by s.lockNotifOn.collectAsStateWithLifecycle()
    val layout by s.lockNotifLayout.collectAsStateWithLifecycle()
    val hide by s.lockHideText.collectAsStateWithLifecycle()
    val aodNotif by s.aodNotif.collectAsStateWithLifecycle()
    val depth by s.lockDepth.collectAsStateWithLifecycle()
    val swipe by s.lockSwipe.collectAsStateWithLifecycle()
    val bubble by s.lockBubble.collectAsStateWithLifecycle()
    val speed by s.animSpeed.collectAsStateWithLifecycle()
    return LockConfig(clock, weight, color, shape, wall, left, right, notifOn, layout, hide, aodNotif, depth, swipe, bubble, animSpeedFactor(speed))
}

// ------------------------------------------------------------------------------------------------
// Battery
// ------------------------------------------------------------------------------------------------

data class BatteryInfo(val level: Int, val charging: Boolean)

private fun parseBattery(i: Intent?): BatteryInfo {
    if (i == null) return BatteryInfo(100, false)
    val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
    val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
    return BatteryInfo(
        if (lvl >= 0 && scale > 0) lvl * 100 / scale else 100,
        st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    )
}

@Composable
fun rememberBattery(): BatteryInfo {
    val ctx = LocalContext.current
    var info by remember { mutableStateOf(parseBattery(ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)))) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { info = parseBattery(i) }
        }
        ContextCompat.registerReceiver(ctx, r, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { try { ctx.unregisterReceiver(r) } catch (_: Exception) {} }
    }
    return info
}

// ------------------------------------------------------------------------------------------------
// Vector glyphs drawn in code (the project only has the core icon set)
// ------------------------------------------------------------------------------------------------

@Composable
fun FingerprintGlyph(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = size.minDimension
        val sw = s * 0.07f
        val c = Offset(size.width / 2f, size.height / 2f + s * 0.02f)
        fun arc(r: Float, start: Float, sweep: Float) = drawArc(
            color, start, sweep, false,
            topLeft = Offset(c.x - r, c.y - r), size = Size(2 * r, 2 * r),
            style = Stroke(sw, cap = StrokeCap.Round)
        )
        arc(s * 0.44f, 205f, 130f)
        arc(s * 0.44f, 20f, 60f)
        arc(s * 0.33f, 190f, 160f)
        arc(s * 0.33f, 25f, 55f)
        arc(s * 0.22f, 180f, 180f)
        arc(s * 0.22f, 15f, 45f)
        arc(s * 0.11f, 200f, 140f)
        drawLine(color, Offset(c.x, c.y - s * 0.02f), Offset(c.x, c.y + s * 0.30f), sw, StrokeCap.Round)
        drawLine(color, Offset(c.x - s * 0.11f, c.y + s * 0.08f), Offset(c.x - s * 0.11f, c.y + s * 0.34f), sw, StrokeCap.Round)
        drawLine(color, Offset(c.x + s * 0.11f, c.y + s * 0.08f), Offset(c.x + s * 0.11f, c.y + s * 0.26f), sw, StrokeCap.Round)
    }
}

private fun DrawScope.drawShortcut(sc: LockShortcut, color: Color) {
    val u = size.minDimension / 24f
    val st = Stroke(2f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
    when (sc) {
        LockShortcut.NONE -> {
            drawCircle(color, radius = 8f * u, center = center, style = st)
            drawLine(color, Offset(6.5f * u, 17.5f * u), Offset(17.5f * u, 6.5f * u), 2f * u, StrokeCap.Round)
        }
        LockShortcut.TORCH -> {
            val head = Path().apply {
                moveTo(7f * u, 2f * u); lineTo(17f * u, 2f * u); lineTo(15f * u, 8f * u); lineTo(9f * u, 8f * u); close()
            }
            drawPath(head, color)
            drawRoundRect(color, Offset(9f * u, 9.5f * u), Size(6f * u, 12.5f * u), CornerRadius(2f * u))
        }
        LockShortcut.CAMERA -> {
            drawRoundRect(color, Offset(3f * u, 7f * u), Size(18f * u, 13f * u), CornerRadius(3f * u), style = st)
            drawCircle(color, radius = 3.4f * u, center = Offset(12f * u, 13.5f * u), style = st)
            val hump = Path().apply {
                moveTo(8.5f * u, 7f * u); lineTo(9.8f * u, 4.2f * u); lineTo(14.2f * u, 4.2f * u); lineTo(15.5f * u, 7f * u)
            }
            drawPath(hump, color, style = st)
        }
        LockShortcut.CALCULATOR -> {
            drawRoundRect(color, Offset(5f * u, 2.5f * u), Size(14f * u, 19f * u), CornerRadius(2.5f * u), style = st)
            drawRoundRect(color, Offset(8f * u, 5.5f * u), Size(8f * u, 3f * u), CornerRadius(0.8f * u))
            for (row in 0..2) for (col in 0..2) {
                drawCircle(color, 1.1f * u, Offset((8.5f + col * 3.5f) * u, (12f + row * 3.4f) * u))
            }
        }
        LockShortcut.MUTE -> {
            val bell = Path().apply {
                moveTo(6f * u, 17f * u); lineTo(6f * u, 11f * u)
                cubicTo(6f * u, 7f * u, 9f * u, 5f * u, 12f * u, 5f * u)
                cubicTo(15f * u, 5f * u, 18f * u, 7f * u, 18f * u, 11f * u)
                lineTo(18f * u, 17f * u)
                moveTo(4.5f * u, 17f * u); lineTo(19.5f * u, 17f * u)
            }
            drawPath(bell, color, style = st)
            drawLine(color, Offset(4f * u, 3.5f * u), Offset(20f * u, 21f * u), 2f * u, StrokeCap.Round)
        }
        LockShortcut.BLUETOOTH -> {
            val p = Path().apply {
                moveTo(7f * u, 7.5f * u); lineTo(17f * u, 16.5f * u); lineTo(12f * u, 21f * u)
                lineTo(12f * u, 3f * u); lineTo(17f * u, 7.5f * u); lineTo(7f * u, 16.5f * u)
            }
            drawPath(p, color, style = st)
        }
        LockShortcut.WIFI -> {
            val cx = 12f * u
            val cy = 19f * u
            for (r in floatArrayOf(14f, 9.5f, 5f)) {
                val rr = r * u
                drawArc(color, 227f, 86f, false, Offset(cx - rr, cy - rr), Size(2 * rr, 2 * rr), style = st)
            }
            drawCircle(color, 1.6f * u, Offset(cx, cy))
        }
        LockShortcut.DATA -> {
            val heights = floatArrayOf(5f, 9f, 13f, 18f)
            for (i in 0..3) {
                val h = heights[i] * u
                drawRoundRect(color, Offset((4f + i * 5f) * u, 21f * u - h), Size(3f * u, h), CornerRadius(1f * u))
            }
        }
    }
}

@Composable
fun ShortcutGlyph(sc: LockShortcut, color: Color, modifier: Modifier = Modifier.size(24.dp)) {
    Canvas(modifier) { drawShortcut(sc, color) }
}

// ------------------------------------------------------------------------------------------------
// Pieces of the screen
// ------------------------------------------------------------------------------------------------

/** The photo, placed the same way for the background layer and for the cut-out subject drawn over the clock. */
@Composable
private fun BoxScope.WallPic(bmp: ImageBitmap, shape: Boolean) {
    if (shape) {
        Image(
            bmp, null,
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = 70.dp)
                .fillMaxWidth(0.96f)
                .aspectRatio(0.95f)
                .clip(BlobShape),
            contentScale = ContentScale.Crop
        )
    } else {
        Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

/** Bubble geometry: centre and radius; reveal 0..1 grows the bubble to cover the whole screen. */
private fun bubbleGeometry(size: Size, reveal: Float): Pair<Offset, Float> {
    val c = Offset(size.width / 2f, size.height * 0.42f)
    val small = min(size.width, size.height) * 0.36f
    val full = hypot(max(c.x, size.width - c.x), max(c.y, size.height - c.y))
    val r = small + (full - small) * reveal.coerceIn(0f, 1f)
    return c to r
}

/**
 * Meizu-like wallpaper: the photo is blurred and darkened everywhere, and a big bubble in the
 * middle shows it sharp. On unlock the bubble swells until the sharp photo covers the screen.
 */
@Composable
private fun BubbleWall(bmp: ImageBitmap, reveal: Float, alpha: Float) {
    Box(Modifier.fillMaxSize().graphicsLayer { this.alpha = alpha }) {
        Image(
            bmp, null,
            Modifier.fillMaxSize().graphicsLayer {
                this.alpha = 1f - reveal
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    renderEffect = BlurEffect(36f, 36f, TileMode.Clamp)
                }
            },
            contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.42f * (1f - reveal))))
        Image(
            bmp, null,
            Modifier.fillMaxSize().drawWithContent {
                val (c, r) = bubbleGeometry(size, reveal)
                clipPath(Path().apply { addOval(Rect(c.x - r, c.y - r, c.x + r, c.y + r)) }) {
                    this@drawWithContent.drawContent()
                }
            },
            contentScale = ContentScale.Crop
        )
        Canvas(Modifier.fillMaxSize()) {
            val (c, r) = bubbleGeometry(size, reveal)
            drawCircle(
                Color.White.copy(alpha = 0.35f * (1f - reveal)),
                radius = r, center = c,
                style = Stroke(1.5.dp.toPx())
            )
        }
    }
}

@Composable
private fun LockBackdrop(cfg: LockConfig, alpha: Float, bmp: ImageBitmap?) {
    Box(Modifier.fillMaxSize().graphicsLayer { this.alpha = alpha }) {
        if (cfg.shape) {
            Box(Modifier.fillMaxSize().background(cfg.color.bg))
            if (bmp != null) WallPic(bmp, true)
        } else {
            Box(Modifier.fillMaxSize().background(Color(0xFF101218)))
            if (bmp != null) WallPic(bmp, false)
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Black.copy(0.30f), Color.Transparent, Color.Black.copy(0.45f)))
                )
            )
        }
    }
}

@Composable
private fun RoundButton(bg: Color, modifier: Modifier = Modifier, onClick: (() -> Unit)?, content: @Composable () -> Unit) {
    Box(
        modifier
            .size(56.dp)
            .clip(CircleShape)
            .background(bg)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun FingerprintButton(interactive: Boolean, bg: Color, fg: Color, onUnlock: () -> Unit) {
    val progress = remember { Animatable(0f) }
    val burst = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val unlock by rememberUpdatedState(onUnlock)
    val scan = Color(0xFF4C8DF6)
    val p = progress.value
    val wave by rememberInfiniteTransition(label = "fpWave").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing)),
        label = "fpWavePhase"
    )
    Box(
        Modifier
            .size(96.dp)
            .then(
                if (!interactive) Modifier else Modifier.pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        val job = scope.launch {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            progress.animateTo(1f, tween(UNLOCK_HOLD_MS, easing = LinearEasing))
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            burst.animateTo(1f, tween(280))
                            unlock()
                            delay(300)
                            burst.snapTo(0f)
                            progress.animateTo(0f, tween(250))
                        }
                        waitForUpOrCancellation()
                        if (progress.value < 1f) {
                            job.cancel()
                            scope.launch { progress.animateTo(0f, tween(180)) }
                        }
                    }
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        // pulses, progress ring and the success flash
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val base = 36.dp.toPx()
            val pr = progress.value
            if (interactive) {
                // rings keep spreading out from the finger, stronger while it is held
                for (k in 0..2) {
                    val t = (wave + k / 3f) % 1f
                    drawCircle(
                        scan,
                        radius = 30.dp.toPx() + 18.dp.toPx() * t,
                        center = c,
                        alpha = (0.30f + 0.30f * pr) * (1f - t),
                        style = Stroke(2.dp.toPx())
                    )
                }
            }
            val ringR = 44.dp.toPx()
            drawArc(
                scan, -90f, 360f * pr, false,
                topLeft = Offset(c.x - ringR, c.y - ringR), size = Size(2 * ringR, 2 * ringR),
                style = Stroke(4.dp.toPx(), cap = StrokeCap.Round)
            )
            val bu = burst.value
            if (bu > 0f) drawCircle(scan, radius = base + bu * 700.dp.toPx(), center = c, alpha = 0.45f * (1f - bu))
        }
        Box(
            Modifier
                .size(72.dp)
                .graphicsLayer {
                    val k = 1f + 0.12f * progress.value
                    scaleX = k
                    scaleY = k
                }
                .clip(CircleShape)
                .background(bg),
            contentAlignment = Alignment.Center
        ) {
            FingerprintGlyph(lerp(fg, scan, p), Modifier.size(40.dp))
            // scanner line sweeping over the finger print while it is held
            Canvas(Modifier.fillMaxSize()) {
                val pr = progress.value
                if (pr > 0f && pr < 1f) {
                    val y = size.height * (0.15f + 0.7f * pr)
                    drawLine(scan, Offset(size.width * 0.18f, y), Offset(size.width * 0.82f, y), 2.dp.toPx(), StrokeCap.Round)
                }
            }
        }
    }
}

@Composable
private fun NotifIcon(n: LockNotif, size: Dp) {
    val ctx = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx().coerceAtLeast(1) }
    val bmp = remember(n.key, px) {
        try { ctx.packageManager.getApplicationIcon(n.pkg).toBitmap(px, px).asImageBitmap() } catch (_: Throwable) { null }
    }
    if (bmp != null) {
        Image(bmp, null, Modifier.size(size).clip(CircleShape))
    } else {
        Box(Modifier.size(size).clip(CircleShape).background(Color(0xFF6C7BD6)), contentAlignment = Alignment.Center) {
            Text(n.title.take(1).uppercase(), color = Color.White, fontSize = (size.value * 0.45f).sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** Monochrome status-bar style icon, used by the always-on display. */
@Composable
private fun SmallGlyph(n: LockNotif, size: Dp, tint: Color) {
    val ctx = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx().coerceAtLeast(1) }
    val bmp = remember(n.key, px) {
        try { n.smallIcon?.loadDrawable(ctx)?.toBitmap(px, px)?.asImageBitmap() } catch (_: Throwable) { null }
    }
    if (bmp != null) {
        Image(bmp, null, Modifier.size(size), colorFilter = ColorFilter.tint(tint))
    } else {
        Box(Modifier.size(size * 0.45f).clip(CircleShape).background(tint))
    }
}

private fun timeText(t: Long): String =
    if (t <= 0L) "" else DateTimeFormatter.ofPattern("HH:mm")
        .format(Instant.ofEpochMilli(t).atZone(ZoneId.systemDefault()).toLocalTime())

@Composable
private fun LockNotifications(
    layout: LockNotifLayout,
    items: List<LockNotif>,
    hideText: Boolean,
    maxFull: Int,
    onClick: ((LockNotif) -> Unit)?,
    colors: LockColor = LockColor.WHITE
) {
    val hidden = stringResource(R.string.lock_hidden_content)
    val card = colors.cardColor()
    val ink = colors.cardInk()
    when (layout) {
        LockNotifLayout.MINIMAL -> Row(
            Modifier.clip(RoundedCornerShape(50)).background(card).padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.take(6).forEach { NotifIcon(it, 26.dp) }
            if (items.size > 6) Text("+${items.size - 6}", color = ink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        LockNotifLayout.COMPACT -> Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items.take(3).forEach { n ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(card)
                        .then(if (onClick != null) Modifier.clickable { onClick(n) } else Modifier)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NotifIcon(n, 26.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        n.title, color = ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (hideText) hidden else n.text, color = ink.copy(0.7f), fontSize = 12.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                    )
                }
            }
            if (items.size > 3) Text("+${items.size - 3}", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp))
        }

        LockNotifLayout.FULL -> Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items.take(maxFull).forEach { n ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(card)
                        .then(if (onClick != null) Modifier.clickable { onClick(n) } else Modifier)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NotifIcon(n, 36.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(n.title, color = ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (hideText) hidden else n.text, color = ink.copy(0.72f), fontSize = 13.sp,
                            maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                    val tt = timeText(n.time)
                    if (tt.isNotEmpty()) {
                        Spacer(Modifier.width(8.dp))
                        Text(tt, color = ink.copy(0.55f), fontSize = 11.sp)
                    }
                }
            }
            if (items.size > maxFull) Text("+${items.size - maxFull}", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp))
        }
    }
}

val SampleNotifs: List<LockNotif> = listOf(
    LockNotif("s1", "", "Telegram", "Your account has been banned", 0L, null),
    LockNotif("s2", "", "WhatsApp", "Message from Anna", 0L, null),
    LockNotif("s3", "", "Play Store", "10 apps are waiting for updates", 0L, null)
)

// ------------------------------------------------------------------------------------------------
// The whole screen. [aod] = 0 lock screen ... 1 always-on display (smooth morph in between).
// ------------------------------------------------------------------------------------------------

@Composable
fun LockScreenContent(
    cfg: LockConfig,
    aod: Float,
    interactive: Boolean,
    notifs: List<LockNotif>,
    modifier: Modifier = Modifier,
    torchOn: Boolean = false,
    muted: Boolean = false,
    shiftX: Dp = 0.dp,
    shiftY: Dp = 0.dp,
    onUnlock: () -> Unit = {},
    onShortcut: (LockShortcut) -> Unit = {},
    onNotif: (LockNotif) -> Unit = {},
    onWake: () -> Unit = {},
    onSleep: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val is24 = remember { android.text.format.DateFormat.is24HourFormat(ctx) }
    val top = cfg.clock.isTop()
    val now = rememberNow(everySecond = cfg.clock == LockClockStyle.DIGITAL && aod < 0.5f)
    val battery = rememberBattery()
    val day = now.toLocalDate()
    val dateShort = remember(day) { DateTimeFormatter.ofPattern("EEE, d MMM", Locale.getDefault()).format(day) }
    val dateLong = remember(day) { DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()).format(day) }
    val ink = cfg.color.clock
    val btnBg = cfg.color.buttonBg()
    val btnFg = cfg.color.buttonFg()
    val shown = if (notifs.isEmpty() && !interactive) SampleNotifs else notifs
    val wall = rememberLockWallpaper(cfg.wall)
    val cutout = rememberLockCutout(cfg.wall, cfg.depth)

    // swipe up to unlock: the whole screen follows the finger, the cut-out subject moves a bit more (depth)
    val drag = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var boxH by remember { mutableIntStateOf(1) }
    val unlockNow by rememberUpdatedState(onUnlock)
    // the bubble opens to the whole screen first, then the unlock goes through
    val reveal = remember { Animatable(0f) }
    fun startUnlock() {
        scope.launch {
            reveal.animateTo(1f, tween((520 * cfg.speedFactor).toInt(), easing = CubicBezierEasing(0.2f, 0f, 0f, 1f)))
            unlockNow()
            delay(400)
            reveal.snapTo(0f)
        }
    }
    val swipeOn = interactive && cfg.swipe && aod < 0.5f

    Box(
        modifier
            .background(Color.Black)
            .onSizeChanged { boxH = it.height.coerceAtLeast(1) }
            .then(
                if (!swipeOn) Modifier else Modifier.pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragEnd = {
                            scope.launch {
                                if (-drag.value > boxH * 0.2f) {
                                    drag.animateTo(-boxH * 0.35f, tween(160))
                                    startUnlock()
                                    delay(400)
                                    drag.animateTo(0f, tween(250))
                                } else {
                                    drag.animateTo(0f, spring())
                                }
                            }
                        },
                        onDragCancel = { scope.launch { drag.animateTo(0f, spring()) } },
                        onVerticalDrag = { change, amount ->
                            change.consume()
                            scope.launch { drag.snapTo((drag.value + amount).coerceIn(-boxH.toFloat(), 0f)) }
                        }
                    )
                }
            )
    ) {
        val insets = if (interactive) Modifier.windowInsetsPadding(WindowInsets.systemBars)
        else Modifier.padding(top = 26.dp, bottom = 10.dp)

        Box(
            Modifier.fillMaxSize().graphicsLayer {
                val pr = (-drag.value / boxH).coerceIn(0f, 1f)
                translationY = drag.value
                alpha = 1f - 0.7f * pr
                val sc = 1f - 0.05f * pr
                scaleX = sc
                scaleY = sc
            }
        ) {
            if (wall != null && cfg.bubble) BubbleWall(wall, reveal.value, 1f - aod)
            else LockBackdrop(cfg, 1f - aod, wall)

            // a tap on an empty spot of the lock screen sends it back to the always-on display
            if (interactive && aod < 0.5f) {
                Box(
                    Modifier.fillMaxSize().clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onSleep
                    )
                )
            }

            // clock and everything that sits above the photo's subject
            Column(
                Modifier.fillMaxWidth().then(insets).padding(horizontal = 24.dp).offset(shiftX, shiftY)
            ) {
                if (!top) {
                    Column(Modifier.padding(top = 4.dp)) {
                        Text(dateLong, color = ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text(
                            stringResource(R.string.lock_battery, battery.level),
                            color = ink.copy(alpha = 0.8f), fontSize = 13.sp,
                            modifier = Modifier.graphicsLayer { alpha = 1f - aod }
                        )
                    }
                }

                Box(
                    Modifier.fillMaxWidth().padding(top = if (top) 14.dp else 22.dp),
                    contentAlignment = if (top) Alignment.TopStart else Alignment.TopCenter
                ) {
                    LockClock(
                        style = cfg.clock, weight = cfg.weight, color = cfg.color, time = now, is24 = is24,
                        dateText = dateShort, aod = aod,
                        modifier = Modifier.graphicsLayer {
                            val sc = 1f - 0.30f * aod
                            scaleX = sc
                            scaleY = sc
                            transformOrigin = TransformOrigin(if (top) 0f else 0.5f, 0f)
                        }
                    )
                }

                // always-on display: notification glyphs right under the clock
                if (aod > 0.02f && cfg.aodNotif && shown.isNotEmpty()) {
                    Row(
                        Modifier.padding(top = 18.dp).graphicsLayer { alpha = aod },
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) { shown.take(6).forEach { SmallGlyph(it, 22.dp, ink) } }
                }
            }

            // depth effect: the subject of the photo is drawn again over the clock
            if (cfg.depth && cutout != null) {
                Box(
                    Modifier.fillMaxSize().graphicsLayer {
                        alpha = 1f - aod
                        translationY = drag.value * 0.12f
                    }
                ) { WallPic(cutout, cfg.shape) }
            }

            // lock screen only: fades out while the AOD takes over
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .then(insets)
                    .padding(horizontal = 24.dp)
                    .graphicsLayer { alpha = 1f - aod },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (cfg.notifOn && shown.isNotEmpty()) {
                    LockNotifications(
                        cfg.notifLayout, shown, cfg.hideText, if (top) 4 else 3,
                        if (interactive) onNotif else null,
                        cfg.color
                    )
                    Spacer(Modifier.height(14.dp))
                }
                FingerprintButton(interactive && aod < 0.5f, btnBg, btnFg, { startUnlock() })
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    ShortcutSlot(cfg.left, torchOn, muted, btnBg, btnFg, interactive && aod < 0.5f, onShortcut)
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Text(
                            if (battery.charging) stringResource(R.string.lock_charging, battery.level)
                            else stringResource(R.string.lock_hold_hint),
                            color = ink.copy(alpha = 0.85f), fontSize = 13.sp, maxLines = 2, textAlign = TextAlign.Center
                        )
                    }
                    ShortcutSlot(cfg.right, torchOn, muted, btnBg, btnFg, interactive && aod < 0.5f, onShortcut)
                }
                Spacer(Modifier.height(12.dp))
                Box(Modifier.width(110.dp).height(4.dp).clip(CircleShape).background(ink.copy(alpha = 0.75f)))
            }
        }

        // tap on the always-on display wakes the lock screen
        if (interactive && aod > 0.05f) {
            // a single touch anywhere on the always-on display opens the lock screen at once (on touch down, not on release)
            val wake by rememberUpdatedState(onWake)
            Box(
                Modifier.fillMaxSize().pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        down.consume()
                        wake()
                    }
                }
            )
        }
    }
}

@Composable
private fun ShortcutSlot(
    sc: LockShortcut,
    torchOn: Boolean,
    muted: Boolean,
    bg: Color,
    fg: Color,
    enabled: Boolean,
    onShortcut: (LockShortcut) -> Unit
) {
    if (sc == LockShortcut.NONE) {
        Spacer(Modifier.size(56.dp))
        return
    }
    val active = (sc == LockShortcut.TORCH && torchOn) || (sc == LockShortcut.MUTE && muted)
    RoundButton(if (active) TorchOn else bg, onClick = if (enabled) ({ onShortcut(sc) }) else null) {
        ShortcutGlyph(sc, if (active) DarkInk else fg, Modifier.size(24.dp))
    }
}

/** Phone-shaped live preview used in the settings (the real screen drawn on a smaller "virtual" display). */
@Composable
fun LockPreview(cfg: LockConfig, notifs: List<LockNotif>, aod: Float = 0f, width: Dp = 190.dp) {
    val conf = LocalConfiguration.current
    val screenW = conf.screenWidthDp.toFloat().coerceAtLeast(300f)
    val screenH = conf.screenHeightDp.toFloat().coerceAtLeast(500f)
    val ratio = (screenH / screenW).coerceIn(1.6f, 2.3f)
    val base = LocalDensity.current
    val scaled = Density(base.density * (width.value / screenW), base.fontScale)
    val shape = RoundedCornerShape(24.dp)
    Box(
        Modifier.width(width).height(width * ratio).clip(shape)
            .border(2.dp, Color.White.copy(alpha = 0.35f), shape)
    ) {
        CompositionLocalProvider(LocalDensity provides scaled) {
            LockScreenContent(cfg, aod, false, notifs, Modifier.fillMaxSize())
        }
    }
}
