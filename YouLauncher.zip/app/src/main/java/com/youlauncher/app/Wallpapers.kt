package com.youlauncher.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------
// Built-in wallpapers. They are drawn in code (gradient + soft light blobs + layered waves), so
// they are sharp at any resolution and add nothing to the APK size.
// ---------------------------------------------------------------------------------------------

internal class Blob(val x: Float, val y: Float, val r: Float, val color: Long)
internal class Wave(val y: Float, val amp: Float, val freq: Float, val phase: Float, val color: Long)

class WallpaperSpec private constructor(
    val id: String,
    private val top: Long,
    private val bottom: Long,
    private val blobs: List<Blob>,
    private val waves: List<Wave>
) {
    fun render(w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val wf = w.toFloat()
        val hf = h.toFloat()

        p.shader = LinearGradient(0f, 0f, wf * 0.45f, hf, top.toInt(), bottom.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, wf, hf, p)

        for (b in blobs) {
            val cx = b.x * wf
            val cy = b.y * hf
            val r = b.r * hf
            p.shader = RadialGradient(cx, cy, r, b.color.toInt(), (b.color and 0x00FFFFFFL).toInt(), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, p)
        }

        p.shader = null
        for (wv in waves) {
            val path = Path()
            val base = wv.y * hf
            path.moveTo(0f, base)
            var x = 0f
            val step = max(4f, wf / 90f)
            while (x <= wf + step) {
                val y = base + sin((x / wf) * 2f * PI.toFloat() * wv.freq + wv.phase) * wv.amp * hf
                path.lineTo(x, y)
                x += step
            }
            path.lineTo(wf, hf)
            path.lineTo(0f, hf)
            path.close()
            p.color = wv.color.toInt()
            c.drawPath(path, p)
        }
        return bmp
    }

    companion object {
        val all: List<WallpaperSpec> = listOf(
            // Sunset
            WallpaperSpec(
                "sunset", 0xFF2B1B4F, 0xFFFF8A5B,
                listOf(Blob(0.75f, 0.62f, 0.45f, 0xCCFFD27A), Blob(0.1f, 0.15f, 0.4f, 0x889B5DE5)),
                listOf(Wave(0.78f, 0.025f, 1.3f, 0.6f, 0x552B1B4F), Wave(0.88f, 0.03f, 0.9f, 2.2f, 0x992B1B4F))
            ),
            // Midnight
            WallpaperSpec(
                "midnight", 0xFF050B1F, 0xFF16336B,
                listOf(Blob(0.2f, 0.25f, 0.5f, 0x884C6FFF), Blob(0.9f, 0.8f, 0.45f, 0x6636D1DC)),
                emptyList()
            ),
            // Mint
            WallpaperSpec(
                "mint", 0xFFD7F7E6, 0xFF4CC9A0,
                listOf(Blob(0.85f, 0.12f, 0.5f, 0xAAFFFFFF), Blob(0.1f, 0.85f, 0.5f, 0x8800A884)),
                listOf(Wave(0.82f, 0.02f, 1.1f, 1.0f, 0x4400A884))
            ),
            // Lilac
            WallpaperSpec(
                "lilac", 0xFFEBD9FF, 0xFFB388FF,
                listOf(Blob(0.15f, 0.2f, 0.5f, 0xAAFFFFFF), Blob(0.85f, 0.75f, 0.5f, 0x88FF7EB6)),
                emptyList()
            ),
            // Ocean
            WallpaperSpec(
                "ocean", 0xFF0A2A66, 0xFF29B6F6,
                listOf(Blob(0.8f, 0.1f, 0.4f, 0x99FFFFFF)),
                listOf(
                    Wave(0.55f, 0.03f, 1.0f, 0.0f, 0x440A2A66),
                    Wave(0.70f, 0.035f, 1.4f, 1.8f, 0x660A2A66),
                    Wave(0.85f, 0.03f, 0.8f, 3.4f, 0x990A2A66)
                )
            ),
            // Dunes
            WallpaperSpec(
                "dunes", 0xFFFFE0B2, 0xFFFFA45C,
                listOf(Blob(0.7f, 0.2f, 0.35f, 0xCCFFF3D6)),
                listOf(
                    Wave(0.62f, 0.04f, 0.7f, 0.5f, 0x66C2672B),
                    Wave(0.76f, 0.04f, 0.9f, 2.4f, 0x99A5481B),
                    Wave(0.90f, 0.03f, 1.1f, 4.1f, 0xCC7A2E12)
                )
            ),
            // Aurora
            WallpaperSpec(
                "aurora", 0xFF03130F, 0xFF0B2D3A,
                listOf(
                    Blob(0.3f, 0.3f, 0.45f, 0xAA2EE59D),
                    Blob(0.75f, 0.45f, 0.4f, 0x884D7CFF),
                    Blob(0.5f, 0.75f, 0.4f, 0x66B04DFF)
                ),
                emptyList()
            ),
            // Graphite
            WallpaperSpec(
                "graphite", 0xFF1A1C1E, 0xFF3A3F45,
                listOf(Blob(0.85f, 0.15f, 0.45f, 0x33FFFFFF)),
                emptyList()
            ),
            // Rose
            WallpaperSpec(
                "rose", 0xFFFFD6E0, 0xFFFF6F91,
                listOf(Blob(0.2f, 0.8f, 0.5f, 0x99FFFFFF), Blob(0.9f, 0.25f, 0.4f, 0x88C2185B)),
                emptyList()
            )
        )
    }
}

/** Decodes a picked image, shrunk so that the longest side is at most [maxSide] px. */
private fun decodeUri(ctx: Context, uri: Uri, maxSide: Int = 2560): Bitmap? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    val longest = max(bounds.outWidth, bounds.outHeight)
    while (longest / sample > maxSide) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
} catch (_: Throwable) {
    null
}

@Composable
private fun rememberPreview(spec: WallpaperSpec): ImageBitmap? =
    produceState<ImageBitmap?>(null, spec.id) {
        value = withContext(Dispatchers.Default) { spec.render(270, 585).asImageBitmap() }
    }.value

@Composable
fun WallpapersScreen(vm: LauncherViewModel) {
    val ctx = LocalContext.current
    var target by remember { mutableStateOf(WallTarget.BOTH) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.applyWallpaper(target) { decodeUri(ctx, uri) }
    }

    fun applyBuiltIn(spec: WallpaperSpec) {
        val dm = ctx.resources.displayMetrics
        // render at the real screen size (capped so low-RAM phones do not run out of memory)
        val scale = min(1f, 1440f / dm.widthPixels)
        val w = (dm.widthPixels * scale).toInt()
        val h = (dm.heightPixels * scale).toInt()
        vm.applyWallpaper(target) { spec.render(w, h) }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.systemBars)
        ) {
            PageTopBar(stringResource(R.string.wallpaper), onBack = vm::closeOverlay)

            SingleChoiceSegmentedButtonRow(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                val options = listOf(
                    WallTarget.HOME to stringResource(R.string.wp_target_home),
                    WallTarget.LOCK to stringResource(R.string.wp_target_lock),
                    WallTarget.BOTH to stringResource(R.string.wp_target_both)
                )
                options.forEachIndexed { index, (value, label) ->
                    SegmentedButton(
                        selected = value == target,
                        onClick = { target = value },
                        shape = SegmentedButtonDefaults.itemShape(index = index, count = options.size),
                        label = { Text(label, maxLines = 1) }
                    )
                }
            }

            Text(
                stringResource(R.string.wp_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item(key = "gallery") {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(9f / 19.5f)
                            .clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.secondaryContainer)
                            .clickable { picker.launch("image/*") },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            stringResource(R.string.wp_gallery),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
                items(WallpaperSpec.all, key = { it.id }) { spec ->
                    val preview = rememberPreview(spec)
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(9f / 19.5f)
                            .clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                            .clickable { applyBuiltIn(spec) }
                    ) {
                        preview?.let {
                            Image(
                                bitmap = it,
                                contentDescription = spec.id,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }

            TextButton(
                onClick = vm::openWallpaperPicker,
                modifier = Modifier.padding(horizontal = 12.dp)
            ) { Text(stringResource(R.string.wp_system_picker)) }
        }
    }
}
