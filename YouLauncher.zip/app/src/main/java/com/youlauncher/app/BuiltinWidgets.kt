package com.youlauncher.app

import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.text.format.DateFormat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.WeekFields
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

/** Widgets drawn by the launcher itself. They live in the same ordered list as system widgets under negative ids. */
enum class Builtin(val id: Int, val labelRes: Int) {
    CLOCK(-1, R.string.bw_clock),
    ANALOG(-2, R.string.bw_analog),
    BATTERY(-3, R.string.bw_battery),
    CALENDAR(-4, R.string.bw_calendar),
    NOTE(-5, R.string.bw_note),
    GOOGLE(-6, R.string.bw_google);

    companion object {
        fun of(id: Int): Builtin? = entries.firstOrNull { it.id == id }
    }
}

@Composable
fun BuiltinWidgetItem(ctl: WidgetController, b: Builtin, radius: Dp) {
    when (b) {
        Builtin.CLOCK -> ClockWidget(radius)
        Builtin.ANALOG -> AnalogWidget(radius)
        Builtin.BATTERY -> BatteryWidget(radius)
        Builtin.CALENDAR -> CalendarWidget(radius)
        Builtin.NOTE -> NoteWidget(ctl, radius)
        Builtin.GOOGLE -> GoogleSearchWidget()
    }
}

@Composable
private fun WCard(
    radius: Dp,
    color: Color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.92f),
    content: @Composable BoxScope.() -> Unit
) {
    Surface(
        shape = RoundedCornerShape(radius),
        color = color,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Box(Modifier.padding(20.dp), content = content)
    }
}

@Composable
private fun rememberNow(everySecond: Boolean): LocalDateTime {
    val t by produceState(LocalDateTime.now(), everySecond) {
        while (true) {
            value = LocalDateTime.now()
            val now = System.currentTimeMillis()
            val wait = if (everySecond) 1000L - now % 1000L else 60_000L - now % 60_000L
            delay(wait.coerceAtLeast(50L))
        }
    }
    return t
}

// ---------------- digital clock ----------------
@Composable
private fun ClockWidget(radius: Dp) {
    val ctx = LocalContext.current
    val now = rememberNow(false)
    val is24 = DateFormat.is24HourFormat(ctx)
    val time = now.format(DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm", Locale.getDefault()))
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()))
    WCard(radius, MaterialTheme.colorScheme.primaryContainer) {
        Column {
            Text(
                time,
                fontSize = 76.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Text(
                date.replaceFirstChar { it.uppercase() },
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )
        }
    }
}

// ---------------- analog clock on a "cookie" shape ----------------
@Composable
private fun AnalogWidget(radius: Dp) {
    val now = rememberNow(true)
    val face = MaterialTheme.colorScheme.tertiaryContainer
    val hand = MaterialTheme.colorScheme.onTertiaryContainer
    val accent = MaterialTheme.colorScheme.primary
    val date = now.format(DateTimeFormatter.ofPattern("EEEE", Locale.getDefault()))
    val day = now.format(DateTimeFormatter.ofPattern("d MMMM", Locale.getDefault()))
    WCard(radius, MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.92f)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(150.dp)
                    .clip(IconShapeOption.SCALLOP.toShape())
                    .background(face)
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = center
                    val r = size.minDimension / 2f
                    fun pt(deg: Float, len: Float): Offset {
                        val a = Math.toRadians(deg.toDouble())
                        return Offset(c.x + len * sin(a).toFloat(), c.y - len * cos(a).toFloat())
                    }
                    for (i in 0 until 12) {
                        drawCircle(hand.copy(alpha = 0.55f), 2.5.dp.toPx(), pt(i * 30f, r * 0.8f))
                    }
                    val h = (now.hour % 12 + now.minute / 60f) * 30f
                    val m = (now.minute + now.second / 60f) * 6f
                    val s = now.second * 6f
                    drawLine(hand, c, pt(h, r * 0.42f), 9.dp.toPx(), StrokeCap.Round)
                    drawLine(hand, c, pt(m, r * 0.62f), 6.dp.toPx(), StrokeCap.Round)
                    drawCircle(accent, 5.dp.toPx(), pt(s, r * 0.68f))
                    drawCircle(hand, 6.dp.toPx(), c)
                }
            }
            Spacer(Modifier.width(20.dp))
            Column {
                Text(
                    date.replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    day,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ---------------- battery ----------------
private data class BatteryState(val percent: Int, val charging: Boolean)

@Composable
private fun BatteryWidget(radius: Dp) {
    val ctx = LocalContext.current
    val st by produceState(BatteryState(0, false)) {
        while (true) {
            val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
                value = BatteryState(
                    pct,
                    status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
                )
            }
            delay(20_000)
        }
    }
    WCard(radius, MaterialTheme.colorScheme.secondaryContainer) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { st.percent / 100f },
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.primary,
                    strokeWidth = 10.dp,
                    trackColor = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.15f)
                )
                Text(
                    "${st.percent}%",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
            Spacer(Modifier.width(20.dp))
            Column {
                Text(
                    stringResource(R.string.bw_battery),
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
                Text(
                    stringResource(if (st.charging) R.string.battery_charging else R.string.battery_discharging),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.75f)
                )
            }
        }
    }
}

// ---------------- month calendar ----------------
@Composable
private fun CalendarWidget(radius: Dp) {
    val today = rememberNow(false).toLocalDate()
    val locale = Locale.getDefault()
    val ym = YearMonth.from(today)
    val firstDow: DayOfWeek = WeekFields.of(locale).firstDayOfWeek
    val offset = (ym.atDay(1).dayOfWeek.value - firstDow.value + 7) % 7
    val days = ym.lengthOfMonth()
    val rows = (offset + days + 6) / 7
    val title = today.format(DateTimeFormatter.ofPattern("LLLL yyyy", locale))
    WCard(radius) {
        Column(Modifier.fillMaxWidth()) {
            Text(
                title.replaceFirstChar { it.uppercase() },
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Row(Modifier.fillMaxWidth()) {
                for (i in 0 until 7) {
                    Text(
                        firstDow.plus(i.toLong()).getDisplayName(TextStyle.NARROW, locale),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
            for (r in 0 until rows) {
                Row(Modifier.fillMaxWidth()) {
                    for (c in 0 until 7) {
                        val d = r * 7 + c - offset + 1
                        val isToday = d == today.dayOfMonth
                        Box(
                            Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .padding(2.dp)
                                .clip(CircleShape)
                                .background(if (isToday) MaterialTheme.colorScheme.primary else Color.Transparent),
                            contentAlignment = Alignment.Center
                        ) {
                            if (d in 1..days) {
                                Text(
                                    d.toString(),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isToday) MaterialTheme.colorScheme.onPrimary
                                    else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- sticky note ----------------
@Composable
private fun NoteWidget(ctl: WidgetController, radius: Dp) {
    val note by ctl.note.collectAsStateWithLifecycle()
    WCard(radius, MaterialTheme.colorScheme.tertiaryContainer) {
        Box(Modifier.fillMaxWidth().heightIn(min = 96.dp)) {
            if (note.isEmpty()) {
                Text(
                    stringResource(R.string.bw_note_hint),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.6f)
                )
            }
            BasicTextField(
                value = note,
                onValueChange = ctl::setNote,
                textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onTertiaryContainer),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ---------------- Google search pill ----------------
private fun openGoogle(ctx: android.content.Context) {
    val i = ctx.packageManager.getLaunchIntentForPackage("com.google.android.googlequicksearchbox")
        ?: Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com"))
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try { ctx.startActivity(i) } catch (_: Exception) {}
}

@Composable
private fun GoogleSearchWidget() {
    val ctx = LocalContext.current
    val g = androidx.compose.ui.text.buildAnnotatedString {
        fun letter(c: Long, t: String) {
            pushStyle(androidx.compose.ui.text.SpanStyle(color = Color(c), fontWeight = FontWeight.Bold))
            append(t); pop()
        }
        letter(0xFF4285F4, "G")
    }
    Surface(
        onClick = { openGoogle(ctx) },
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.94f),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).heightIn(min = 56.dp)
    ) {
        Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(g, fontSize = 26.sp)
            Spacer(Modifier.width(14.dp))
            Text(
                stringResource(R.string.google_hint),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
