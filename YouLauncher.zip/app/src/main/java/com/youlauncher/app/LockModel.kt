package com.youlauncher.app

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import kotlinx.coroutines.flow.MutableStateFlow

/** Clock designs of the lock screen (like Pixel "Clock" picker). */
enum class LockClockStyle { STACKED, NUMERALS, DIGITAL, OUTLINE, VERTICAL }

/** Clock color + tint of the background that goes with it (used by the "shaped photo" look). */
enum class LockColor(val clock: Color, val bg: Color) {
    WHITE(Color(0xFFFFFFFF), Color(0xFF1B2030)),
    SLATE(Color(0xFFC9D0E4), Color(0xFF59668F)),
    SKY(Color(0xFFD4E8FF), Color(0xFF3F6FA6)),
    MINT(Color(0xFFD6F6E3), Color(0xFF3C7A5E)),
    SAGE(Color(0xFFE1EBC8), Color(0xFF5F7A3C)),
    SAND(Color(0xFFF8E6B8), Color(0xFF8C6D2E)),
    ROSE(Color(0xFFFFD9DF), Color(0xFF9E4B5C)),
    LAVENDER(Color(0xFFE6DEFF), Color(0xFF6A5BA8)),
    PEACH(Color(0xFFFFDCC8), Color(0xFFA8643C)),
    AQUA(Color(0xFFCFF3F4), Color(0xFF2F7F86)),
    BLACK(Color(0xFF14161C), Color(0xFFE8EAF2))
}

enum class LockShortcut(val labelRes: Int) {
    NONE(R.string.sc_none),
    TORCH(R.string.sc_torch),
    CAMERA(R.string.sc_camera),
    CALCULATOR(R.string.sc_calculator),
    MUTE(R.string.sc_mute),
    BLUETOOTH(R.string.sc_bluetooth),
    WIFI(R.string.sc_wifi),
    DATA(R.string.sc_data)
}

enum class LockNotifLayout { MINIMAL, COMPACT, FULL }

/** How long the always-on display stays lit. FOREVER = until the power button is pressed. */
enum class AodDuration(val seconds: Int) { S15(15), S60(60), M5(300), FOREVER(0) }

/** NONE = nothing shown, LOCK = lock screen, AOD = always-on display, SLEEP = screen is off (activity kept for the next wake). */
enum class LockMode { NONE, LOCK, AOD, SLEEP }

object LockState {
    val mode = MutableStateFlow(LockMode.NONE)
    /** Set by the service right before it starts the AOD, so the "screen on" it causes is ignored. */
    @Volatile var pendingAod = false
    /** AOD time is over: the screen is no longer held on and will turn off by itself. */
    @Volatile var aodExpired = false
}

/** Everything the lock screen UI needs to know about the user's choices. */
data class LockConfig(
    val clock: LockClockStyle = LockClockStyle.STACKED,
    val weight: Int = 4,
    val color: LockColor = LockColor.WHITE,
    val shape: Boolean = true,
    val wall: String = "",
    val left: LockShortcut = LockShortcut.TORCH,
    val right: LockShortcut = LockShortcut.CAMERA,
    val notifOn: Boolean = true,
    val notifLayout: LockNotifLayout = LockNotifLayout.COMPACT,
    val hideText: Boolean = false,
    val aodNotif: Boolean = true,
    val depth: Boolean = false,
    val swipe: Boolean = true
)

fun LockClockStyle.isTop(): Boolean =
    this == LockClockStyle.DIGITAL || this == LockClockStyle.OUTLINE || this == LockClockStyle.VERTICAL

// ---- Material 3 tonal surfaces of the lock screen: cards and buttons take a soft tint of the chosen color ----
private val LockInk = Color(0xFF1B1F2A)
private fun LockColor.neutral() = this == LockColor.WHITE || this == LockColor.BLACK

/** Notification card background. */
fun LockColor.cardColor(): Color =
    if (neutral()) Color.White.copy(alpha = 0.90f) else lerp(Color.White, clock, 0.45f).copy(alpha = 0.92f)

/** Text color on cards and buttons. */
fun LockColor.cardInk(): Color = if (neutral()) LockInk else lerp(LockInk, bg, 0.45f)

fun LockColor.buttonBg(): Color = when (this) {
    LockColor.BLACK -> Color(0xFF14161C)
    LockColor.WHITE -> Color.White.copy(alpha = 0.94f)
    else -> lerp(Color.White, clock, 0.55f).copy(alpha = 0.95f)
}

fun LockColor.buttonFg(): Color = if (this == LockColor.BLACK) Color.White else cardInk()
