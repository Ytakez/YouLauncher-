package com.youlauncher.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow

object NotificationDots {
    val packages = MutableStateFlow<Set<String>>(emptySet())
}

class DotsService : NotificationListenerService() {
    override fun onListenerConnected() = refresh()
    override fun onNotificationPosted(sbn: StatusBarNotification?) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refresh()
    override fun onListenerDisconnected() { NotificationDots.packages.value = emptySet() }

    private fun refresh() {
        try {
            NotificationDots.packages.value = activeNotifications
                .filter { !it.isOngoing }
                .map { it.packageName }
                .toSet()
        } catch (_: Exception) {}
    }
}
