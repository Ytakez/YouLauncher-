package com.youlauncher.app

import android.app.Notification
import android.app.PendingIntent
import android.graphics.drawable.Icon
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow

/** A notification as the lock screen shows it. [pkg] may be empty for sample data. */
class LockNotif(
    val key: String,
    val pkg: String,
    val title: String,
    val text: String,
    val time: Long,
    val intent: PendingIntent?,
    val smallIcon: Icon? = null
)

object NotificationDots {
    val packages = MutableStateFlow<Set<String>>(emptySet())
    /** Newest first. Used by the lock screen and the always-on display. */
    val items = MutableStateFlow<List<LockNotif>>(emptyList())
}

class DotsService : NotificationListenerService() {
    override fun onListenerConnected() = refresh()
    override fun onNotificationPosted(sbn: StatusBarNotification?) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refresh()
    override fun onListenerDisconnected() {
        NotificationDots.packages.value = emptySet()
        NotificationDots.items.value = emptyList()
    }

    private fun refresh() {
        try {
            val active = activeNotifications.filter { !it.isOngoing }
            NotificationDots.packages.value = active.map { it.packageName }.toSet()
            NotificationDots.items.value = active
                .filter { (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 }
                .filter { it.packageName != packageName }
                .sortedByDescending { it.postTime }
                .map { sbn ->
                    val ex = sbn.notification.extras
                    val title = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
                    val text = (ex?.getCharSequence(Notification.EXTRA_TEXT)
                        ?: ex?.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString().orEmpty()
                    LockNotif(sbn.key, sbn.packageName, title, text, sbn.postTime, sbn.notification.contentIntent, sbn.notification.smallIcon)
                }
        } catch (_: Exception) {}
    }
}
