package com.youlauncher.app

import android.app.ActivityOptions
import android.app.WallpaperManager
import android.graphics.Bitmap
import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.net.Uri
import android.os.Build
import android.os.Process
import android.os.UserHandle
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.compose.ui.geometry.Rect
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Overlay { SETTINGS, WIDGETS, WALLPAPERS, LOCKSCREEN }

enum class WallTarget { HOME, LOCK, BOTH }

/** State of the built-in launch animation (icon expands into a full-screen surface). */
data class LaunchAnim(val key: String, val rect: Rect, val id: Long = System.nanoTime())

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val ctx: Context = application.applicationContext
    private val pm: PackageManager = ctx.packageManager
    private val prefs = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    private val launcherApps: LauncherApps = ctx.getSystemService(LauncherApps::class.java)

    val settings = LauncherSettings(prefs)
    val widgets = WidgetController(ctx, prefs)

    // ---------- apps / dock / home ----------
    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps.asStateFlow()

    private val dockKeys = MutableStateFlow(readList("dock"))
    private val _items = MutableStateFlow(readLayout())
    /** Everything on the home pages: apps and folders with their page / column / row. */
    val homeItems: StateFlow<List<HomeItem>> = _items.asStateFlow()

    // grid size last reported by the UI (needed to place items from the ViewModel)
    private var gCols = 5
    private var gRows = 6
    private var gBlocked = 0
    private val usage = MutableStateFlow(readUsage())

    val dockApps: StateFlow<List<AppInfo>> =
        combine(_apps, dockKeys) { apps, keys -> keys.mapNotNull { k -> apps.firstOrNull { it.key == k } } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val suggestions: StateFlow<List<AppInfo>> =
        combine(_apps, usage) { apps, u ->
            apps.filter { (u[it.key] ?: 0) > 0 }.sortedByDescending { u[it.key] ?: 0 }.take(4)
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---------- drawer / overlays / launch animation ----------
    private val _drawerOpen = MutableStateFlow(false)
    val drawerOpen: StateFlow<Boolean> = _drawerOpen.asStateFlow()

    private val _focusSearch = MutableStateFlow(false)
    val focusSearch: StateFlow<Boolean> = _focusSearch.asStateFlow()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _overlay = MutableStateFlow<Overlay?>(null)
    val overlay: StateFlow<Overlay?> = _overlay.asStateFlow()

    private val _launchAnim = MutableStateFlow<LaunchAnim?>(null)
    val launchAnim: StateFlow<LaunchAnim?> = _launchAnim.asStateFlow()

    fun openDrawer() {
        if (!settings.drawerEnabled.value) return // no app list: swipe up does nothing
        _focusSearch.value = false; _drawerOpen.value = true
    }
    fun openSearch() { _focusSearch.value = true; _drawerOpen.value = true }
    fun closeDrawer() { _drawerOpen.value = false; _focusSearch.value = false; _query.value = "" }
    fun setQuery(q: String) { _query.value = q }
    fun openOverlay(o: Overlay) { _overlay.value = o }
    fun closeOverlay() { _overlay.value = null }

    private val appsCallback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) {
            // only a real uninstall removes the icon from the saved layout
            packageName?.let { removePackage(it) }
            refreshApps()
        }
        override fun onPackageAdded(packageName: String?, user: UserHandle?) { refreshApps() }
        override fun onPackageChanged(packageName: String?, user: UserHandle?) { refreshApps() }
        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) { refreshApps() }
        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) { refreshApps() }
    }

    init {
        try { launcherApps.registerCallback(appsCallback) } catch (_: Exception) {}
    }

    override fun onCleared() {
        try { launcherApps.unregisterCallback(appsCallback) } catch (_: Exception) {}
        super.onCleared()
    }

    fun refreshApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(intent, 0)
                .map {
                    AppInfo(
                        it.loadLabel(pm).toString(),
                        ComponentName(it.activityInfo.packageName, it.activityInfo.name).flattenToString()
                    )
                }
                .filter { !it.key.startsWith(ctx.packageName + "/") }
                .distinctBy { it.key }
                .sortedBy { it.label.lowercase() }

            if (list.isEmpty()) return@launch

            if (!prefs.getBoolean("init", false)) {
                val dock = defaultDock(list)
                dockKeys.value = dock
                _items.value = list.map { it.key }.filter { it !in dock }.take(8).map { HomeItem.app(it) }
                prefs.edit().putBoolean("init", true).apply()
            }
            // no app list: every (new) app goes straight to the home screen
            if (!settings.drawerEnabled.value) addMissingToHome(list, onlyNew = true)
            // Saved layout is never pruned here: apps that are temporarily missing (updating,
            // SD card, work profile paused) are just hidden and come back on their old spot.
            save()
            _apps.value = list
        }
    }

    private fun defaultDock(apps: List<AppInfo>): List<String> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        return intents
            .mapNotNull { pm.queryIntentActivities(it, PackageManager.MATCH_DEFAULT_ONLY).firstOrNull()?.activityInfo?.packageName }
            .distinct()
            .mapNotNull { pkg -> apps.firstOrNull { it.packageName == pkg }?.key }
            .take(4)
    }

    /** Turns the app list on/off. Off: closes it and puts every app that is not on the home screen / dock onto the home screen. */
    fun setDrawerEnabled(v: Boolean) {
        settings.setDrawerEnabled(v)
        if (!v) {
            closeDrawer()
            addMissingToHome(_apps.value, onlyNew = false)
        }
    }

    /** onlyNew: add just the apps installed since the last time (so removing an icon from home stays possible). */
    private fun addMissingToHome(list: List<AppInfo>, onlyNew: Boolean) {
        val seen = prefs.getStringSet("seenApps", null) ?: emptySet()
        val add = list.filter { a ->
            a.key !in dockKeys.value && !inHome(a.key) && (!onlyNew || a.key !in seen)
        }
        if (add.isNotEmpty()) _items.value = _items.value + add.map { HomeItem.app(it.key) }
        prefs.edit().putStringSet("seenApps", list.map { it.key }.toSet()).apply()
        save()
    }

    private fun inHome(key: String): Boolean =
        _items.value.any { it.appKey == key || key in it.keys }

    fun addToHome(key: String) {
        dockKeys.value = dockKeys.value - key
        if (!inHome(key)) _items.value = _items.value + HomeItem.app(key)
        save(); closeDrawer()
    }

    fun addToDock(key: String) {
        if (key in dockKeys.value) { closeDrawer(); return }
        if (dockKeys.value.size >= 4) {
            Toast.makeText(ctx, R.string.dock_full, Toast.LENGTH_SHORT).show()
            return
        }
        _items.value = stripKeys(_items.value) { it == key }
        dockKeys.value = dockKeys.value + key
        save(); closeDrawer()
    }

    private fun removePackage(pkg: String) {
        dockKeys.value = dockKeys.value.filter { it.substringBefore('/') != pkg }
        _items.value = stripKeys(_items.value) { it.substringBefore('/') == pkg }
        save()
    }

    fun unpin(key: String) {
        dockKeys.value = dockKeys.value - key
        _items.value = stripKeys(_items.value) { it == key }
        save()
    }

    // ---------- home grid: free placement, folders, pages ----------
    private fun cellKey(page: Int, col: Int, row: Int): Long = page * 1_000_000L + row * 1000L + col

    /**
     * Makes the saved layout valid for the current grid: every item gets a free cell, nothing overlaps,
     * nothing sits under the widget header (page 0) or outside the grid. Unplaced items take the first free cell.
     * Does nothing (and writes nothing) when the layout is already valid.
     */
    fun normalizeHome(cols: Int, rows: Int, blocked: Int, priority: String? = null) {
        gCols = cols; gRows = rows; gBlocked = blocked
        val cur = _items.value
        val order = cur.sortedWith(
            compareBy<HomeItem>(
                { if (it.id == priority) 0 else 1 },
                { if (it.col < 0 || it.page < 0) 1 else 0 },
                { it.page }, { it.row }, { it.col }
            )
        )
        val occ = HashSet<Long>()
        fun fits(page: Int, col: Int, row: Int, s: Int): Boolean {
            if (col < 0 || row < 0 || col + s > cols || row + s > rows) return false
            if (page == 0 && row < blocked) return false
            for (r in row until row + s) for (c in col until col + s) if (occ.contains(cellKey(page, c, r))) return false
            return true
        }
        fun take(page: Int, col: Int, row: Int, s: Int) {
            for (r in row until row + s) for (c in col until col + s) occ.add(cellKey(page, c, r))
        }
        val placed = HashMap<String, HomeItem>()
        for (item in order) {
            val s = item.spanFor(cols, rows)
            var pg = item.page
            var cl = item.col
            var rw = item.row
            var ok = false
            if (pg >= 0 && cl >= 0 && rw >= 0) {
                cl = minOf(cl, cols - s)
                rw = minOf(rw, rows - s)
                ok = fits(pg, cl, rw, s)
            }
            if (!ok) {
                var found = false
                var p = maxOf(item.page, 0)
                while (!found && p < 60) {
                    val minRow = if (p == 0) blocked else 0
                    var r = minRow
                    while (!found && r + s <= rows) {
                        var c = 0
                        while (!found && c + s <= cols) {
                            if (fits(p, c, r, s)) { pg = p; cl = c; rw = r; found = true }
                            c++
                        }
                        r++
                    }
                    if (!found) p++
                }
                if (!found) { pg = p; cl = 0; rw = 0 }
            }
            take(pg, cl, rw, s)
            placed[item.id] = item.copy(page = pg, col = cl, row = rw)
        }
        val result = cur.map { placed[it.id] ?: it }
        if (result != cur) {
            _items.value = result
            save()
        }
    }

    /** Drag & drop: put [id] on (page, col, row); if the cell is taken the nearest free one is used. */
    fun moveItem(id: String, page: Int, col: Int, row: Int) {
        val list = _items.value
        val me = list.firstOrNull { it.id == id } ?: return
        val s = me.spanFor(gCols, gRows)
        val occ = HashSet<Long>()
        for (o in list) {
            if (o.id == id || o.page < 0 || o.col < 0) continue
            val os = o.spanFor(gCols, gRows)
            for (r in o.row until o.row + os) for (c in o.col until o.col + os) occ.add(cellKey(o.page, c, r))
        }
        val minRow = if (page == 0) gBlocked else 0
        var best: Pair<Int, Int>? = null
        var bestD = Int.MAX_VALUE
        for (r in minRow..(gRows - s)) {
            for (c in 0..(gCols - s)) {
                var free = true
                for (rr in r until r + s) for (cc in c until c + s) if (occ.contains(cellKey(page, cc, rr))) free = false
                if (!free) continue
                val d = Math.abs(c - col) + Math.abs(r - row)
                if (d < bestD) { bestD = d; best = c to r }
            }
        }
        val b = best ?: return
        _items.value = list.map { if (it.id == id) it.copy(page = page, col = b.first, row = b.second) else it }
        compactPages()
        save()
    }

    /** Dropping an app on another app makes a folder; dropping it on a folder adds it there. */
    fun mergeInto(dragId: String, targetId: String) {
        val list = _items.value
        val d = list.firstOrNull { it.id == dragId } ?: return
        val t = list.firstOrNull { it.id == targetId } ?: return
        if (d.isFolder || d.id == t.id) return
        val dk = d.appKey ?: return
        val merged: HomeItem = if (t.isFolder) {
            t.copy(keys = if (dk in t.keys) t.keys else t.keys + dk)
        } else {
            HomeItem(
                id = "f:${System.nanoTime()}",
                page = t.page, col = t.col, row = t.row,
                appKey = null,
                name = ctx.getString(R.string.folder_default_name),
                size = FolderSize.NORMAL,
                keys = listOf(t.appKey!!, dk)
            )
        }
        _items.value = list.filter { it.id != dragId }.map { if (it.id == targetId) merged else it }
        compactPages()
        save()
    }

    fun updateFolder(id: String, name: String, size: FolderSize) {
        val list = _items.value
        val f = list.firstOrNull { it.id == id && it.isFolder } ?: return
        val sizeChanged = f.size != size
        _items.value = list.map { if (it.id == id) it.copy(name = name, size = size) else it }
        save()
        if (sizeChanged) normalizeHome(gCols, gRows, gBlocked, priority = id)
    }

    fun renameFolder(id: String, name: String) {
        _items.value = _items.value.map { if (it.id == id && it.isFolder) it.copy(name = name) else it }
        save()
    }

    fun deleteFolder(id: String) {
        val list = _items.value
        val f = list.firstOrNull { it.id == id && it.isFolder } ?: return
        _items.value = list.filter { it.id != id } + f.keys.map { HomeItem.app(it, page = f.page) }
        save()
    }

    fun removeFromFolder(folderId: String, key: String) {
        val list = _items.value
        val f = list.firstOrNull { it.id == folderId && it.isFolder } ?: return
        _items.value = stripKeys(list) { it == key } + HomeItem.app(key, page = f.page)
        save()
    }

    /** Pages that became empty disappear, the others are renumbered. */
    private fun compactPages() {
        val used = _items.value.filter { it.page >= 0 }.map { it.page }.distinct().sorted()
        if (used.isEmpty() || used == used.indices.toList()) return
        val map = used.withIndex().associate { (i, p) -> p to i }
        _items.value = _items.value.map { if (it.page >= 0) it.copy(page = map[it.page] ?: it.page) else it }
    }

    // ---------- launching ----------
    /** Entry point for every app tap. */
    fun launch(key: String, rect: Rect?, view: View?) {
        bumpUsage(key)
        val mode = settings.animMode.value
        if (mode == AnimMode.CUSTOM && rect != null) {
            // built-in Material You animation: overlay animates, then calls commitLaunch()
            _launchAnim.value = LaunchAnim(key, rect)
        } else {
            start(key, rect, view, if (mode == AnimMode.OFF) AnimMode.OFF else AnimMode.SYSTEM)
            closeDrawer()
        }
    }

    fun commitLaunch(a: LaunchAnim) {
        start(a.key, null, null, AnimMode.CUSTOM)
        closeDrawer()
    }

    fun endLaunch() { _launchAnim.value = null }

    private fun start(key: String, rect: Rect?, view: View?, mode: AnimMode) {
        val cn = ComponentName.unflattenFromString(key) ?: run { endLaunch(); return }
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(cn)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val opts: ActivityOptions? = try {
            when {
                mode == AnimMode.OFF -> ActivityOptions.makeCustomAnimation(ctx, 0, 0)
                mode == AnimMode.CUSTOM -> ActivityOptions.makeCustomAnimation(ctx, android.R.anim.fade_in, 0)
                view != null && rect != null -> ActivityOptions.makeClipRevealAnimation(
                    view, rect.left.toInt(), rect.top.toInt(), rect.width.toInt(), rect.height.toInt()
                )
                else -> null
            }
        } catch (_: Exception) { null }
        try {
            ctx.startActivity(i, opts?.toBundle())
        } catch (_: Exception) {
            endLaunch()
        }
    }

    // ---------- shortcuts / system actions ----------
    fun shortcutActions(pkg: String): List<MenuAction> {
        return try {
            if (!launcherApps.hasShortcutHostPermission()) return emptyList()
            val q = LauncherApps.ShortcutQuery()
                .setPackage(pkg)
                .setQueryFlags(
                    LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
                )
            (launcherApps.getShortcuts(q, Process.myUserHandle()) ?: emptyList())
                .filter { it.isEnabled }
                .take(4)
                .map { s -> MenuAction(shortcutLabel(s)) { startShortcut(s) } }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun shortcutLabel(s: ShortcutInfo): String =
        s.shortLabel?.toString() ?: s.longLabel?.toString() ?: s.id

    private fun startShortcut(s: ShortcutInfo) {
        try {
            launcherApps.startShortcut(s.`package`, s.id, null, null, Process.myUserHandle())
        } catch (_: Exception) {}
    }

    fun openAppInfo(pkg: String) {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(Uri.fromParts("package", pkg, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {}
    }

    fun uninstall(pkg: String) {
        val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {}
    }

    fun expandNotifications() {
        try {
            val sb = ctx.getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
        } catch (_: Throwable) {}
    }

    /** Builds the bitmap off the main thread and sets it as the wallpaper. */
    fun applyWallpaper(target: WallTarget, make: () -> Bitmap?) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = try {
                val bmp = make() ?: throw IllegalStateException("no bitmap")
                val wm = WallpaperManager.getInstance(ctx)
                val flags = when (target) {
                    WallTarget.HOME -> WallpaperManager.FLAG_SYSTEM
                    WallTarget.LOCK -> WallpaperManager.FLAG_LOCK
                    WallTarget.BOTH -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                }
                wm.setBitmap(bmp, null, true, flags)
                true
            } catch (_: Throwable) {
                false
            }
            withContext(Dispatchers.Main) {
                Toast.makeText(ctx, if (ok) R.string.wp_set_ok else R.string.wp_set_fail, Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun openWallpaperPicker() {
        val i = Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), ctx.getString(R.string.wallpaper))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {}
    }

    fun openDefaultLauncherSettings() {
        val i = Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {
            try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
    }

    fun openNotificationAccess() {
        val i = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {}
    }

    // ---------- persistence ----------
    private fun bumpUsage(key: String) {
        val cur = usage.value
        usage.value = cur + (key to ((cur[key] ?: 0) + 1))
        prefs.edit().putString("usage", usage.value.entries.joinToString("|") { "${it.key}=${it.value}" }).apply()
    }

    private fun readUsage(): Map<String, Int> {
        val out = HashMap<String, Int>()
        (prefs.getString("usage", "") ?: "").split("|").forEach { part ->
            val p = part.split("=")
            if (p.size == 2) p[1].toIntOrNull()?.let { out[p[0]] = it }
        }
        return out
    }

    private fun readList(name: String): List<String> =
        (prefs.getString(name, "") ?: "").split("|").filter { it.isNotBlank() }

    private fun readLayout(): List<HomeItem> {
        val saved = prefs.getString("layout", null)
        if (saved != null) return parseLayout(saved)
        // first start after the update: old flat "home" list becomes unplaced items, the grid places them
        return readList("home").map { HomeItem.app(it) }
    }

    private fun save() {
        prefs.edit()
            .putString("dock", dockKeys.value.joinToString("|"))
            .putString("layout", serializeLayout(_items.value))
            .apply()
    }
}
