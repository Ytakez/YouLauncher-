package com.youlauncher.app

import android.app.ActivityOptions
import android.app.WallpaperManager
import android.graphics.Bitmap
import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import android.os.Build
import android.os.Process
import android.os.UserHandle
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.compose.ui.geometry.Rect
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Overlay { SETTINGS, WIDGETS, WALLPAPERS }

enum class WallTarget { HOME, LOCK, BOTH }

/** State of the built-in launch animation (icon expands into a full-screen surface). */
data class LaunchAnim(val key: String, val rect: Rect, val id: Long = System.nanoTime())

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val ctx: Context = application.applicationContext
    private val pm: PackageManager = ctx.packageManager
    private val prefs = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    private val launcherApps: LauncherApps = ctx.getSystemService(LauncherApps::class.java)

    val settings = LauncherSettings(prefs)
    val widgets = WidgetController(ctx, prefs)

    // ---------- apps / dock / home ----------
    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps.asStateFlow()

    private val dockKeys = MutableStateFlow(readList("dock"))
    private val homeKeys = MutableStateFlow(readList("home"))
    private val usage = MutableStateFlow(readUsage())

    val dockApps: StateFlow<List<AppInfo>> =
        combine(_apps, dockKeys) { apps, keys -> keys.mapNotNull { k -> apps.firstOrNull { it.key == k } } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val homeApps: StateFlow<List<AppInfo>> =
        combine(_apps, homeKeys) { apps, keys -> keys.mapNotNull { k -> apps.firstOrNull { it.key == k } } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val suggestions: StateFlow<List<AppInfo>> =
        combine(_apps, usage) { apps, u ->
            apps.filter { (u[it.key] ?: 0) > 0 }.sortedByDescending { u[it.key] ?: 0 }.take(4)
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---------- drawer / overlays / launch animation ----------
    private val _drawerOpen = MutableStateFlow(false)
    val drawerOpen: StateFlow<Boolean> = _drawerOpen.asStateFlow()

    private val _focusSearch = MutableStateFlow(false)
    val focusSearch: StateFlow<Boolean> = _focusSearch.asStateFlow()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _overlay = MutableStateFlow<Overlay?>(null)
    val overlay: StateFlow<Overlay?> = _overlay.asStateFlow()

    private val _launchAnim = MutableStateFlow<LaunchAnim?>(null)
    val launchAnim: StateFlow<LaunchAnim?> = _launchAnim.asStateFlow()

    fun openDrawer() { _focusSearch.value = false; _drawerOpen.value = true }
    fun openSearch() { _focusSearch.value = true; _drawerOpen.value = true }
    fun closeDrawer() { _drawerOpen.value = false; _focusSearch.value = false; _query.value = "" }
    fun setQuery(q: String) { _query.value = q }
    fun openOverlay(o: Overlay) { _overlay.value = o }
    fun closeOverlay() { _overlay.value = null }

    private val appsCallback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) {
            // only a real uninstall removes the icon from the saved layout
            packageName?.let { removePackage(it) }
            refreshApps()
        }
        override fun onPackageAdded(packageName: String?, user: UserHandle?) { refreshApps() }
        override fun onPackageChanged(packageName: String?, user: UserHandle?) { refreshApps() }
        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) { refreshApps() }
        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) { refreshApps() }
    }

    // ---------- AI icon recolor (DeepSeek) ----------
    val aiKey = MutableStateFlow(prefs.getString("aiKey", "") ?: "")
    private val _aiBusy = MutableStateFlow(false)
    val aiBusy: StateFlow<Boolean> = _aiBusy.asStateFlow()
    private val _aiName = MutableStateFlow(prefs.getString("aiName", "") ?: "")
    val aiName: StateFlow<String> = _aiName.asStateFlow()

    fun setAiKey(v: String) { aiKey.value = v.trim(); prefs.edit().putString("aiKey", v.trim()).apply() }

    fun resetIconColors() {
        IconTheme.seed = 0
        _aiName.value = ""
        prefs.edit().remove("seed").remove("aiName").apply()
    }

    /** Picks the Material You color directly (swatches, no AI needed). */
    fun setIconSeed(color: Int, name: String) {
        IconTheme.seed = color
        _aiName.value = name
        prefs.edit().putInt("seed", color).putString("aiName", name).apply()
    }

    /** Asks DeepSeek for the Material You seed color that matches [prompt] and recolors every icon with it. */
    fun recolorWithAi(prompt: String) {
        val key = aiKey.value
        if (key.isBlank() || prompt.isBlank() || _aiBusy.value) return
        _aiBusy.value = true
        viewModelScope.launch(Dispatchers.IO) {
            var error: String? = null
            try {
                val body = JSONObject()
                    .put("model", "deepseek-chat")
                    .put("temperature", 1.0)
                    .put("response_format", JSONObject().put("type", "json_object"))
                    .put("messages", org.json.JSONArray()
                        .put(JSONObject().put("role", "system").put("content",
                            "You pick the Material You seed color for an Android launcher. The user names a color " +
                            "or mood (e.g. blue, sunset, mint). Reply with JSON only: " +
                            "{\"name\": short color name in the user's language, \"color\": \"#RRGGBB\"}. " +
                            "The color must be a clear, medium-saturated, medium-brightness hue like Google's Material You seeds."))
                        .put(JSONObject().put("role", "user").put("content", prompt)))
                val conn = (URL("https://api.deepseek.com/chat/completions").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 45000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $key")
                }
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                if (conn.responseCode !in 200..299) {
                    error = "HTTP ${conn.responseCode}"
                } else {
                    val resp = conn.inputStream.bufferedReader().use { it.readText() }
                    val content = JSONObject(resp).getJSONArray("choices").getJSONObject(0)
                        .getJSONObject("message").getString("content")
                    val j = JSONObject(content)
                    val color = android.graphics.Color.parseColor(j.getString("color")) or 0xFF000000.toInt()
                    val name = j.optString("name", "")
                    prefs.edit().putInt("seed", color).putString("aiName", name).apply()
                    withContext(Dispatchers.Main) { IconTheme.seed = color; _aiName.value = name }
                }
            } catch (e: Throwable) {
                error = e.message ?: e.javaClass.simpleName
            }
            withContext(Dispatchers.Main) {
                _aiBusy.value = false
                if (error != null) Toast.makeText(ctx, ctx.getString(R.string.ai_fail, error), Toast.LENGTH_LONG).show()
            }
        }
    }

    init {
        IconTheme.seed = prefs.getInt("seed", 0)
        try { launcherApps.registerCallback(appsCallback) } catch (_: Exception) {}
    }

    override fun onCleared() {
        try { launcherApps.unregisterCallback(appsCallback) } catch (_: Exception) {}
        super.onCleared()
    }

    fun refreshApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(intent, 0)
                .map {
                    AppInfo(
                        it.loadLabel(pm).toString(),
                        ComponentName(it.activityInfo.packageName, it.activityInfo.name).flattenToString()
                    )
                }
                .filter { !it.key.startsWith(ctx.packageName + "/") }
                .distinctBy { it.key }
                .sortedBy { it.label.lowercase() }

            if (list.isEmpty()) return@launch

            if (!prefs.getBoolean("init", false)) {
                val dock = defaultDock(list)
                dockKeys.value = dock
                homeKeys.value = list.map { it.key }.filter { it !in dock }.take(8)
                prefs.edit().putBoolean("init", true).apply()
            }
            // Saved layout is never pruned here: apps that are temporarily missing (updating,
            // SD card, work profile paused) are just hidden and come back on their old spot.
            save()
            _apps.value = list
        }
    }

    private fun defaultDock(apps: List<AppInfo>): List<String> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        return intents
            .mapNotNull { pm.queryIntentActivities(it, PackageManager.MATCH_DEFAULT_ONLY).firstOrNull()?.activityInfo?.packageName }
            .distinct()
            .mapNotNull { pkg -> apps.firstOrNull { it.packageName == pkg }?.key }
            .take(4)
    }

    fun addToHome(key: String) {
        dockKeys.value = dockKeys.value - key
        if (key !in homeKeys.value) homeKeys.value = homeKeys.value + key
        save(); closeDrawer()
    }

    fun addToDock(key: String) {
        if (key in dockKeys.value) { closeDrawer(); return }
        if (dockKeys.value.size >= 4) {
            Toast.makeText(ctx, R.string.dock_full, Toast.LENGTH_SHORT).show()
            return
        }
        homeKeys.value = homeKeys.value - key
        dockKeys.value = dockKeys.value + key
        save(); closeDrawer()
    }

    /** Drag & drop on the home grid: [from] takes the slot of [to]. Saved immediately. */
    fun moveHome(from: String, to: String) {
        val l = homeKeys.value.toMutableList()
        val i = l.indexOf(from)
        val j = l.indexOf(to)
        if (i < 0 || j < 0 || i == j) return
        l.removeAt(i)
        l.add(j, from)
        homeKeys.value = l
        save()
    }

    private fun removePackage(pkg: String) {
        dockKeys.value = dockKeys.value.filter { it.substringBefore('/') != pkg }
        homeKeys.value = homeKeys.value.filter { it.substringBefore('/') != pkg }
        save()
    }

    fun unpin(key: String) {
        dockKeys.value = dockKeys.value - key
        homeKeys.value = homeKeys.value - key
        save()
    }

    // ---------- launching ----------
    /** Entry point for every app tap. */
    fun launch(key: String, rect: Rect?, view: View?) {
        bumpUsage(key)
        val mode = settings.animMode.value
        if (mode == AnimMode.CUSTOM && rect != null) {
            // built-in Material You animation: overlay animates, then calls commitLaunch()
            _launchAnim.value = LaunchAnim(key, rect)
        } else {
            start(key, rect, view, if (mode == AnimMode.OFF) AnimMode.OFF else AnimMode.SYSTEM)
            closeDrawer()
        }
    }

    fun commitLaunch(a: LaunchAnim) {
        start(a.key, null, null, AnimMode.CUSTOM)
        closeDrawer()
    }

    fun endLaunch() { _launchAnim.value = null }

    private fun start(key: String, rect: Rect?, view: View?, mode: AnimMode) {
        val cn = ComponentName.unflattenFromString(key) ?: run { endLaunch(); return }
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(cn)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val opts: ActivityOptions? = try {
            when {
                mode == AnimMode.OFF -> ActivityOptions.makeCustomAnimation(ctx, 0, 0)
                mode == AnimMode.CUSTOM -> ActivityOptions.makeCustomAnimation(ctx, android.R.anim.fade_in, 0)
                view != null && rect != null -> ActivityOptions.makeClipRevealAnimation(
                    view, rect.left.toInt(), rect.top.toInt(), rect.width.toInt(), rect.height.toInt()
                )
                else -> null
            }
        } catch (_: Exception) { null }
        try {
            ctx.startActivity(i, opts?.toBundle())
        } catch (_: Exception) {
            endLaunch()
        }
    }

    // ---------- shortcuts / system actions ----------
    fun shortcutActions(pkg: String): List<MenuAction> {
        return try {
            if (!launcherApps.hasShortcutHostPermission()) return emptyList()
            val q = LauncherApps.ShortcutQuery()
                .setPackage(pkg)
                .setQueryFlags(
                    LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
                )
            (launcherApps.getShortcuts(q, Process.myUserHandle()) ?: emptyList())
                .filter { it.isEnabled }
                .take(4)
                .map { s -> MenuAction(shortcutLabel(s)) { startShortcut(s) } }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun shortcutLabel(s: ShortcutInfo): String =
        s.shortLabel?.toString() ?: s.longLabel?.toString() ?: s.id

    private fun startShortcut(s: ShortcutInfo) {
        try {
            launcherApps.startShortcut(s.`package`, s.id, null, null, Process.myUserHandle())
        } catch (_: Exception) {}
    }

    fun openAppInfo(pkg: String) {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(Uri.fromParts("package", pkg, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {}
    }

    fun uninstall(pkg: String) {
        val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {}
    }

    fun expandNotifications() {
        try {
            val sb = ctx.getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
        } catch (_: Throwable) {}
    }

    /** Builds the bitmap off the main thread and sets it as the wallpaper. */
    fun applyWallpaper(target: WallTarget, make: () -> Bitmap?) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = try {
                val bmp = make() ?: throw IllegalStateException("no bitmap")
                val wm = WallpaperManager.getInstance(ctx)
                val flags = when (target) {
                    WallTarget.HOME -> WallpaperManager.FLAG_SYSTEM
                    WallTarget.LOCK -> WallpaperManager.FLAG_LOCK
                    WallTarget.BOTH -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                }
                wm.setBitmap(bmp, null, true, flags)
                true
            } catch (_: Throwable) {
                false
            }
            withContext(Dispatchers.Main) {
                Toast.makeText(ctx, if (ok) R.string.wp_set_ok else R.string.wp_set_fail, Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun openWallpaperPicker() {
        val i = Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), ctx.getString(R.string.wallpaper))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {}
    }

    fun openDefaultLauncherSettings() {
        val i = Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {
            try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
    }

    fun openNotificationAccess() {
        val i = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {}
    }

    // ---------- persistence ----------
    private fun bumpUsage(key: String) {
        val cur = usage.value
        usage.value = cur + (key to ((cur[key] ?: 0) + 1))
        prefs.edit().putString("usage", usage.value.entries.joinToString("|") { "${it.key}=${it.value}" }).apply()
    }

    private fun readUsage(): Map<String, Int> {
        val out = HashMap<String, Int>()
        (prefs.getString("usage", "") ?: "").split("|").forEach { part ->
            val p = part.split("=")
            if (p.size == 2) p[1].toIntOrNull()?.let { out[p[0]] = it }
        }
        return out
    }

    private fun readList(name: String): List<String> =
        (prefs.getString(name, "") ?: "").split("|").filter { it.isNotBlank() }

    private fun save() {
        prefs.edit()
            .putString("dock", dockKeys.value.joinToString("|"))
            .putString("home", homeKeys.value.joinToString("|"))
            .apply()
    }
}
