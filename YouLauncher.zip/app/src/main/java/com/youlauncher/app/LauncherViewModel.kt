package com.youlauncher.app

import android.app.ActivityOptions
import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.net.Uri
import android.os.Build
import android.os.Process
import android.os.UserHandle
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.compose.ui.geometry.Rect
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class Overlay { SETTINGS, WIDGETS, WALLPAPER }

/** State of the built-in launch animation (icon expands into a full-screen surface). */
data class LaunchAnim(val key: String, val rect: Rect, val id: Long = System.nanoTime())

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val ctx: Context = application.applicationContext
    private val pm: PackageManager = ctx.packageManager
    private val prefs = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    private val launcherApps: LauncherApps = ctx.getSystemService(LauncherApps::class.java)

    val settings = LauncherSettings(prefs)
    val widgets = WidgetController(ctx, prefs)

    // ---------- apps / dock / home ----------
    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps.asStateFlow()

    private val dockKeys = MutableStateFlow(readList("dock"))
    private val homePos = MutableStateFlow(readPos())
    private val usage = MutableStateFlow(readUsage())

    val dockApps: StateFlow<List<AppInfo>> =
        combine(_apps, dockKeys) { apps, keys -> keys.mapNotNull { k -> apps.firstOrNull { it.key == k } } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Cell index (row * columns + column) -> app. Positions are chosen by the user. */
    val homeCells: StateFlow<Map<Int, AppInfo>> =
        combine(_apps, homePos) { apps, pos ->
            val byKey = apps.associateBy { it.key }
            val out = HashMap<Int, AppInfo>()
            pos.forEach { (k, i) -> byKey[k]?.let { out[i] = it } }
            out
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    private val _placing = MutableStateFlow<String?>(null)
    val placing: StateFlow<String?> = _placing.asStateFlow()

    val suggestions: StateFlow<List<AppInfo>> =
        combine(_apps, usage) { apps, u ->
            apps.filter { (u[it.key] ?: 0) > 0 }.sortedByDescending { u[it.key] ?: 0 }.take(4)
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---------- drawer / overlays / launch animation ----------
    private val _drawerOpen = MutableStateFlow(false)
    val drawerOpen: StateFlow<Boolean> = _drawerOpen.asStateFlow()

    private val _focusSearch = MutableStateFlow(false)
    val focusSearch: StateFlow<Boolean> = _focusSearch.asStateFlow()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _overlay = MutableStateFlow<Overlay?>(null)
    val overlay: StateFlow<Overlay?> = _overlay.asStateFlow()

    private val _launchAnim = MutableStateFlow<LaunchAnim?>(null)
    val launchAnim: StateFlow<LaunchAnim?> = _launchAnim.asStateFlow()

    fun openDrawer() { _focusSearch.value = false; _drawerOpen.value = true }
    fun openSearch() { _focusSearch.value = true; _drawerOpen.value = true }
    fun closeDrawer() { _drawerOpen.value = false; _focusSearch.value = false; _query.value = "" }
    fun setQuery(q: String) { _query.value = q }
    fun openOverlay(o: Overlay) { _overlay.value = o }
    fun closeOverlay() { _overlay.value = null }

    private val appsCallback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) {
            if (user == null || user == Process.myUserHandle()) forgetIfGone(packageName)
            refreshApps()
        }
        override fun onPackageAdded(packageName: String?, user: UserHandle?) { refreshApps() }
        override fun onPackageChanged(packageName: String?, user: UserHandle?) { refreshApps() }
        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) { refreshApps() }
        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) { refreshApps() }
    }

    init {
        try { launcherApps.registerCallback(appsCallback) } catch (_: Exception) {}
    }

    fun flush() { save() }

    override fun onCleared() {
        try { launcherApps.unregisterCallback(appsCallback) } catch (_: Exception) {}
        super.onCleared()
    }

    fun refreshApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(intent, 0)
                .map {
                    AppInfo(
                        it.loadLabel(pm).toString(),
                        ComponentName(it.activityInfo.packageName, it.activityInfo.name).flattenToString()
                    )
                }
                .filter { !it.key.startsWith(ctx.packageName + "/") }
                .distinctBy { it.key }
                .sortedBy { it.label.lowercase() }

            if (list.isEmpty()) return@launch

            if (!prefs.getBoolean("init", false)) {
                val dock = defaultDock(list)
                dockKeys.value = dock
                homePos.value = list.map { it.key }.filter { it !in dock }.take(8)
                    .mapIndexed { i, k -> k to i }.toMap()
                prefs.edit().putBoolean("init", true).apply()
                save()
            }
            // ВАЖНО: раскладку (док/главный) здесь больше не чистим. Раньше любое временное
            // "исчезновение" приложения (обновление, загрузка телефона, SD-карта) стирало его
            // место навсегда. Отсутствующие приложения просто не показываются и возвращаются на место.
            _apps.value = list
        }
    }

    private fun defaultDock(apps: List<AppInfo>): List<String> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        return intents
            .mapNotNull { pm.queryIntentActivities(it, PackageManager.MATCH_DEFAULT_ONLY).firstOrNull()?.activityInfo?.packageName }
            .distinct()
            .mapNotNull { pkg -> apps.firstOrNull { it.packageName == pkg }?.key }
            .take(4)
    }

    /** Enters "pick a spot" mode: the user taps an empty (or occupied -> swap) cell on the home grid. */
    fun addToHome(key: String) = startPlacing(key)

    fun startPlacing(key: String) { _placing.value = key; closeDrawer(); closeOverlay() }
    fun cancelPlacing() { _placing.value = null }

    fun placeAt(idx: Int) {
        val key = _placing.value ?: return
        val pos = LinkedHashMap(homePos.value)
        val old = pos[key]
        val occupant = pos.entries.firstOrNull { it.value == idx && it.key != key }?.key
        if (occupant != null) { if (old != null) pos[occupant] = old else pos.remove(occupant) }
        pos[key] = idx
        dockKeys.value = dockKeys.value - key
        homePos.value = pos
        _placing.value = null
        save()
    }

    fun addToDock(key: String) {
        if (key in dockKeys.value) { closeDrawer(); return }
        if (dockKeys.value.size >= 4) {
            Toast.makeText(ctx, R.string.dock_full, Toast.LENGTH_SHORT).show()
            return
        }
        homePos.value = homePos.value - key
        dockKeys.value = dockKeys.value + key
        save(); closeDrawer()
    }

    private fun forgetIfGone(pkg: String?) {
        if (pkg == null) return
        val installed = try { pm.getPackageInfo(pkg, 0); true }
        catch (_: PackageManager.NameNotFoundException) { false }
        catch (_: Exception) { true }
        if (installed) return
        dockKeys.value = dockKeys.value.filter { !it.startsWith("$pkg/") }
        homePos.value = homePos.value.filterKeys { !it.startsWith("$pkg/") }
        save()
    }

    private fun moveIn(list: List<String>, key: String, delta: Int): List<String> {
        val visible = _apps.value.map { it.key }.toSet()
        val vis = list.filter { it in visible }
        val i = vis.indexOf(key)
        if (i < 0) return list
        val target = vis.getOrNull(i + delta) ?: return list
        val a = list.indexOf(key)
        val b = list.indexOf(target)
        return list.toMutableList().also { it.removeAt(a); it.add(b, key) }
    }

    fun moveDock(key: String, delta: Int) { dockKeys.value = moveIn(dockKeys.value, key, delta); save() }

    fun unpin(key: String) {
        dockKeys.value = dockKeys.value - key
        homePos.value = homePos.value - key
        save()
    }

    // ---------- launching ----------
    /** Entry point for every app tap. */
    fun launch(key: String, rect: Rect?, view: View?) {
        bumpUsage(key)
        val mode = settings.animMode.value
        if (mode == AnimMode.CUSTOM && rect != null) {
            // built-in Material You animation: overlay animates, then calls commitLaunch()
            _launchAnim.value = LaunchAnim(key, rect)
        } else {
            start(key, rect, view, if (mode == AnimMode.OFF) AnimMode.OFF else AnimMode.SYSTEM)
            closeDrawer()
        }
    }

    fun commitLaunch(a: LaunchAnim) {
        start(a.key, null, null, AnimMode.CUSTOM)
        closeDrawer()
    }

    fun endLaunch() { _launchAnim.value = null }

    private fun start(key: String, rect: Rect?, view: View?, mode: AnimMode) {
        val cn = ComponentName.unflattenFromString(key) ?: run { endLaunch(); return }
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(cn)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val opts: ActivityOptions? = try {
            when {
                mode == AnimMode.OFF -> ActivityOptions.makeCustomAnimation(ctx, 0, 0)
                mode == AnimMode.CUSTOM -> ActivityOptions.makeCustomAnimation(ctx, R.anim.app_enter, R.anim.launcher_hold)
                view != null && rect != null -> ActivityOptions.makeClipRevealAnimation(
                    view, rect.left.toInt(), rect.top.toInt(), rect.width.toInt(), rect.height.toInt()
                )
                else -> null
            }
        } catch (_: Exception) { null }
        try {
            ctx.startActivity(i, opts?.toBundle())
        } catch (_: Exception) {
            endLaunch()
        }
    }

    // ---------- shortcuts / system actions ----------
    fun shortcutActions(pkg: String): List<MenuAction> {
        return try {
            if (!launcherApps.hasShortcutHostPermission()) return emptyList()
            val q = LauncherApps.ShortcutQuery()
                .setPackage(pkg)
                .setQueryFlags(
                    LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
                )
            (launcherApps.getShortcuts(q, Process.myUserHandle()) ?: emptyList())
                .filter { it.isEnabled }
                .take(4)
                .map { s -> MenuAction(shortcutLabel(s)) { startShortcut(s) } }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun shortcutLabel(s: ShortcutInfo): String =
        s.shortLabel?.toString() ?: s.longLabel?.toString() ?: s.id

    private fun startShortcut(s: ShortcutInfo) {
        try {
            launcherApps.startShortcut(s.`package`, s.id, null, null, Process.myUserHandle())
        } catch (_: Exception) {}
    }

    fun openAppInfo(pkg: String) {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(Uri.fromParts("package", pkg, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {}
    }

    fun uninstall(pkg: String) {
        val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {}
    }

    fun expandNotifications() {
        try {
            val sb = ctx.getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
        } catch (_: Throwable) {}
    }

    fun openWallpaperPicker() {
        val i = Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), ctx.getString(R.string.wallpaper))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {}
    }

    fun openDefaultLauncherSettings() {
        val i = Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {
            try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
    }

    fun openNotificationAccess() {
        val i = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {}
    }

    // ---------- persistence ----------
    private fun bumpUsage(key: String) {
        val cur = usage.value
        usage.value = cur + (key to ((cur[key] ?: 0) + 1))
        prefs.edit().putString("usage", usage.value.entries.joinToString("|") { "${it.key}=${it.value}" }).apply()
    }

    private fun readUsage(): Map<String, Int> {
        val out = HashMap<String, Int>()
        (prefs.getString("usage", "") ?: "").split("|").forEach { part ->
            val p = part.split("=")
            if (p.size == 2) p[1].toIntOrNull()?.let { out[p[0]] = it }
        }
        return out
    }

    private fun readPos(): Map<String, Int> {
        val raw = prefs.getString("homePos", null)
        if (raw == null) { // migrate the old ordered list: item i -> cell i
            return readList("home").mapIndexed { i, k -> k to i }.toMap()
        }
        val out = LinkedHashMap<String, Int>()
        raw.split("|").forEach { part ->
            val p = part.split("=")
            if (p.size == 2) p[1].toIntOrNull()?.let { out[p[0]] = it }
        }
        return out
    }

    private fun readList(name: String): List<String> =
        (prefs.getString(name, "") ?: "").split("|").filter { it.isNotBlank() }

    private fun save() {
        prefs.edit()
            .putString("dock", dockKeys.value.joinToString("|"))
            .putString("homePos", homePos.value.entries.joinToString("|") { "${it.key}=${it.value}" })
            .apply()
    }
}
