package com.youlauncher.app

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class WidgetController(private val ctx: Context, private val prefs: SharedPreferences) {
    val host = AppWidgetHost(ctx, 1024)
    val manager: AppWidgetManager = AppWidgetManager.getInstance(ctx)

    private val _ids = MutableStateFlow(read())
    val ids: StateFlow<List<Int>> = _ids.asStateFlow()

    private fun read(): List<Int> =
        (prefs.getString("widgets", "") ?: "").split("|").mapNotNull { it.toIntOrNull() }

    private val _bottom = MutableStateFlow(readBottom())
    /** Widgets placed under the dock (the spot of the removed search bar). */
    val bottomIds: StateFlow<List<Int>> = _bottom.asStateFlow()

    private fun readBottom(): List<Int> =
        (prefs.getString("widgetsBottom", "") ?: "").split("|").mapNotNull { it.toIntOrNull() }

    private fun save() {
        prefs.edit()
            .putString("widgets", _ids.value.joinToString("|"))
            .putString("widgetsBottom", _bottom.value.joinToString("|"))
            .apply()
    }

    fun moveTo(id: Int, bottom: Boolean) {
        if (bottom) {
            _ids.value = _ids.value - id
            if (id !in _bottom.value) _bottom.value = _bottom.value + id
        } else {
            _bottom.value = _bottom.value - id
            if (id !in _ids.value) _ids.value = _ids.value + id
        }
        save()
    }

    fun commit(id: Int) {
        if (id !in _ids.value) {
            _ids.value = _ids.value + id
            save()
        }
    }

    fun remove(id: Int) {
        try { host.deleteAppWidgetId(id) } catch (_: Exception) {}
        _ids.value = _ids.value - id
        _bottom.value = _bottom.value - id
        save()
    }

    fun providers(): List<AppWidgetProviderInfo> =
        try { manager.installedProviders } catch (e: Exception) { emptyList() }

    @Suppress("DEPRECATION")
    fun label(info: AppWidgetProviderInfo): String =
        if (Build.VERSION.SDK_INT >= 30) info.loadLabel(ctx.packageManager) else (info.label ?: "")
}
