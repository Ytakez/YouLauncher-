package com.youlauncher.app

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class WidgetController(private val ctx: Context, private val prefs: SharedPreferences) {
    val host = AppWidgetHost(ctx, 1024)
    val manager: AppWidgetManager = AppWidgetManager.getInstance(ctx)

    private val _ids = MutableStateFlow(read())
    val ids: StateFlow<List<Int>> = _ids.asStateFlow()

    private fun read(): List<Int> =
        (prefs.getString("widgets", "") ?: "").split("|").mapNotNull { it.toIntOrNull() }

    private fun save() {
        prefs.edit().putString("widgets", _ids.value.joinToString("|")).commit()
    }

    /** Виджет, который сейчас привязывается/настраивается. Хранится на диске: если систему
     *  убила наш процесс, пока открыт экран настройки виджета, мы всё равно его добавим. */
    var pending: Int
        get() = prefs.getInt("pendingWidget", -1)
        set(v) { prefs.edit().putInt("pendingWidget", v).apply() }

    val note = MutableStateFlow(prefs.getString("note", "") ?: "")
    fun setNote(v: String) { note.value = v; prefs.edit().putString("note", v).apply() }

    /** Built-in widgets use negative ids; they are added once each. */
    fun addBuiltin(b: Builtin) { commit(b.id) }

    fun move(id: Int, delta: Int) {
        val l = _ids.value.toMutableList()
        val i = l.indexOf(id)
        val j = i + delta
        if (i < 0 || j !in l.indices) return
        l.removeAt(i); l.add(j, id)
        _ids.value = l
        save()
    }

    fun commit(id: Int) {
        if (id !in _ids.value) {
            _ids.value = _ids.value + id
            save()
        }
    }

    fun remove(id: Int) {
        if (id >= 0) { try { host.deleteAppWidgetId(id) } catch (_: Exception) {} }
        _ids.value = _ids.value - id
        save()
    }

    fun providers(): List<AppWidgetProviderInfo> =
        try { manager.installedProviders } catch (e: Exception) { emptyList() }

    @Suppress("DEPRECATION")
    fun label(info: AppWidgetProviderInfo): String =
        if (Build.VERSION.SDK_INT >= 30) info.loadLabel(ctx.packageManager) else (info.label ?: "")
}
