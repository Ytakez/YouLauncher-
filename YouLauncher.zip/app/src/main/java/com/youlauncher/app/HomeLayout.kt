package com.youlauncher.app

import android.net.Uri
import androidx.compose.ui.geometry.Rect

/** Folder sizes: how many home cells a folder covers (1x1, 2x2, 3x3). */
enum class FolderSize(val span: Int) { NORMAL(1), LARGE(2), XXL(3) }

/**
 * One thing on the home screen: an app icon or a folder, placed at (page, col, row).
 * col < 0 or page < 0 means "not placed yet" - the grid puts it on the first free cell.
 */
data class HomeItem(
    val id: String,
    val page: Int,
    val col: Int,
    val row: Int,
    val appKey: String? = null,
    val name: String = "",
    val size: FolderSize = FolderSize.NORMAL,
    val keys: List<String> = emptyList()
) {
    val isFolder: Boolean get() = appKey == null

    /** Cells per side that this item occupies on a grid of [cols] x [rows]. */
    fun spanFor(cols: Int, rows: Int): Int =
        if (isFolder) minOf(size.span, cols, rows).coerceAtLeast(1) else 1

    companion object {
        fun app(key: String, page: Int = -1) = HomeItem("a:$key", page, -1, -1, appKey = key)
    }
}

/** Geometry of the home grid in pixels (same for every page). */
data class HomeMetrics(
    val cols: Int,
    val rows: Int,
    val padX: Float,
    val topPad: Float,
    val cellW: Float,
    val cellH: Float,
    val blockedRows: Int
) {
    fun rect(item: HomeItem): Rect {
        val s = item.spanFor(cols, rows)
        val l = padX + item.col * cellW
        val t = topPad + item.row * cellH
        return Rect(l, t, l + s * cellW, t + s * cellH)
    }

    fun rect(col: Int, row: Int, span: Int): Rect {
        val l = padX + col * cellW
        val t = topPad + row * cellH
        return Rect(l, t, l + span * cellW, t + span * cellH)
    }
}

fun serializeLayout(list: List<HomeItem>): String = list.joinToString("\n") { i ->
    if (i.isFolder) {
        listOf("F", i.id, i.page, i.col, i.row, i.size.name, Uri.encode(i.name), i.keys.joinToString(","))
            .joinToString("|")
    } else {
        listOf("A", i.page, i.col, i.row, i.appKey).joinToString("|")
    }
}

fun parseLayout(s: String): List<HomeItem> = s.split("\n").mapNotNull { line ->
    val p = line.split("|")
    try {
        when (p[0]) {
            "A" -> HomeItem("a:${p[4]}", p[1].toInt(), p[2].toInt(), p[3].toInt(), appKey = p[4])
            "F" -> HomeItem(
                id = p[1], page = p[2].toInt(), col = p[3].toInt(), row = p[4].toInt(),
                appKey = null,
                name = Uri.decode(p[6]),
                size = FolderSize.valueOf(p[5]),
                keys = p.getOrElse(7) { "" }.split(",").filter { it.isNotBlank() }
            )
            else -> null
        }
    } catch (_: Exception) {
        null
    }
}

/** Removes every app for which [pred] is true, also from inside folders. Folders with <2 apps collapse. */
fun stripKeys(list: List<HomeItem>, pred: (String) -> Boolean): List<HomeItem> {
    val out = ArrayList<HomeItem>()
    for (item in list) {
        if (!item.isFolder) {
            if (!pred(item.appKey!!)) out.add(item)
            continue
        }
        val left = item.keys.filter { !pred(it) }
        when {
            left.size == item.keys.size -> out.add(item)
            left.isEmpty() -> Unit
            left.size == 1 -> out.add(HomeItem("a:${left[0]}", item.page, item.col, item.row, appKey = left[0]))
            else -> out.add(item.copy(keys = left))
        }
    }
    return out
}
