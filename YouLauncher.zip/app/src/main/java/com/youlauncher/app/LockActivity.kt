package com.youlauncher.app

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import java.lang.ref.WeakReference

/**
 * Own lock screen + always-on display. It is an activity that is shown above the system keyguard
 * (showWhenLocked / turnScreenOn) and is started by [LockService] when the screen goes off / on.
 */
class LockActivity : ComponentActivity() {

    // created in onCreate: a context is not attached yet while the fields are initialised
    private val settingsState = mutableStateOf<LauncherSettings?>(null)
    private val settings: LauncherSettings get() = settingsState.value!!
    private val torchOn = mutableStateOf(false)
    private val muted = mutableStateOf(false)
    private var torchId: String? = null
    private val createdAt = SystemClock.elapsedRealtime()

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchId) torchOn.value = enabled
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = WeakReference(this)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        reloadSettings()
        applyMode(intent)
        setupTorch()
        muted.value = try {
            getSystemService(AudioManager::class.java).ringerMode != AudioManager.RINGER_MODE_NORMAL
        } catch (_: Throwable) { false }

        setContent {
            val mode by LockState.mode.collectAsStateWithLifecycle()
            val cfg = rememberLockConfig(settingsState.value!!)
            val notifs by NotificationDots.items.collectAsStateWithLifecycle()
            val aod by animateFloatAsState(
                targetValue = if (mode == LockMode.AOD || mode == LockMode.SLEEP) 1f else 0f,
                animationSpec = tween(650, easing = FastOutSlowInEasing),
                label = "aod"
            )
            var lastTouch by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
            var shiftIndex by remember { mutableIntStateOf(0) }
            val shifts = remember { listOf(0 to 0, 9 to -6, -8 to 8, 6 to 10, -10 to -4) }
            val shiftX by animateDpAsState(shifts[shiftIndex % shifts.size].first.dp, tween(2000), label = "sx")
            val shiftY by animateDpAsState(shifts[shiftIndex % shifts.size].second.dp, tween(2000), label = "sy")

            // brightness, keep-awake and system bars follow the mode
            LaunchedEffect(mode) {
                applyWindow(mode)
                if (mode == LockMode.AOD) {
                    LockState.aodExpired = false
                    val sec = settings.aodDuration.value.seconds
                    if (sec > 0) {
                        delay(sec * 1000L)
                        LockState.aodExpired = true
                        applyWindow(LockMode.AOD)
                    }
                }
            }
            // OLED burn-in protection: the AOD picture drifts a few pixels every minute
            LaunchedEffect(mode) {
                while (mode == LockMode.AOD) {
                    delay(60_000L)
                    shiftIndex++
                }
            }
            // idle on the lock screen -> back to the always-on display
            LaunchedEffect(mode, lastTouch) {
                if (mode == LockMode.LOCK && settings.aodEnabled.value && !LockState.aodExpired) {
                    delay(IDLE_TO_AOD_MS)
                    LockState.mode.value = LockMode.AOD
                }
            }

            BackHandler(enabled = true) { /* the lock screen cannot be dismissed with Back */ }

            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .pointerInput(Unit) {
                        awaitPointerEventScope {
                            while (true) {
                                awaitPointerEvent(PointerEventPass.Initial)
                                lastTouch = SystemClock.elapsedRealtime()
                            }
                        }
                    }
            ) {
                if (mode != LockMode.SLEEP) {
                    LockScreenContent(
                        cfg = cfg,
                        aod = aod,
                        interactive = true,
                        notifs = notifs,
                        modifier = Modifier.fillMaxSize(),
                        torchOn = torchOn.value,
                        muted = muted.value,
                        shiftX = if (mode == LockMode.AOD) shiftX else 0.dp,
                        shiftY = if (mode == LockMode.AOD) shiftY else 0.dp,
                        onUnlock = { unlock() },
                        onShortcut = ::runShortcut,
                        onNotif = { n -> unlock { try { n.intent?.send() } catch (_: Throwable) {} } },
                        onWake = {
                            if (settings.lockEnabled.value) LockState.mode.value = LockMode.LOCK else unlock()
                        }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        reloadSettings()
        applyMode(intent)
    }

    override fun onDestroy() {
        try { getSystemService(CameraManager::class.java).unregisterTorchCallback(torchCb) } catch (_: Throwable) {}
        if (current?.get() === this) current = null
        if (isFinishing) {
            LockState.mode.value = LockMode.NONE
            LockState.pendingAod = false
        }
        super.onDestroy()
    }

    // ---------- helpers ----------

    private fun reloadSettings() {
        settingsState.value = LauncherSettings(getSharedPreferences("launcher", Context.MODE_PRIVATE))
    }

    private fun applyMode(i: Intent?) {
        val m = runCatching { LockMode.valueOf(i?.getStringExtra(EXTRA_MODE) ?: "LOCK") }.getOrDefault(LockMode.LOCK)
        LockState.pendingAod = false
        LockState.mode.value = m
    }

    private fun applyWindow(mode: LockMode) {
        val lp = window.attributes
        lp.screenBrightness = if (mode == LockMode.AOD) 0.02f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
        if (mode == LockMode.AOD && !LockState.aodExpired) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.isAppearanceLightStatusBars = settings.lockColor.value == LockColor.BLACK && settings.lockShape.value
        if (mode == LockMode.AOD || mode == LockMode.SLEEP) c.hide(WindowInsetsCompat.Type.systemBars())
        else c.show(WindowInsetsCompat.Type.systemBars())
    }

    /** Dismisses the system keyguard (asks for the PIN only if the phone has a secure lock), then runs [then]. */
    private fun unlock(then: (() -> Unit)? = null) {
        val km = getSystemService(KeyguardManager::class.java)
        val done = {
            LockState.mode.value = LockMode.NONE
            try { then?.invoke() } catch (_: Throwable) {}
            finishAndRemoveTask()
        }
        if (km == null || !km.isKeyguardLocked) {
            done()
            return
        }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { done() }
            override fun onDismissError() { done() }
            override fun onDismissCancelled() { /* stays on the lock screen */ }
        })
    }

    private fun runShortcut(sc: LockShortcut) {
        when (sc) {
            LockShortcut.NONE -> {}
            LockShortcut.TORCH -> try {
                val id = torchId
                if (id != null) getSystemService(CameraManager::class.java).setTorchMode(id, !torchOn.value)
            } catch (_: Throwable) {}
            LockShortcut.MUTE -> try {
                val am = getSystemService(AudioManager::class.java)
                am.ringerMode = if (am.ringerMode == AudioManager.RINGER_MODE_NORMAL)
                    AudioManager.RINGER_MODE_VIBRATE else AudioManager.RINGER_MODE_NORMAL
                muted.value = am.ringerMode != AudioManager.RINGER_MODE_NORMAL
            } catch (_: Throwable) {}
            LockShortcut.CAMERA -> try {
                startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Throwable) {}
            LockShortcut.CALCULATOR -> unlock {
                try {
                    startActivity(
                        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Throwable) {}
            }
            LockShortcut.BLUETOOTH -> unlock { openSettings(Settings.ACTION_BLUETOOTH_SETTINGS) }
            LockShortcut.WIFI, LockShortcut.DATA -> unlock {
                openSettings(
                    if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY
                    else Settings.ACTION_WIRELESS_SETTINGS
                )
            }
        }
    }

    private fun openSettings(action: String) {
        try { startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
    }

    private fun setupTorch() {
        try {
            val cm = getSystemService(CameraManager::class.java)
            torchId = cm.cameraIdList.firstOrNull { id ->
                val ch = cm.getCameraCharacteristics(id)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
            cm.registerTorchCallback(torchCb, null)
        } catch (_: Throwable) {}
    }

    companion object {
        const val EXTRA_MODE = "mode"
        private const val IDLE_TO_AOD_MS = 12_000L
        private var current: WeakReference<LockActivity>? = null

        /** Closes the lock screen if the phone was unlocked some other way (e.g. by the system). */
        fun finishCurrent(onlyIfOlderThanMs: Long = 0L) {
            val a = current?.get() ?: return
            if (SystemClock.elapsedRealtime() - a.createdAt < onlyIfOlderThanMs) return
            LockState.mode.value = LockMode.NONE
            a.finishAndRemoveTask()
        }

        fun show(ctx: Context, mode: LockMode) {
            val i = Intent(ctx, LockActivity::class.java)
                .putExtra(EXTRA_MODE, mode.name)
                .addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                        Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                )
            try { ctx.startActivity(i) } catch (_: Throwable) {}
        }
    }
}
