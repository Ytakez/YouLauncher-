package com.youlauncher.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import androidx.compose.runtime.staticCompositionLocalOf

/**
 * Icon recoloring. ORIGINAL keeps the app's own colors; every other option repaints ALL icons
 * (even apps without a monochrome layer) in soft Material 3 tones.
 */
enum class IconPalette(val hue: Float, val labelRes: Int) {
    ORIGINAL(-1f, R.string.pal_original),
    THEME(-1f, R.string.pal_theme),
    MIX(-1f, R.string.pal_mix),
    LAVENDER(255f, R.string.pal_lavender),
    MINT(152f, R.string.pal_mint),
    PEACH(22f, R.string.pal_peach),
    SKY(205f, R.string.pal_sky),
    ROSE(340f, R.string.pal_rose),
    SAND(42f, R.string.pal_sand)
}

/** Hues used by the "Mix" palette: every app gets one of them, stable per package. */
val MixHues = floatArrayOf(255f, 152f, 22f, 205f, 340f, 42f)

private fun hsv(h: Float, s: Float, v: Float): Int =
    android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))

/** (tile color, glyph color) for hue based palettes; null for ORIGINAL / THEME (they use the app theme). */
fun IconPalette.colorsFor(key: String, dark: Boolean): Pair<Int, Int>? {
    val h = when (this) {
        IconPalette.ORIGINAL, IconPalette.THEME -> return null
        IconPalette.MIX -> MixHues[(key.substringBefore('/').hashCode() and 0x7fffffff) % MixHues.size]
        else -> hue
    }
    return if (dark) hsv(h, 0.42f, 0.30f) to hsv(h, 0.18f, 0.96f)
    else hsv(h, 0.16f, 0.98f) to hsv(h, 0.70f, 0.40f)
}

/**
 * Two-tone repaint: dark parts of the picture become [dark], bright parts become [light].
 * Keeps the shape of the original icon, so every app stays recognisable.
 */
fun duotone(src: Bitmap, dark: Int, light: Int): Bitmap {
    val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
    val c = Canvas(out)
    c.drawColor(light)
    val k = 1.15f // a little extra contrast
    fun row(shift: Int): FloatArray {
        val d = (dark shr shift and 0xFF).toFloat()
        val l = (light shr shift and 0xFF).toFloat()
        val diff = l - d
        return floatArrayOf(
            0.299f * k * diff / 255f, 0.587f * k * diff / 255f, 0.114f * k * diff / 255f, 0f,
            d + diff * (0.5f - 0.5f * k)
        )
    }
    val m = floatArrayOf(*row(16), *row(8), *row(0), 0f, 0f, 0f, 1f, 0f)
    val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    p.colorFilter = ColorMatrixColorFilter(ColorMatrix(m))
    c.drawBitmap(src, 0f, 0f, p)
    return out
}

val LocalIconPalette = staticCompositionLocalOf { IconPalette.ORIGINAL }

/** Tonal Material 3 container behind home screen widgets. */
val LocalWidgetCards = staticCompositionLocalOf { true }
