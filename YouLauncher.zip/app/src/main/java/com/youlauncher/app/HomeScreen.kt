package com.youlauncher.app

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.IconButton
import androidx.compose.runtime.key
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.zIndex
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun HomeScreen(vm: LauncherViewModel) {
    val home by vm.homeApps.collectAsStateWithLifecycle()
    val dock by vm.dockApps.collectAsStateWithLifecycle()
    val widgetIds by vm.widgets.ids.collectAsStateWithLifecycle()
    val cols by vm.settings.columns.collectAsStateWithLifecycle()
    val iconSize by vm.settings.iconSize.collectAsStateWithLifecycle()
    val labels by vm.settings.showLabels.collectAsStateWithLifecycle()
    val themed by vm.settings.themedIcons.collectAsStateWithLifecycle()
    val dotsOn by vm.settings.dots.collectAsStateWithLifecycle()
    val dotPkgs by NotificationDots.packages.collectAsStateWithLifecycle()
    val showDate by vm.settings.showDate.collectAsStateWithLifecycle()
    val showSearch by vm.settings.showSearch.collectAsStateWithLifecycle()
    val bottomIds by vm.widgets.bottomIds.collectAsStateWithLifecycle()
    val launch = rememberLauncher(vm)
    val connection = rememberSwipeConnection(onUp = vm::openDrawer, onDown = vm::expandNotifications)

    var menuOpen by remember { mutableStateOf(false) }
    var menuPos by remember { mutableStateOf(Offset.Zero) }

    // ---- drag & drop of home icons (order is saved by the ViewModel on every move) ----
    val gridState = rememberLazyGridState()
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragStart by remember { mutableStateOf(Offset.Zero) }
    var dragTotal by remember { mutableStateOf(Offset.Zero) }
    val lastMove = remember { longArrayOf(0L) }
    val homeKeySet = home.map { it.key }.toSet()

    val startDrag: (String) -> Unit = { key ->
        val info = gridState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == key }
        if (info != null) {
            dragKey = key
            dragStart = Offset(info.offset.x.toFloat(), info.offset.y.toFloat())
            dragTotal = Offset.Zero
        }
    }
    val dragBy: (Offset) -> Unit = { d ->
        dragTotal += d
        val dk = dragKey
        if (dk != null && System.currentTimeMillis() - lastMove[0] > 120L) {
            val infos = gridState.layoutInfo.visibleItemsInfo
            val cur = infos.firstOrNull { it.key == dk }
            if (cur != null) {
                val cx = dragStart.x + dragTotal.x + cur.size.width / 2f
                val cy = dragStart.y + dragTotal.y + cur.size.height / 2f
                val target = infos.firstOrNull {
                    val k = it.key
                    k is String && k != dk && k in homeKeySet &&
                        cx >= it.offset.x && cx < it.offset.x + it.size.width &&
                        cy >= it.offset.y && cy < it.offset.y + it.size.height
                }
                if (target != null) {
                    lastMove[0] = System.currentTimeMillis()
                    vm.moveHome(dk, target.key as String)
                }
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.systemBars)
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = { menuPos = it; menuOpen = true })
            }
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(cols),
                state = gridState,
                modifier = Modifier.weight(1f).nestedScroll(connection),
                contentPadding = PaddingValues(top = 24.dp, bottom = 8.dp)
            ) {
                if (showDate) {
                    item(key = "glance", span = { GridItemSpan(maxLineSpan) }) {
                        RemovableItem(onRemove = { vm.settings.setShowDate(false) }) { AtAGlance() }
                    }
                }
                items(widgetIds, key = { "w$it" }, span = { GridItemSpan(maxLineSpan) }) { id ->
                    WidgetHostItem(vm.widgets, id, bottom = false)
                }
                items(home, key = { it.key }) { app ->
                    val dragging = dragKey == app.key
                    AppIcon(
                        app = app,
                        modifier = if (dragging) {
                            Modifier
                                .zIndex(2f)
                                .graphicsLayer {
                                    val cur = gridState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == app.key }
                                    if (cur != null) {
                                        translationX = dragStart.x + dragTotal.x - cur.offset.x
                                        translationY = dragStart.y + dragTotal.y - cur.offset.y
                                    }
                                    alpha = 0.92f
                                }
                        } else Modifier.animateItem(),
                        onDragStart = { startDrag(app.key) },
                        onDragBy = dragBy,
                        onDragEnd = { dragKey = null },
                        labelColor = Color.White,
                        labelShadow = true,
                        iconSize = iconSize.dp,
                        themed = themed,
                        showLabel = labels,
                        dot = dotsOn && app.packageName in dotPkgs,
                        onLaunch = { r -> launch(app.key, r) },
                        menu = rememberMenu(vm, app, listOf(MenuAction(stringResource(R.string.remove)) { vm.unpin(app.key) }))
                    )
                }
            }

            // Dock + search pill: swipe up opens the drawer, swipe down pulls the shade
            Column(Modifier.verticalSwipe(onUp = vm::openDrawer, onDown = vm::expandNotifications)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    dock.forEach { app ->
                        AppIcon(
                            app = app,
                            labelColor = Color.White,
                            showLabel = false,
                            iconSize = iconSize.dp,
                            themed = themed,
                            dot = dotsOn && app.packageName in dotPkgs,
                            modifier = Modifier.weight(1f),
                            onLaunch = { r -> launch(app.key, r) },
                            menu = rememberMenu(vm, app, listOf(MenuAction(stringResource(R.string.remove)) { vm.unpin(app.key) }))
                        )
                    }
                }
                // widgets placed in the "search spot" (long-press the search bar -> Remove, then add e.g. Google Search widget)
                bottomIds.forEach { id ->
                    key(id) { WidgetHostItem(vm.widgets, id, bottom = true) }
                }
                if (showSearch) {
                    Spacer(Modifier.height(8.dp))
                    RemovableItem(
                        shape = CircleShape,
                        onClick = vm::openSearch,
                        onRemove = { vm.settings.setShowSearch(false) }
                    ) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.94f))
                                .padding(horizontal = 20.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                stringResource(R.string.search_apps),
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }

        // Long-press on empty space: wallpaper / widgets / settings
        Box(Modifier.offset { IntOffset(menuPos.x.roundToInt(), menuPos.y.roundToInt()) }) {
            DropdownMenu(
                expanded = menuOpen,
                onDismissRequest = { menuOpen = false },
                shape = RoundedCornerShape(24.dp),
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
            ) {
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.wallpaper)) },
                    onClick = { menuOpen = false; vm.openOverlay(Overlay.WALLPAPERS) }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.widgets)) },
                    onClick = { menuOpen = false; vm.openOverlay(Overlay.WIDGETS) }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.settings)) },
                    onClick = { menuOpen = false; vm.openOverlay(Overlay.SETTINGS) }
                )
            }
        }
    }
}

@Composable
private fun AtAGlance() {
    val date by produceState(LocalDate.now()) {
        while (true) { delay(60_000); value = LocalDate.now() }
    }
    val text = remember(date) {
        date.format(DateTimeFormatter.ofPattern("EEE, d MMM", Locale.getDefault()))
    }
    Text(
        text = text,
        color = Color.White,
        modifier = Modifier.padding(bottom = 12.dp),
        style = MaterialTheme.typography.headlineMedium.copy(
            shadow = Shadow(Color.Black.copy(alpha = 0.45f), Offset(0f, 3f), 10f)
        )
    )
}

/** Long-press: menu with "Remove". Used for the date and the search bar. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RemovableItem(
    shape: Shape = RoundedCornerShape(24.dp),
    onClick: (() -> Unit)? = null,
    onRemove: () -> Unit,
    content: @Composable () -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val haptics = LocalHapticFeedback.current
    Box {
        Box(
            Modifier
                .clip(shape)
                .combinedClickable(
                    onClick = { onClick?.invoke() },
                    onLongClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        open = true
                    }
                )
        ) { content() }
        DropdownMenu(
            expanded = open,
            onDismissRequest = { open = false },
            shape = RoundedCornerShape(24.dp),
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
        ) {
            DropdownMenuItem(
                text = { Text(stringResource(R.string.remove)) },
                onClick = { open = false; onRemove() }
            )
        }
    }
}

@Composable
fun WidgetHostItem(ctl: WidgetController, id: Int, bottom: Boolean) {
    val info = remember(id) { ctl.manager.getAppWidgetInfo(id) } ?: return
    val screenWidthDp = LocalConfiguration.current.screenWidthDp
    val density = LocalDensity.current.density
    val wDp = (screenWidthDp - 32).coerceAtLeast(120)
    val hDp = (info.minHeight / density).toInt().coerceIn(48, 340)
    var menu by remember { mutableStateOf(false) }
    Box(
        Modifier
            .fillMaxWidth()
            .height(hDp.dp)
            .padding(vertical = 4.dp)
    ) {
        AndroidView(
            factory = { c ->
                ctl.host.createView(c, id, info).also {
                    it.updateAppWidgetSize(null, wDp, hDp, wDp, hDp)
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(28.dp))
        )
        // small menu button: remove the widget or move it between the top and the search spot
        Box(Modifier.align(Alignment.TopEnd).padding(6.dp)) {
            IconButton(
                onClick = { menu = true },
                modifier = Modifier.size(28.dp).background(Color.Black.copy(alpha = 0.35f), CircleShape)
            ) {
                Icon(Icons.Rounded.MoreVert, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
            DropdownMenu(
                expanded = menu,
                onDismissRequest = { menu = false },
                shape = RoundedCornerShape(24.dp),
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
            ) {
                DropdownMenuItem(
                    text = { Text(stringResource(if (bottom) R.string.widget_move_up else R.string.widget_move_down)) },
                    onClick = { menu = false; ctl.moveTo(id, !bottom) }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.remove)) },
                    onClick = { menu = false; ctl.remove(id) }
                )
            }
        }
    }
}
