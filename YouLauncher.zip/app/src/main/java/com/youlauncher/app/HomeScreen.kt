package com.youlauncher.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt

/** One item (app or folder) drawn inside its cell(s). */
@Composable
private fun ItemVisual(
    item: HomeItem,
    appMap: Map<String, AppInfo>,
    span: Int,
    wDp: androidx.compose.ui.unit.Dp,
    hDp: androidx.compose.ui.unit.Dp,
    cellW: androidx.compose.ui.unit.Dp,
    cellH: androidx.compose.ui.unit.Dp,
    iconSize: androidx.compose.ui.unit.Dp,
    labels: Boolean,
    themed: Boolean,
    dot: Boolean,
    onLaunch: (String, androidx.compose.ui.geometry.Rect) -> Unit,
    onOpenFolder: (String) -> Unit
) {
    Box(Modifier.size(wDp, hDp), contentAlignment = Alignment.TopCenter) {
        if (item.isFolder) {
            FolderVisual(
                folder = item,
                apps = item.keys.mapNotNull { appMap[it] },
                span = span,
                cellW = cellW,
                cellH = cellH,
                iconSize = iconSize,
                showLabel = labels,
                themed = themed,
                onClick = { onOpenFolder(item.id) },
                onLaunch = onLaunch
            )
        } else {
            val app = item.appKey?.let { appMap[it] } ?: return@Box
            AppIcon(
                app = app,
                labelColor = Color.White,
                labelShadow = true,
                iconSize = iconSize,
                themed = themed,
                showLabel = labels,
                dot = dot,
                longPressEnabled = false,
                modifier = Modifier.fillMaxWidth(),
                menu = { emptyList() },
                onLaunch = { r -> onLaunch(app.key, r) }
            )
        }
    }
}

/** Drop highlight + the item that follows the finger. Recomposes on every move, so it is kept separate. */
@Composable
private fun DragLayer(
    item: HomeItem,
    posState: State<Offset>,
    grab: Offset,
    m: HomeMetrics,
    items: List<HomeItem>,
    page: Int,
    visible: (HomeItem) -> Boolean,
    density: Density,
    content: @Composable (androidx.compose.ui.unit.Dp, androidx.compose.ui.unit.Dp) -> Unit
) {
    val target = computeDrop(item, items, m, posState.value, grab, page, visible)
    val r = when (target) {
        is DropTarget.Merge -> m.rect(target.target)
        is DropTarget.Place -> m.rect(target.col, target.row, target.span)
    }
    val merge = target is DropTarget.Merge
    Box(
        Modifier
            .offset { IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
            .size(with(density) { r.width.toDp() }, with(density) { r.height.toDp() })
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(alpha = if (merge) 0.30f else 0.16f))
    )
    val s = item.spanFor(m.cols, m.rows)
    val w = with(density) { (s * m.cellW).toDp() }
    val h = with(density) { (s * m.cellH).toDp() }
    Box(
        Modifier
            .offset { IntOffset((posState.value.x - grab.x).roundToInt(), (posState.value.y - grab.y).roundToInt()) }
            .size(w, h)
            .graphicsLayer { scaleX = 1.08f; scaleY = 1.08f; alpha = 0.95f }
    ) { content(w, h) }
}

@Composable
fun HomeScreen(vm: LauncherViewModel) {
    val items by vm.homeItems.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    val dock by vm.dockApps.collectAsStateWithLifecycle()
    val widgetIds by vm.widgets.ids.collectAsStateWithLifecycle()
    val cols by vm.settings.columns.collectAsStateWithLifecycle()
    val iconSize by vm.settings.iconSize.collectAsStateWithLifecycle()
    val labels by vm.settings.showLabels.collectAsStateWithLifecycle()
    val themed by vm.settings.themedIcons.collectAsStateWithLifecycle()
    val showPageDots by vm.settings.pageDots.collectAsStateWithLifecycle()
    val dockBg by vm.settings.dockBg.collectAsStateWithLifecycle()
    val dotsOn by vm.settings.dots.collectAsStateWithLifecycle()
    val dotPkgs by NotificationDots.packages.collectAsStateWithLifecycle()
    val showDate by vm.settings.showDate.collectAsStateWithLifecycle()
    val homeClock by vm.settings.homeClock.collectAsStateWithLifecycle()
    val homeCtx = LocalContext.current
    val showSearch by vm.settings.showSearch.collectAsStateWithLifecycle()
    val bottomIds by vm.widgets.bottomIds.collectAsStateWithLifecycle()
    val drawerOpen by vm.drawerOpen.collectAsStateWithLifecycle()
    val overlay by vm.overlay.collectAsStateWithLifecycle()
    val launch = rememberLauncher(vm)
    val density = LocalDensity.current
    val haptics = LocalHapticFeedback.current

    val sInfo = stringResource(R.string.app_info)
    val sUninstall = stringResource(R.string.uninstall)
    val sRemove = stringResource(R.string.remove)
    val sEdit = stringResource(R.string.folder_edit)
    val sDeleteFolder = stringResource(R.string.folder_delete)
    val sFromFolder = stringResource(R.string.remove_from_folder)

    val appMap = remember(apps) { apps.associateBy { it.key } }
    val appMapState = rememberUpdatedState(appMap)

    // empty-space menu (wallpaper / widgets / settings)
    var menuOpen by remember { mutableStateOf(false) }
    var menuPos by remember { mutableStateOf(Offset.Zero) }
    // context menu of an item (long-press without moving)
    var itemMenuAnchor by remember { mutableStateOf<IntOffset?>(null) }
    var itemMenuActions by remember { mutableStateOf(emptyList<MenuAction>()) }

    var openFolderId by remember { mutableStateOf<String?>(null) }
    var editFolderId by remember { mutableStateOf<String?>(null) }

    // ---- grid geometry ----
    var pageSize by remember { mutableStateOf(IntSize.Zero) }
    var headerH by remember { mutableIntStateOf(0) }
    val metrics: HomeMetrics? = remember(pageSize, cols, iconSize, labels, headerH, density) {
        if (pageSize.width == 0 || pageSize.height == 0) null else {
            val d = density.density
            val cellH = (iconSize + 16 + (if (labels) 22 else 0)) * d
            val padX = 16 * d
            val top = 16 * d
            val bottom = 28 * d // room for the page dots
            val cellW = (pageSize.width - 2 * padX) / cols
            val rows = floor((pageSize.height - top - bottom) / cellH).toInt().coerceAtLeast(1)
            val blocked = if (headerH > top + 1) {
                ceil((headerH - top) / cellH).toInt().coerceAtMost(rows - 1)
            } else 0
            HomeMetrics(cols, rows, padX, top, cellW, cellH, blocked)
        }
    }
    val metricsState = rememberUpdatedState(metrics)
    val headerHState = rememberUpdatedState(headerH)

    // every change of the grid / items: put unplaced or overlapping icons on free cells
    LaunchedEffect(metrics, items) {
        metrics?.let { vm.normalizeHome(it.cols, it.rows, it.blockedRows) }
    }

    // ---- drag state ----
    var dragId by remember { mutableStateOf<String?>(null) }
    val dragPos = remember { mutableStateOf(Offset.Zero) }
    var dragGrab by remember { mutableStateOf(Offset.Zero) }
    var edgeSide by remember { mutableIntStateOf(0) }

    val basePages = max(1, (items.maxOfOrNull { it.page } ?: 0) + 1)
    val pageCount = basePages + if (dragId != null) 1 else 0 // spare page at the end while dragging
    val pagerState = rememberPagerState { pageCount }

    val visible: (HomeItem) -> Boolean = { o ->
        o.col >= 0 && o.page >= 0 && (o.isFolder || (o.appKey != null && appMapState.value.containsKey(o.appKey)))
    }

    fun appMenu(app: AppInfo, folderId: String?): List<MenuAction> = buildList {
        addAll(vm.shortcutActions(app.packageName))
        if (folderId != null) add(MenuAction(sFromFolder) { vm.removeFromFolder(folderId, app.key) })
        else add(MenuAction(sRemove) { vm.unpin(app.key) })
        add(MenuAction(sInfo) { vm.openAppInfo(app.packageName) })
        add(MenuAction(sUninstall) { vm.uninstall(app.packageName) })
    }

    fun openItemMenu(d: HomeItem, mm: HomeMetrics) {
        val r = mm.rect(d)
        itemMenuActions = if (d.isFolder) {
            listOf(
                MenuAction(sEdit) { editFolderId = d.id },
                MenuAction(sDeleteFolder) { vm.deleteFolder(d.id) }
            )
        } else {
            d.appKey?.let { appMapState.value[it] }?.let { appMenu(it, null) } ?: emptyList()
        }
        itemMenuAnchor = IntOffset(r.left.roundToInt(), r.top.roundToInt())
    }

    // holding an icon near the left / right edge flips the page
    LaunchedEffect(dragId != null, edgeSide) {
        if (dragId != null && edgeSide != 0) {
            while (true) {
                delay(650)
                val t = pagerState.currentPage + edgeSide
                if (t in 0 until pagerState.pageCount) pagerState.animateScrollToPage(t)
            }
        }
    }

    val scope = rememberCoroutineScope()
    BackHandler(enabled = pagerState.currentPage > 0 && !drawerOpen && overlay == null &&
        openFolderId == null && editFolderId == null) {
        scope.launch { pagerState.animateScrollToPage(0) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.systemBars)
    ) {
        Column(Modifier.fillMaxSize()) {
            // ---------------- pages ----------------
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .onSizeChanged { pageSize = it }
                    .verticalSwipe(onUp = vm::openDrawer, onDown = vm::expandNotifications)
                    .pointerInput(Unit) {
                        detectLauncherGestures(
                            onLongPress = { p ->
                                val mm = metricsState.value
                                val page = pagerState.currentPage
                                val hit = if (mm == null) null else items.firstOrNull { o ->
                                    o.page == page && visible(o) && mm.rect(o).contains(p)
                                }
                                if (hit == null || mm == null) {
                                    // date / widget header handles its own long-press menu
                                    if (!(page == 0 && p.y < headerHState.value)) {
                                        menuPos = p
                                        menuOpen = true
                                    }
                                    false
                                } else {
                                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                    val r = mm.rect(hit)
                                    dragGrab = p - Offset(r.left, r.top)
                                    dragPos.value = p
                                    edgeSide = 0
                                    dragId = hit.id
                                    true
                                }
                            },
                            onDrag = { pos ->
                                dragPos.value = pos
                                val edge = 36.dp.toPx()
                                edgeSide = when {
                                    pos.x < edge -> -1
                                    pos.x > size.width - edge -> 1
                                    else -> 0
                                }
                            },
                            onEnd = { moved ->
                                val id = dragId
                                val page = pagerState.currentPage
                                dragId = null
                                edgeSide = 0
                                val mm = metricsState.value
                                val d = items.firstOrNull { it.id == id }
                                if (d != null && mm != null) {
                                    if (!moved) {
                                        openItemMenu(d, mm)
                                    } else {
                                        when (val t = computeDrop(d, items, mm, dragPos.value, dragGrab, page, visible)) {
                                            is DropTarget.Merge -> vm.mergeInto(d.id, t.target.id)
                                            is DropTarget.Place -> vm.moveItem(d.id, page, t.col, t.row)
                                        }
                                    }
                                }
                            }
                        )
                    }
            ) {
                HorizontalPager(
                    state = pagerState,
                    userScrollEnabled = dragId == null,
                    modifier = Modifier.fillMaxSize()
                ) { page ->
                    Box(Modifier.fillMaxSize()) {
                        if (page == 0) {
                            // date + widgets live above the icon cells of the first page
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .onSizeChanged { headerH = it.height }
                                    .padding(start = 16.dp, end = 16.dp, top = 16.dp)
                            ) {
                                if (showDate) {
                                    RemovableItem(
                                        onClick = if (homeClock == HomeClockStyle.FLOWER) ({ openClockApp(homeCtx) }) else null,
                                        onRemove = { vm.settings.setShowDate(false) }
                                    ) { if (homeClock == HomeClockStyle.FLOWER) FlowerClock() else AtAGlance() }
                                }
                                widgetIds.forEach { id ->
                                    key(id) { WidgetHostItem(vm.widgets, id, bottom = false) }
                                }
                            }
                        }
                        val mm = metrics
                        if (mm != null) {
                            for (item in items) {
                                if (item.page != page || !visible(item)) continue
                                key(item.id) {
                                    val s = item.spanFor(mm.cols, mm.rows)
                                    val cellWdp = with(density) { mm.cellW.toDp() }
                                    val cellHdp = with(density) { mm.cellH.toDp() }
                                    Box(
                                        Modifier
                                            .offset {
                                                IntOffset(
                                                    (mm.padX + item.col * mm.cellW).roundToInt(),
                                                    (mm.topPad + item.row * mm.cellH).roundToInt()
                                                )
                                            }
                                            .alpha(if (dragId == item.id) 0f else 1f)
                                    ) {
                                        ItemVisual(
                                            item = item,
                                            appMap = appMap,
                                            span = s,
                                            wDp = cellWdp * s,
                                            hDp = cellHdp * s,
                                            cellW = cellWdp,
                                            cellH = cellHdp,
                                            iconSize = iconSize.dp,
                                            labels = labels,
                                            themed = themed,
                                            dot = dotsOn && item.appKey != null &&
                                                item.appKey.substringBefore('/') in dotPkgs,
                                            onLaunch = { k, r -> launch(k, r) },
                                            onOpenFolder = { openFolderId = it }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // page dots
                if (pageCount > 1 && showPageDots) {
                    Row(
                        Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        repeat(pageCount) { i ->
                            val cur = i == pagerState.currentPage
                            Box(
                                Modifier
                                    .size(if (cur) 8.dp else 6.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = if (cur) 0.95f else 0.45f))
                            )
                        }
                    }
                }

                // drop highlight + the lifted icon
                val lifted = dragId?.let { id -> items.firstOrNull { it.id == id } }
                if (lifted != null && metrics != null) {
                    DragLayer(
                        item = lifted,
                        posState = dragPos,
                        grab = dragGrab,
                        m = metrics,
                        items = items,
                        page = pagerState.currentPage,
                        visible = visible,
                        density = density
                    ) { w, h ->
                        val s = lifted.spanFor(metrics.cols, metrics.rows)
                        ItemVisual(
                            item = lifted,
                            appMap = appMap,
                            span = s,
                            wDp = w,
                            hDp = h,
                            cellW = w / s,
                            cellH = h / s,
                            iconSize = iconSize.dp,
                            labels = labels,
                            themed = themed,
                            dot = false,
                            onLaunch = { _, _ -> },
                            onOpenFolder = { }
                        )
                    }
                }

                // item context menu (long-press without moving)
                itemMenuAnchor?.let { a ->
                    Box(Modifier.offset { a }) {
                        DropdownMenu(
                            expanded = true,
                            onDismissRequest = { itemMenuAnchor = null },
                            shape = RoundedCornerShape(24.dp),
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        ) {
                            itemMenuActions.forEach { act ->
                                DropdownMenuItem(
                                    text = { Text(act.label) },
                                    onClick = { itemMenuAnchor = null; act.onClick() }
                                )
                            }
                        }
                    }
                }

                // long-press on empty space: wallpaper / widgets / settings
                Box(Modifier.offset { IntOffset(menuPos.x.roundToInt(), menuPos.y.roundToInt()) }) {
                    DropdownMenu(
                        expanded = menuOpen,
                        onDismissRequest = { menuOpen = false },
                        shape = RoundedCornerShape(24.dp),
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    ) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.wallpaper)) },
                            onClick = { menuOpen = false; vm.openOverlay(Overlay.WALLPAPERS) }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.widgets)) },
                            onClick = { menuOpen = false; vm.openOverlay(Overlay.WIDGETS) }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.settings)) },
                            onClick = { menuOpen = false; vm.openOverlay(Overlay.SETTINGS) }
                        )
                    }
                }
            }

            // Dock + search pill: swipe up opens the drawer, swipe down pulls the shade
            Column(
                Modifier
                    .padding(horizontal = 16.dp)
                    .verticalSwipe(onUp = vm::openDrawer, onDown = vm::expandNotifications)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .then(
                            if (dockBg) Modifier
                                .clip(RoundedCornerShape(32.dp))
                                .background(Color.White.copy(alpha = 0.18f))
                            else Modifier
                        ),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    dock.forEach { app ->
                        AppIcon(
                            app = app,
                            labelColor = Color.White,
                            showLabel = false,
                            iconSize = iconSize.dp,
                            themed = themed,
                            dot = dotsOn && app.packageName in dotPkgs,
                            modifier = Modifier.weight(1f),
                            onLaunch = { r -> launch(app.key, r) },
                            menu = rememberMenu(vm, app, listOf(MenuAction(stringResource(R.string.remove)) { vm.unpin(app.key) }))
                        )
                    }
                }
                // widgets placed in the "search spot" (long-press the search bar -> Remove, then add e.g. Google Search widget)
                bottomIds.forEach { id ->
                    key(id) { WidgetHostItem(vm.widgets, id, bottom = true) }
                }
                if (showSearch) {
                    Spacer(Modifier.height(8.dp))
                    // Pixel-style search pill: a full-height rounded bar, not a circle stretched across the screen
                    RemovableItem(
                        shape = RoundedCornerShape(28.dp),
                        onClick = vm::openSearch,
                        onRemove = { vm.settings.setShowSearch(false) }
                    ) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.94f))
                                .padding(horizontal = 20.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                stringResource(R.string.search_apps),
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }

        // ---------------- opened folder / folder editor ----------------
        val openFolder = openFolderId?.let { id -> items.firstOrNull { it.id == id && it.isFolder } }
        if (openFolder != null && editFolderId == null) {
            BackHandler { openFolderId = null }
            FolderPopup(
                folder = openFolder,
                apps = openFolder.keys.mapNotNull { appMap[it] },
                themed = themed,
                onRename = { vm.renameFolder(openFolder.id, it) },
                onClose = { openFolderId = null },
                onLaunch = { k, r -> openFolderId = null; launch(k, r) },
                menuFor = { app -> appMenu(app, openFolder.id) }
            )
        }
        val editFolder = editFolderId?.let { id -> items.firstOrNull { it.id == id && it.isFolder } }
        if (editFolder != null) {
            BackHandler { editFolderId = null }
            FolderEditSheet(
                folder = editFolder,
                apps = editFolder.keys.mapNotNull { appMap[it] },
                themed = themed,
                onCancel = { editFolderId = null },
                onApply = { n, sz ->
                    vm.updateFolder(editFolder.id, n.trim().ifEmpty { editFolder.name }, sz)
                    editFolderId = null
                }
            )
        }
    }
}

@Composable
private fun AtAGlance() {
    val date by produceState(LocalDate.now()) {
        while (true) { delay(60_000); value = LocalDate.now() }
    }
    val text = remember(date) {
        date.format(DateTimeFormatter.ofPattern("EEE, d MMM", Locale.getDefault()))
    }
    Text(
        text = text,
        color = Color.White,
        modifier = Modifier.padding(bottom = 12.dp),
        style = MaterialTheme.typography.headlineMedium.copy(
            shadow = Shadow(Color.Black.copy(alpha = 0.45f), Offset(0f, 3f), 10f)
        )
    )
}

/** Long-press: menu with "Remove". Used for the date and the search bar. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RemovableItem(
    shape: Shape = RoundedCornerShape(24.dp),
    onClick: (() -> Unit)? = null,
    onRemove: () -> Unit,
    content: @Composable () -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val haptics = LocalHapticFeedback.current
    Box {
        Box(
            Modifier
                .clip(shape)
                .combinedClickable(
                    onClick = { onClick?.invoke() },
                    onLongClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        open = true
                    }
                )
        ) { content() }
        DropdownMenu(
            expanded = open,
            onDismissRequest = { open = false },
            shape = RoundedCornerShape(24.dp),
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
        ) {
            DropdownMenuItem(
                text = { Text(stringResource(R.string.remove)) },
                onClick = { open = false; onRemove() }
            )
        }
    }
}

@Composable
fun WidgetHostItem(ctl: WidgetController, id: Int, bottom: Boolean) {
    val info = remember(id) { ctl.manager.getAppWidgetInfo(id) } ?: return
    val screenWidthDp = LocalConfiguration.current.screenWidthDp
    val density = LocalDensity.current.density
    val wDp = (screenWidthDp - 32).coerceAtLeast(120)
    // search-spot widgets (Google search bar) need at least 56dp, otherwise the bar gets cut
    val minH = if (bottom) 64 else 48
    // Google's search bar draws a pill with its own padding; minHeight alone is often smaller than the drawn bar.
    val hDp = (maxOf(info.minHeight, info.minResizeHeight) / density).toInt().coerceIn(minH, 340)
    var menu by remember { mutableStateOf(false) }
    val cards = LocalWidgetCards.current && !bottom
    val scheme = MaterialTheme.colorScheme
    Box(
        Modifier
            .fillMaxWidth()
            // +8dp: the 4dp vertical padding must not eat the widget's own height
            .height((hDp + 8).dp)
            .padding(vertical = 4.dp)
    ) {
        // Material 3 card for normal widgets; the search-spot widget draws its own pill, so no card and no clipping
        Box(
            Modifier
                .fillMaxSize()
                .then(if (cards) Modifier.clip(RoundedCornerShape(28.dp)).background(scheme.surfaceContainer.copy(alpha = 0.94f)) else Modifier)
        ) {
            AndroidView(
                factory = { c ->
                    ctl.host.createView(c, id, info).also {
                        it.updateAppWidgetSize(null, wDp, hDp, wDp, hDp)
                    }
                },
                update = { v -> (v as? LongPressHostView)?.onLongPress = { menu = true } },
                modifier = Modifier.fillMaxSize()
            )
        }
        // long-press on the widget opens the menu (no more "three dots" over the widget)
        Box(Modifier.align(Alignment.Center)) {
            DropdownMenu(
                expanded = menu,
                onDismissRequest = { menu = false },
                shape = RoundedCornerShape(24.dp),
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
            ) {
                DropdownMenuItem(
                    text = { Text(stringResource(if (bottom) R.string.widget_move_up else R.string.widget_move_down)) },
                    onClick = { menu = false; ctl.moveTo(id, !bottom) }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.remove)) },
                    onClick = { menu = false; ctl.remove(id) }
                )
            }
        }
    }
}
