package com.youlauncher.app

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun HomeScreen(vm: LauncherViewModel) {
    val cells by vm.homeCells.collectAsStateWithLifecycle()
    val placing by vm.placing.collectAsStateWithLifecycle()
    val allApps by vm.apps.collectAsStateWithLifecycle()
    val dock by vm.dockApps.collectAsStateWithLifecycle()
    val widgetIds by vm.widgets.ids.collectAsStateWithLifecycle()
    val cols by vm.settings.columns.collectAsStateWithLifecycle()
    val iconSize by vm.settings.iconSize.collectAsStateWithLifecycle()
    val labels by vm.settings.showLabels.collectAsStateWithLifecycle()
    val themed by vm.settings.themedIcons.collectAsStateWithLifecycle()
    val dotsOn by vm.settings.dots.collectAsStateWithLifecycle()
    val dotPkgs by NotificationDots.packages.collectAsStateWithLifecycle()
    val dockStyle by vm.settings.dockStyle.collectAsStateWithLifecycle()
    val showSearch by vm.settings.showSearch.collectAsStateWithLifecycle()
    val wRadius by vm.settings.widgetRadius.collectAsStateWithLifecycle()
    val launch = rememberLauncher(vm)
    val earlier = stringResource(R.string.move_earlier)
    val later = stringResource(R.string.move_later)
    val moveLabel = stringResource(R.string.move_app)
    var searchMenu by remember { mutableStateOf(false) }
    val totalCells = remember(cells, cols) {
        val need = (cells.keys.maxOrNull() ?: -1) + 1
        maxOf(cols * 8, (need + cols - 1) / cols * cols)
    }
    val cellH = iconSize.dp + 16.dp + (if (labels) 24.dp else 0.dp)
    val connection = rememberSwipeConnection(onUp = vm::openDrawer, onDown = vm::expandNotifications)

    var menuOpen by remember { mutableStateOf(false) }
    var menuPos by remember { mutableStateOf(Offset.Zero) }

    Box(
        Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.systemBars)
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = { menuPos = it; menuOpen = true })
            }
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(cols),
                modifier = Modifier.weight(1f).nestedScroll(connection),
                contentPadding = PaddingValues(top = 24.dp, bottom = 8.dp)
            ) {
                item(key = "glance", span = { GridItemSpan(maxLineSpan) }) {
                    AtAGlance()
                }
                items(widgetIds, key = { "w$it" }, span = { GridItemSpan(maxLineSpan) }) { id ->
                    WidgetHostItem(vm.widgets, id, wRadius.dp)
                }
                if (placing != null) {
                    item(key = "placing", span = { GridItemSpan(maxLineSpan) }) {
                        val name = allApps.firstOrNull { it.key == placing }?.label ?: ""
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                        ) {
                            Row(Modifier.padding(start = 20.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    stringResource(R.string.place_hint, name),
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    style = MaterialTheme.typography.bodyLarge,
                                    modifier = Modifier.weight(1f)
                                )
                                androidx.compose.material3.TextButton(onClick = vm::cancelPlacing) {
                                    Text(stringResource(R.string.cancel))
                                }
                            }
                        }
                    }
                }
                items(totalCells, key = { "cell$it" }) { idx ->
                    val app = cells[idx]
                    Box(Modifier.fillMaxWidth().heightIn(min = cellH)) {
                        if (app != null) {
                            androidx.compose.runtime.key(app.key) {
                                AppIcon(
                                    app = app,
                                    labelColor = Color.White,
                                    labelShadow = true,
                                    iconSize = iconSize.dp,
                                    themed = themed,
                                    showLabel = labels,
                                    dot = dotsOn && app.packageName in dotPkgs,
                                    enterIndex = if (idx < 24) idx else -1,
                                    onLaunch = { r -> if (placing == null) launch(app.key, r) },
                                    menu = rememberMenu(vm, app, listOf(
                                        MenuAction(moveLabel) { vm.startPlacing(app.key) },
                                        MenuAction(stringResource(R.string.remove)) { vm.unpin(app.key) }
                                    ))
                                )
                            }
                        }
                        if (placing != null) {
                            Box(
                                Modifier
                                    .matchParentSize()
                                    .padding(4.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = if (app == null) 0.16f else 0.30f))
                                    .clickable { vm.placeAt(idx) }
                            )
                        }
                    }
                }
            }

            // Dock + search pill: swipe up opens the drawer, swipe down pulls the shade
            Column(Modifier.verticalSwipe(onUp = vm::openDrawer, onDown = vm::expandNotifications)) {
                val dockMod = if (dockStyle == DockStyle.PILL)
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(36.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.55f))
                        .padding(horizontal = 8.dp)
                else Modifier.fillMaxWidth()
                Row(dockMod, horizontalArrangement = Arrangement.SpaceEvenly) {
                    dock.forEach { app ->
                        AppIcon(
                            app = app,
                            labelColor = Color.White,
                            showLabel = false,
                            iconSize = iconSize.dp,
                            themed = themed,
                            dot = dotsOn && app.packageName in dotPkgs,
                            modifier = Modifier.weight(1f),
                            onLaunch = { r -> launch(app.key, r) },
                            menu = rememberMenu(vm, app, listOf(
                                MenuAction(earlier) { vm.moveDock(app.key, -1) },
                                MenuAction(later) { vm.moveDock(app.key, 1) },
                                MenuAction(stringResource(R.string.remove)) { vm.unpin(app.key) }
                            ))
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (showSearch) Box {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.94f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .pointerInput(Unit) {
                                detectTapGestures(onTap = { vm.openSearch() }, onLongPress = { searchMenu = true })
                            }
                    ) {
                        Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                stringResource(R.string.search_apps),
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    DropdownMenu(
                        expanded = searchMenu,
                        onDismissRequest = { searchMenu = false },
                        shape = RoundedCornerShape(24.dp),
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    ) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.remove_search)) },
                            onClick = { searchMenu = false; vm.settings.setShowSearch(false) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }

        // Long-press on empty space: wallpaper / widgets / settings
        Box(Modifier.offset { IntOffset(menuPos.x.roundToInt(), menuPos.y.roundToInt()) }) {
            DropdownMenu(
                expanded = menuOpen,
                onDismissRequest = { menuOpen = false },
                shape = RoundedCornerShape(24.dp),
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
            ) {
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.wallpaper)) },
                    onClick = { menuOpen = false; vm.openOverlay(Overlay.WALLPAPER) }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.widgets)) },
                    onClick = { menuOpen = false; vm.openOverlay(Overlay.WIDGETS) }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.settings)) },
                    onClick = { menuOpen = false; vm.openOverlay(Overlay.SETTINGS) }
                )
            }
        }
    }
}

@Composable
private fun AtAGlance() {
    val date by produceState(LocalDate.now()) {
        while (true) { delay(60_000); value = LocalDate.now() }
    }
    val text = remember(date) {
        date.format(DateTimeFormatter.ofPattern("EEE, d MMM", Locale.getDefault()))
    }
    Text(
        text = text,
        color = Color.White,
        modifier = Modifier.padding(bottom = 12.dp),
        style = MaterialTheme.typography.headlineMedium.copy(
            shadow = Shadow(Color.Black.copy(alpha = 0.45f), Offset(0f, 3f), 10f)
        )
    )
}

@Composable
fun WidgetHostItem(ctl: WidgetController, id: Int, radius: Dp) {
    if (id < 0) {
        Builtin.of(id)?.let { BuiltinWidgetItem(ctl, it, radius) }
        return
    }
    val info = ctl.manager.getAppWidgetInfo(id) ?: return
    val screenWidthDp = LocalConfiguration.current.screenWidthDp
    val density = LocalDensity.current.density
    val wDp = (screenWidthDp - 32).coerceAtLeast(120)
    val hDp = (info.minHeight / density).toInt().coerceIn(72, 340)
    AndroidView(
        factory = { c ->
            ctl.host.createView(c, id, info).also {
                it.updateAppWidgetSize(null, wDp, hDp, wDp, hDp)
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(hDp.dp)
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(radius))
    )
}
