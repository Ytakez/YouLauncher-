package com.youlauncher.app

import androidx.compose.foundation.background
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Button
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: LauncherViewModel) {
    val s = vm.settings
    val columns by s.columns.collectAsStateWithLifecycle()
    val iconSize by s.iconSize.collectAsStateWithLifecycle()
    val labels by s.showLabels.collectAsStateWithLifecycle()
    val palette by s.iconPalette.collectAsStateWithLifecycle()
    val widgetCards by s.widgetCards.collectAsStateWithLifecycle()
    val dots by s.dots.collectAsStateWithLifecycle()
    val anim by s.animMode.collectAsStateWithLifecycle()
    val animSpeed by s.animSpeed.collectAsStateWithLifecycle()
    val shape by s.iconShape.collectAsStateWithLifecycle()
    val blur by s.blurAnim.collectAsStateWithLifecycle()
    val drawerOn by s.drawerEnabled.collectAsStateWithLifecycle()
    val showDate by s.showDate.collectAsStateWithLifecycle()
    val homeClock by s.homeClock.collectAsStateWithLifecycle()
    val showSearch by s.showSearch.collectAsStateWithLifecycle()
    val labelSize by s.labelSize.collectAsStateWithLifecycle()
    val folderAlpha by s.folderAlpha.collectAsStateWithLifecycle()
    val dim by s.dim.collectAsStateWithLifecycle()
    val pageDots by s.pageDots.collectAsStateWithLifecycle()
    val dockBg by s.dockBg.collectAsStateWithLifecycle()
    val drawerCols by s.drawerCols.collectAsStateWithLifecycle()
    val themeMode by s.themeMode.collectAsStateWithLifecycle()
    val accent by s.accent.collectAsStateWithLifecycle()
    val lockOn by s.lockEnabled.collectAsStateWithLifecycle()
    val aodOn by s.aodEnabled.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.systemBars)
                .verticalScroll(rememberScrollState())
        ) {
            PageTopBar(stringResource(R.string.settings), onBack = vm::closeOverlay)

            SectionTitle(stringResource(R.string.appearance))
            Group {
                ChoiceRow(
                    title = stringResource(R.string.theme_mode),
                    options = listOf(
                        ThemeMode.SYSTEM to stringResource(R.string.theme_system),
                        ThemeMode.LIGHT to stringResource(R.string.theme_light),
                        ThemeMode.DARK to stringResource(R.string.theme_dark)
                    ),
                    selected = themeMode,
                    onSelect = s::setThemeMode
                )
                AccentPicker(selected = accent, onSelect = s::setAccent)
                SliderRow(stringResource(R.string.dim_wallpaper), "$dim%", dim.toFloat(), 0f..70f) { s.setDim(it.roundToInt()) }
            }

            SectionTitle(stringResource(R.string.home_screen))
            Group {
                ChoiceRow(
                    title = stringResource(R.string.columns),
                    options = listOf(4, 5, 6).map { it to it.toString() },
                    selected = columns,
                    onSelect = s::setColumns
                )
                Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                    Text("${stringResource(R.string.icon_size)}: $iconSize dp", style = MaterialTheme.typography.bodyLarge)
                    Slider(
                        value = iconSize.toFloat(),
                        onValueChange = { s.setIconSize(it.roundToInt()) },
                        valueRange = 44f..72f
                    )
                }
                SwitchRow(stringResource(R.string.show_labels), null, labels, s::setShowLabels)
                ChoiceRow(
                    title = stringResource(R.string.label_size),
                    options = listOf(
                        0 to stringResource(R.string.size_small),
                        1 to stringResource(R.string.size_normal),
                        2 to stringResource(R.string.size_big)
                    ),
                    selected = labelSize,
                    onSelect = s::setLabelSize
                )
                SwitchRow(stringResource(R.string.app_drawer), stringResource(R.string.app_drawer_hint), drawerOn, vm::setDrawerEnabled)
                ChoiceRow(
                    title = stringResource(R.string.drawer_columns),
                    options = listOf(0 to stringResource(R.string.same_as_home), 4 to "4", 5 to "5", 6 to "6"),
                    selected = drawerCols,
                    onSelect = s::setDrawerCols
                )
                SwitchRow(stringResource(R.string.page_dots), null, pageDots, s::setPageDots)
                SwitchRow(stringResource(R.string.dock_background), null, dockBg, s::setDockBg)
                SwitchRow(stringResource(R.string.show_date), null, showDate, s::setShowDate)
                ChoiceRow(
                    title = stringResource(R.string.home_clock_style),
                    options = listOf(
                        HomeClockStyle.FLOWER to stringResource(R.string.clock_style_flower),
                        HomeClockStyle.DATE to stringResource(R.string.clock_style_date)
                    ),
                    selected = homeClock,
                    onSelect = s::setHomeClock
                )
                SwitchRow(stringResource(R.string.show_search), null, showSearch, s::setShowSearch)
            }

            SectionTitle(stringResource(R.string.icons))
            Group {
                ShapePicker(selected = shape, onSelect = s::setIconShape)
                SliderRow(stringResource(R.string.folder_opacity), "$folderAlpha%", folderAlpha.toFloat(), 5f..60f) {
                    s.setFolderAlpha(it.roundToInt())
                }
                IconPalettePicker(selected = palette, onSelect = s::setIconPalette)
            }

            SectionTitle(stringResource(R.string.widgets))
            Group {
                SwitchRow(stringResource(R.string.widget_cards), stringResource(R.string.widget_cards_hint), widgetCards, s::setWidgetCards)
            }

            SectionTitle(stringResource(R.string.animations))
            Group {
                ChoiceRow(
                    title = null,
                    options = listOf(
                        AnimMode.CUSTOM to stringResource(R.string.anim_custom),
                        AnimMode.SYSTEM to stringResource(R.string.anim_system),
                        AnimMode.OFF to stringResource(R.string.anim_off)
                    ),
                    selected = anim,
                    onSelect = s::setAnimMode
                )
                ChoiceRow(
                    title = stringResource(R.string.anim_speed),
                    options = listOf(
                        0 to stringResource(R.string.anim_speed_slow),
                        1 to stringResource(R.string.anim_speed_normal),
                        2 to stringResource(R.string.anim_speed_fast)
                    ),
                    selected = animSpeed,
                    onSelect = s::setAnimSpeed
                )
                SwitchRow(stringResource(R.string.anim_blur), stringResource(R.string.anim_blur_hint), blur, s::setBlurAnim)
                Text(
                    stringResource(R.string.anim_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 16.dp)
                )
            }

            SectionTitle(stringResource(R.string.notifications))
            Group {
                SwitchRow(stringResource(R.string.notif_dots), stringResource(R.string.notif_dots_hint), dots, s::setDots)
                TextButton(onClick = vm::openNotificationAccess, modifier = Modifier.padding(horizontal = 12.dp)) {
                    Text(stringResource(R.string.grant_access))
                }
            }

            SectionTitle(stringResource(R.string.lock_title))
            Group {
                SwitchRow(stringResource(R.string.lock_enable), stringResource(R.string.lock_enable_hint), lockOn) {
                    s.setLockEnabled(it)
                    LockService.sync(ctx, s)
                    if (it) LockService.requestOverlayIfNeeded(ctx)
                }
                SwitchRow(stringResource(R.string.aod_enable), stringResource(R.string.aod_enable_hint), aodOn) {
                    s.setAodEnabled(it)
                    LockService.sync(ctx, s)
                    if (it) LockService.requestOverlayIfNeeded(ctx)
                }
                ActionRow(stringResource(R.string.lock_customize)) { vm.openOverlay(Overlay.LOCKSCREEN) }
            }

            SectionTitle(stringResource(R.string.system))
            Group {
                ActionRow(stringResource(R.string.widgets)) { vm.openOverlay(Overlay.WIDGETS) }
                ActionRow(stringResource(R.string.wallpaper)) { vm.openOverlay(Overlay.WALLPAPERS) }
                ActionRow(stringResource(R.string.default_launcher), vm::openDefaultLauncherSettings)
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

/** Material You settings card: rounded surface that groups related rows. */
@Composable
internal fun Group(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh),
        content = content
    )
}

@Composable
internal fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 28.dp, end = 24.dp, top = 24.dp, bottom = 8.dp)
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ShapePicker(selected: IconShapeOption, onSelect: (IconShapeOption) -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
        Text(stringResource(R.string.icon_shape), style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(12.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            IconShapeOption.entries.forEach { opt ->
                val isSelected = opt == selected
                val label = stringResource(opt.labelRes)
                Box(
                    Modifier
                        .size(56.dp)
                        .clip(opt.toShape())
                        .background(
                            if (isSelected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.secondaryContainer
                        )
                        .clickable { onSelect(opt) }
                        .semantics { contentDescription = label },
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Icon(
                            Icons.Rounded.Check,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
internal fun <T> ChoiceRow(
    title: String?,
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit
) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
        if (title != null) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(8.dp))
        }
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            options.forEachIndexed { index, (value, label) ->
                SegmentedButton(
                    selected = value == selected,
                    onClick = { onSelect(value) },
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = options.size),
                    label = { Text(label, maxLines = 1) }
                )
            }
        }
    }
}

@Composable
internal fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            thumbContent = if (checked) {
                { Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(SwitchDefaults.IconSize)) }
            } else null
        )
    }
}

@Composable
internal fun ActionRow(title: String, onClick: () -> Unit) {
    Text(
        title,
        style = MaterialTheme.typography.bodyLarge,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 16.dp)
    )
}

@Composable
internal fun SliderRow(title: String, value: String, v: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
        Text("$title: $value", style = MaterialTheme.typography.bodyLarge)
        Slider(value = v, onValueChange = onChange, valueRange = range)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AccentPicker(selected: AccentOption, onSelect: (AccentOption) -> Unit) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
        Text(stringResource(R.string.accent_color), style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(12.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AccentOption.entries.forEach { opt ->
                val label = stringResource(opt.labelRes)
                val fill = if (opt == AccentOption.SYSTEM) MaterialTheme.colorScheme.surfaceVariant
                else accentScheme(opt.hue, dark = false).primary
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(fill)
                        .clickable { onSelect(opt) }
                        .semantics { contentDescription = label },
                    contentAlignment = Alignment.Center
                ) {
                    if (opt == AccentOption.SYSTEM) {
                        Text("A", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (opt == selected) {
                        Icon(
                            Icons.Rounded.Check,
                            contentDescription = null,
                            tint = if (opt == AccentOption.SYSTEM) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.White
                        )
                    }
                }
            }
        }
    }
}


/** "Icon colors": original, theme, mix of soft tones, or one pastel tone for all icons. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun IconPalettePicker(selected: IconPalette, onSelect: (IconPalette) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val dark = scheme.surface.luminance() < 0.5f
    Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
        Text(stringResource(R.string.icon_colors), style = MaterialTheme.typography.bodyLarge)
        Text(
            stringResource(R.string.icon_colors_hint),
            style = MaterialTheme.typography.bodySmall,
            color = scheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            IconPalette.entries.forEach { opt ->
                val pair = opt.colorsFor("", dark)
                val bg = when (opt) {
                    IconPalette.ORIGINAL -> scheme.surfaceVariant
                    IconPalette.THEME -> scheme.secondaryContainer
                    else -> androidx.compose.ui.graphics.Color(pair!!.first)
                }
                val fg = when (opt) {
                    IconPalette.ORIGINAL -> scheme.onSurfaceVariant
                    IconPalette.THEME -> scheme.onSecondaryContainer
                    else -> androidx.compose.ui.graphics.Color(pair!!.second)
                }
                val label = stringResource(opt.labelRes)
                Column(
                    Modifier.width(64.dp).clip(RoundedCornerShape(16.dp)).clickable { onSelect(opt) }.semantics { contentDescription = label },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val tile = if (opt == IconPalette.MIX) {
                        Modifier.background(
                            androidx.compose.ui.graphics.Brush.sweepGradient(
                                (MixHues.toList() + MixHues[0]).map { h ->
                                    androidx.compose.ui.graphics.Color(
                                        androidx.core.graphics.ColorUtils.HSLToColor(floatArrayOf(h, if (dark) 0.35f else 0.75f, if (dark) 0.35f else 0.85f))
                                    )
                                }
                            )
                        )
                    } else Modifier.background(bg)
                    Box(
                        Modifier
                            .size(52.dp)
                            .clip(LocalIconShape.current)
                            .then(tile)
                            .then(if (opt == selected) Modifier.border(2.5.dp, scheme.primary, LocalIconShape.current) else Modifier),
                        contentAlignment = Alignment.Center
                    ) {
                        if (opt == selected) {
                            Icon(Icons.Rounded.Check, contentDescription = null, tint = if (opt == IconPalette.MIX) scheme.onSurface else fg)
                        } else if (opt == IconPalette.ORIGINAL) {
                            Text("A", style = MaterialTheme.typography.titleMedium, color = fg)
                        } else if (opt != IconPalette.MIX) {
                            Box(Modifier.size(18.dp).clip(CircleShape).background(fg))
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (opt == selected) scheme.primary else scheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
