package com.youlauncher.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Button
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: LauncherViewModel) {
    val s = vm.settings
    val columns by s.columns.collectAsStateWithLifecycle()
    val iconSize by s.iconSize.collectAsStateWithLifecycle()
    val labels by s.showLabels.collectAsStateWithLifecycle()
    val themed by s.themedIcons.collectAsStateWithLifecycle()
    val dots by s.dots.collectAsStateWithLifecycle()
    val anim by s.animMode.collectAsStateWithLifecycle()
    val shape by s.iconShape.collectAsStateWithLifecycle()
    val blur by s.blurAnim.collectAsStateWithLifecycle()
    val showDate by s.showDate.collectAsStateWithLifecycle()
    val showSearch by s.showSearch.collectAsStateWithLifecycle()

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.systemBars)
                .verticalScroll(rememberScrollState())
        ) {
            PageTopBar(stringResource(R.string.settings), onBack = vm::closeOverlay)

            SectionTitle(stringResource(R.string.home_screen))
            Group {
                ChoiceRow(
                    title = stringResource(R.string.columns),
                    options = listOf(4, 5, 6).map { it to it.toString() },
                    selected = columns,
                    onSelect = s::setColumns
                )
                Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                    Text("${stringResource(R.string.icon_size)}: $iconSize dp", style = MaterialTheme.typography.bodyLarge)
                    Slider(
                        value = iconSize.toFloat(),
                        onValueChange = { s.setIconSize(it.roundToInt()) },
                        valueRange = 44f..72f
                    )
                }
                SwitchRow(stringResource(R.string.show_labels), null, labels, s::setShowLabels)
                SwitchRow(stringResource(R.string.show_date), null, showDate, s::setShowDate)
                SwitchRow(stringResource(R.string.show_search), null, showSearch, s::setShowSearch)
            }

            SectionTitle(stringResource(R.string.icons))
            Group {
                ShapePicker(selected = shape, onSelect = s::setIconShape)
                SwitchRow(stringResource(R.string.themed_icons), stringResource(R.string.themed_icons_hint), themed) {
                    s.setThemedIcons(it)
                }
            }

            SectionTitle(stringResource(R.string.animations))
            Group {
                ChoiceRow(
                    title = null,
                    options = listOf(
                        AnimMode.CUSTOM to stringResource(R.string.anim_custom),
                        AnimMode.SYSTEM to stringResource(R.string.anim_system),
                        AnimMode.OFF to stringResource(R.string.anim_off)
                    ),
                    selected = anim,
                    onSelect = s::setAnimMode
                )
                SwitchRow(stringResource(R.string.anim_blur), stringResource(R.string.anim_blur_hint), blur, s::setBlurAnim)
                Text(
                    stringResource(R.string.anim_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 16.dp)
                )
            }

            SectionTitle(stringResource(R.string.notifications))
            Group {
                SwitchRow(stringResource(R.string.notif_dots), stringResource(R.string.notif_dots_hint), dots, s::setDots)
                TextButton(onClick = vm::openNotificationAccess, modifier = Modifier.padding(horizontal = 12.dp)) {
                    Text(stringResource(R.string.grant_access))
                }
            }

            SectionTitle(stringResource(R.string.system))
            Group {
                ActionRow(stringResource(R.string.widgets)) { vm.openOverlay(Overlay.WIDGETS) }
                ActionRow(stringResource(R.string.wallpaper)) { vm.openOverlay(Overlay.WALLPAPERS) }
                ActionRow(stringResource(R.string.default_launcher), vm::openDefaultLauncherSettings)
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

/** Material You settings card: rounded surface that groups related rows. */
@Composable
private fun Group(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh),
        content = content
    )
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 28.dp, end = 24.dp, top = 24.dp, bottom = 8.dp)
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ShapePicker(selected: IconShapeOption, onSelect: (IconShapeOption) -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
        Text(stringResource(R.string.icon_shape), style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(12.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            IconShapeOption.entries.forEach { opt ->
                val isSelected = opt == selected
                val label = stringResource(opt.labelRes)
                Box(
                    Modifier
                        .size(56.dp)
                        .clip(opt.toShape())
                        .background(
                            if (isSelected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.secondaryContainer
                        )
                        .clickable { onSelect(opt) }
                        .semantics { contentDescription = label },
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Icon(
                            Icons.Rounded.Check,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun <T> ChoiceRow(
    title: String?,
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit
) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
        if (title != null) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(8.dp))
        }
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            options.forEachIndexed { index, (value, label) ->
                SegmentedButton(
                    selected = value == selected,
                    onClick = { onSelect(value) },
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = options.size),
                    label = { Text(label, maxLines = 1) }
                )
            }
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            thumbContent = if (checked) {
                { Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(SwitchDefaults.IconSize)) }
            } else null
        )
    }
}

@Composable
private fun ActionRow(title: String, onClick: () -> Unit) {
    Text(
        title,
        style = MaterialTheme.typography.bodyLarge,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 16.dp)
    )
}
