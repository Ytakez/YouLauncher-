package com.youlauncher.app

import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

/** CUSTOM = built-in Material You animation (works on any phone). Old "AUTO" values fall back to CUSTOM. */
enum class AnimMode { CUSTOM, SYSTEM, OFF }
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class DockStyle { PLAIN, PILL }

/** Accent palettes used when dynamic colors are off (or unavailable). */
enum class Accent(val hue: Float) {
    BLUE(215f), TEAL(175f), GREEN(135f), YELLOW(48f), ORANGE(26f), RED(4f), PINK(332f), PURPLE(272f)
}

class LauncherSettings(private val p: SharedPreferences) {
    private inline fun <reified E : Enum<E>> enumPref(key: String, def: E): E =
        runCatching { enumValueOf<E>(p.getString(key, def.name) ?: def.name) }.getOrDefault(def)

    val columns = MutableStateFlow(p.getInt("columns", 5))
    val iconSize = MutableStateFlow(p.getInt("iconSize", 56))
    val showLabels = MutableStateFlow(p.getBoolean("labels", true))
    val themedIcons = MutableStateFlow(p.getBoolean("themed", false))
    val dots = MutableStateFlow(p.getBoolean("dots", true))
    val animMode = MutableStateFlow(enumPref("anim", AnimMode.CUSTOM))
    val animSpeed = MutableStateFlow(p.getFloat("animSpeed", 1f))
    val iconShape = MutableStateFlow(enumPref("shape", IconShapeOption.CIRCLE))

    // theme
    val themeMode = MutableStateFlow(enumPref("themeMode", ThemeMode.SYSTEM))
    val dynamicColor = MutableStateFlow(p.getBoolean("dynamic", true))
    val accent = MutableStateFlow(enumPref("accent", Accent.BLUE))

    // effects
    val stagger = MutableStateFlow(p.getBoolean("fxStagger", true))
    val bounce = MutableStateFlow(p.getBoolean("fxBounce", true))
    val haptics = MutableStateFlow(p.getBoolean("fxHaptics", true))
    val blur = MutableStateFlow(p.getBoolean("fxBlur", true))
    val dim = MutableStateFlow(p.getFloat("dim", 0.12f))
    val drawerOpacity = MutableStateFlow(p.getFloat("drawerOpacity", 0.97f))

    // layout
    val dockStyle = MutableStateFlow(enumPref("dockStyle", DockStyle.PLAIN))
    val showSearch = MutableStateFlow(p.getBoolean("showSearch", true))
    val widgetRadius = MutableStateFlow(p.getInt("widgetRadius", 28))

    fun setColumns(v: Int) { columns.value = v; p.edit().putInt("columns", v).apply() }
    fun setIconSize(v: Int) { iconSize.value = v; p.edit().putInt("iconSize", v).apply() }
    fun setShowLabels(v: Boolean) { showLabels.value = v; p.edit().putBoolean("labels", v).apply() }
    fun setThemedIcons(v: Boolean) { themedIcons.value = v; p.edit().putBoolean("themed", v).apply() }
    fun setDots(v: Boolean) { dots.value = v; p.edit().putBoolean("dots", v).apply() }
    fun setAnimSpeed(v: Float) { animSpeed.value = v; p.edit().putFloat("animSpeed", v).apply() }
    fun setAnimMode(v: AnimMode) { animMode.value = v; p.edit().putString("anim", v.name).apply() }
    fun setIconShape(v: IconShapeOption) { iconShape.value = v; p.edit().putString("shape", v.name).apply() }

    fun setThemeMode(v: ThemeMode) { themeMode.value = v; p.edit().putString("themeMode", v.name).apply() }
    fun setDynamicColor(v: Boolean) { dynamicColor.value = v; p.edit().putBoolean("dynamic", v).apply() }
    fun setAccent(v: Accent) { accent.value = v; p.edit().putString("accent", v.name).apply() }

    fun setStagger(v: Boolean) { stagger.value = v; p.edit().putBoolean("fxStagger", v).apply() }
    fun setBounce(v: Boolean) { bounce.value = v; p.edit().putBoolean("fxBounce", v).apply() }
    fun setHaptics(v: Boolean) { haptics.value = v; p.edit().putBoolean("fxHaptics", v).apply() }
    fun setBlur(v: Boolean) { blur.value = v; p.edit().putBoolean("fxBlur", v).apply() }
    fun setDim(v: Float) { dim.value = v; p.edit().putFloat("dim", v).apply() }
    fun setDrawerOpacity(v: Float) { drawerOpacity.value = v; p.edit().putFloat("drawerOpacity", v).apply() }

    fun setDockStyle(v: DockStyle) { dockStyle.value = v; p.edit().putString("dockStyle", v.name).apply() }
    fun setShowSearch(v: Boolean) { showSearch.value = v; p.edit().putBoolean("showSearch", v).apply() }
    fun setWidgetRadius(v: Int) { widgetRadius.value = v; p.edit().putInt("widgetRadius", v).apply() }
}

/** Effects flags handed down the tree so every icon can read them. */
data class Fx(val stagger: Boolean = true, val bounce: Boolean = true, val haptics: Boolean = true)
val LocalFx = androidx.compose.runtime.staticCompositionLocalOf { Fx() }
