package com.youlauncher.app

import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

/** CUSTOM = built-in Material You animation (works on any phone). Old "AUTO" values fall back to CUSTOM. */
enum class AnimMode { CUSTOM, SYSTEM, OFF }

class LauncherSettings(private val p: SharedPreferences) {
    val columns = MutableStateFlow(p.getInt("columns", 5))
    val iconSize = MutableStateFlow(p.getInt("iconSize", 56))
    val showLabels = MutableStateFlow(p.getBoolean("labels", true))
    val themedIcons = MutableStateFlow(p.getBoolean("themed", false))
    val dots = MutableStateFlow(p.getBoolean("dots", true))
    val animMode = MutableStateFlow(
        runCatching { AnimMode.valueOf(p.getString("anim", "CUSTOM") ?: "CUSTOM") }.getOrDefault(AnimMode.CUSTOM)
    )
    val iconShape = MutableStateFlow(
        runCatching { IconShapeOption.valueOf(p.getString("shape", "CIRCLE") ?: "CIRCLE") }
            .getOrDefault(IconShapeOption.CIRCLE)
    )

    fun setColumns(v: Int) { columns.value = v; p.edit().putInt("columns", v).apply() }
    fun setIconSize(v: Int) { iconSize.value = v; p.edit().putInt("iconSize", v).apply() }
    fun setShowLabels(v: Boolean) { showLabels.value = v; p.edit().putBoolean("labels", v).apply() }
    fun setThemedIcons(v: Boolean) { themedIcons.value = v; p.edit().putBoolean("themed", v).apply() }
    fun setDots(v: Boolean) { dots.value = v; p.edit().putBoolean("dots", v).apply() }
    fun setAnimMode(v: AnimMode) { animMode.value = v; p.edit().putString("anim", v.name).apply() }
    fun setIconShape(v: IconShapeOption) { iconShape.value = v; p.edit().putString("shape", v.name).apply() }
}
