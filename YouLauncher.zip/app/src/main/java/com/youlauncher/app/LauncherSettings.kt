package com.youlauncher.app

import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

/** CUSTOM = built-in Material You animation (works on any phone). Old "AUTO" values fall back to CUSTOM. */
enum class AnimMode { CUSTOM, SYSTEM, OFF }

/** App theme: follow the system, or force light / dark. */
enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Accent color of the launcher UI. SYSTEM = Material You colors from the wallpaper (Android 12+). */
enum class AccentOption(val hue: Float, val labelRes: Int) {
    SYSTEM(-1f, R.string.accent_system),
    BLUE(215f, R.string.accent_blue),
    TEAL(175f, R.string.accent_teal),
    MINT(152f, R.string.accent_mint),
    SKY(200f, R.string.accent_sky),
    GREEN(125f, R.string.accent_green),
    YELLOW(48f, R.string.accent_yellow),
    RED(5f, R.string.accent_red),
    PINK(330f, R.string.accent_pink),
    PURPLE(272f, R.string.accent_purple),
    LAVENDER(255f, R.string.accent_lavender),
    PEACH(22f, R.string.accent_peach)
}

class LauncherSettings(private val p: SharedPreferences) {
    val columns = MutableStateFlow(p.getInt("columns", 5))
    val iconSize = MutableStateFlow(p.getInt("iconSize", 56))
    val showLabels = MutableStateFlow(p.getBoolean("labels", true))
    val themedIcons = MutableStateFlow(p.getBoolean("themed", false) || (p.getString("iconPalette", null)?.let { it != "ORIGINAL" } ?: false))
    /** Icon recolor palette. Old "themed icons = on" settings migrate to THEME. */
    val iconPalette = MutableStateFlow(
        p.getString("iconPalette", null)?.let { n -> runCatching { IconPalette.valueOf(n) }.getOrNull() }
            ?: if (p.getBoolean("themed", false)) IconPalette.THEME else IconPalette.ORIGINAL
    )
    /** Tonal Material 3 container behind home screen widgets. */
    val widgetCards = MutableStateFlow(p.getBoolean("widgetCards", true))
    val dots = MutableStateFlow(p.getBoolean("dots", true))
    val animMode = MutableStateFlow(
        runCatching { AnimMode.valueOf(p.getString("anim", "CUSTOM") ?: "CUSTOM") }.getOrDefault(AnimMode.CUSTOM)
    )
    /** true = app list (drawer) with letters; false = no drawer, every app lives on the home screen. */
    val drawerEnabled = MutableStateFlow(p.getBoolean("drawerOn", true))
    val showDate = MutableStateFlow(p.getBoolean("showDate", false))
    val homeClock = MutableStateFlow(
        runCatching { HomeClockStyle.valueOf(p.getString("homeClock", "FLOWER") ?: "FLOWER") }.getOrDefault(HomeClockStyle.FLOWER)
    )
    val showSearch = MutableStateFlow(p.getBoolean("showSearch", true))
    val blurAnim = MutableStateFlow(p.getBoolean("blurAnim", true))
    val iconShape = MutableStateFlow(
        runCatching { IconShapeOption.valueOf(p.getString("shape", "CIRCLE") ?: "CIRCLE") }
            .getOrDefault(IconShapeOption.CIRCLE)
    )

    val labelSize = MutableStateFlow(p.getInt("labelSize", 1))          // 0 small, 1 normal, 2 large
    val folderAlpha = MutableStateFlow(p.getInt("folderAlpha", 22))    // folder tile opacity, %
    val dim = MutableStateFlow(p.getInt("dim", 0))                     // wallpaper darkening, %
    val pageDots = MutableStateFlow(p.getBoolean("pageDots", true))
    val dockBg = MutableStateFlow(p.getBoolean("dockBg", false))
    val drawerCols = MutableStateFlow(p.getInt("drawerCols", 0))       // 0 = same as home
    val themeMode = MutableStateFlow(
        runCatching { ThemeMode.valueOf(p.getString("themeMode", "SYSTEM") ?: "SYSTEM") }.getOrDefault(ThemeMode.SYSTEM)
    )
    val accent = MutableStateFlow(
        runCatching { AccentOption.valueOf(p.getString("accent", "SYSTEM") ?: "SYSTEM") }.getOrDefault(AccentOption.SYSTEM)
    )

    fun setLabelSize(v: Int) { labelSize.value = v; p.edit().putInt("labelSize", v).apply() }
    fun setFolderAlpha(v: Int) { folderAlpha.value = v; p.edit().putInt("folderAlpha", v).apply() }
    fun setDim(v: Int) { dim.value = v; p.edit().putInt("dim", v).apply() }
    fun setPageDots(v: Boolean) { pageDots.value = v; p.edit().putBoolean("pageDots", v).apply() }
    fun setDockBg(v: Boolean) { dockBg.value = v; p.edit().putBoolean("dockBg", v).apply() }
    fun setDrawerCols(v: Int) { drawerCols.value = v; p.edit().putInt("drawerCols", v).apply() }
    fun setThemeMode(v: ThemeMode) { themeMode.value = v; p.edit().putString("themeMode", v.name).apply() }
    fun setAccent(v: AccentOption) { accent.value = v; p.edit().putString("accent", v.name).apply() }

    fun setColumns(v: Int) { columns.value = v; p.edit().putInt("columns", v).apply() }
    fun setIconSize(v: Int) { iconSize.value = v; p.edit().putInt("iconSize", v).apply() }
    fun setShowLabels(v: Boolean) { showLabels.value = v; p.edit().putBoolean("labels", v).apply() }
    fun setThemedIcons(v: Boolean) { themedIcons.value = v; p.edit().putBoolean("themed", v).apply() }
    fun setIconPalette(v: IconPalette) {
        iconPalette.value = v
        themedIcons.value = v != IconPalette.ORIGINAL
        p.edit().putString("iconPalette", v.name).putBoolean("themed", v != IconPalette.ORIGINAL).apply()
    }
    fun setWidgetCards(v: Boolean) { widgetCards.value = v; p.edit().putBoolean("widgetCards", v).apply() }
    fun setDots(v: Boolean) { dots.value = v; p.edit().putBoolean("dots", v).apply() }
    fun setAnimMode(v: AnimMode) { animMode.value = v; p.edit().putString("anim", v.name).apply() }
    fun setHomeClock(v: HomeClockStyle) { homeClock.value = v; p.edit().putString("homeClock", v.name).apply() }
    fun setDrawerEnabled(v: Boolean) { drawerEnabled.value = v; p.edit().putBoolean("drawerOn", v).apply() }
    fun setShowDate(v: Boolean) { showDate.value = v; p.edit().putBoolean("showDate", v).apply() }
    fun setShowSearch(v: Boolean) { showSearch.value = v; p.edit().putBoolean("showSearch", v).apply() }
    fun setBlurAnim(v: Boolean) { blurAnim.value = v; p.edit().putBoolean("blurAnim", v).apply() }
    fun setIconShape(v: IconShapeOption) { iconShape.value = v; p.edit().putString("shape", v.name).apply() }

    // ---------- lock screen / always-on display ----------
    private inline fun <reified E : Enum<E>> readEnum(key: String, def: E): E =
        runCatching { enumValueOf<E>(p.getString(key, def.name) ?: def.name) }.getOrDefault(def)

    val lockEnabled = MutableStateFlow(p.getBoolean("lockOn", false))
    val lockClock = MutableStateFlow(readEnum("lockClock", LockClockStyle.STACKED))
    val lockWeight = MutableStateFlow(p.getInt("lockWeight", 4))              // 0..4, thin..black
    val lockColor = MutableStateFlow(readEnum("lockColor", LockColor.WHITE))
    val lockShape = MutableStateFlow(p.getBoolean("lockShape", true))         // photo cut out in a blob
    val lockWall = MutableStateFlow(p.getString("lockWall", "") ?: "")        // "", built-in id or "gallery@..."
    val lockLeft = MutableStateFlow(readEnum("lockLeft", LockShortcut.TORCH))
    val lockRight = MutableStateFlow(readEnum("lockRight", LockShortcut.CAMERA))
    val lockNotifOn = MutableStateFlow(p.getBoolean("lockNotifOn", true))
    val lockNotifLayout = MutableStateFlow(readEnum("lockNotifLayout", LockNotifLayout.COMPACT))
    val lockHideText = MutableStateFlow(p.getBoolean("lockHideText", false))
    val lockDepth = MutableStateFlow(p.getBoolean("lockDepth", false))      // clock goes behind the subject of the photo
    val lockSwipe = MutableStateFlow(p.getBoolean("lockSwipe", true))       // swipe up to unlock
    val aodEnabled = MutableStateFlow(p.getBoolean("aodOn", false))
    val aodDuration = MutableStateFlow(readEnum("aodDuration", AodDuration.S60))
    val aodNotif = MutableStateFlow(p.getBoolean("aodNotif", true))

    fun setLockEnabled(v: Boolean) { lockEnabled.value = v; p.edit().putBoolean("lockOn", v).apply() }
    fun setLockClock(v: LockClockStyle) { lockClock.value = v; p.edit().putString("lockClock", v.name).apply() }
    fun setLockWeight(v: Int) { lockWeight.value = v; p.edit().putInt("lockWeight", v).apply() }
    fun setLockColor(v: LockColor) { lockColor.value = v; p.edit().putString("lockColor", v.name).apply() }
    fun setLockShape(v: Boolean) { lockShape.value = v; p.edit().putBoolean("lockShape", v).apply() }
    fun setLockWall(v: String) { lockWall.value = v; p.edit().putString("lockWall", v).apply() }
    fun setLockLeft(v: LockShortcut) { lockLeft.value = v; p.edit().putString("lockLeft", v.name).apply() }
    fun setLockRight(v: LockShortcut) { lockRight.value = v; p.edit().putString("lockRight", v.name).apply() }
    fun setLockNotifOn(v: Boolean) { lockNotifOn.value = v; p.edit().putBoolean("lockNotifOn", v).apply() }
    fun setLockNotifLayout(v: LockNotifLayout) { lockNotifLayout.value = v; p.edit().putString("lockNotifLayout", v.name).apply() }
    fun setLockHideText(v: Boolean) { lockHideText.value = v; p.edit().putBoolean("lockHideText", v).apply() }
    fun setLockDepth(v: Boolean) { lockDepth.value = v; p.edit().putBoolean("lockDepth", v).apply() }
    fun setLockSwipe(v: Boolean) { lockSwipe.value = v; p.edit().putBoolean("lockSwipe", v).apply() }
    fun setAodEnabled(v: Boolean) { aodEnabled.value = v; p.edit().putBoolean("aodOn", v).apply() }
    fun setAodDuration(v: AodDuration) { aodDuration.value = v; p.edit().putString("aodDuration", v.name).apply() }
    fun setAodNotif(v: Boolean) { aodNotif.value = v; p.edit().putBoolean("aodNotif", v).apply() }
}
