package com.youlauncher.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Keeps an eye on the screen: when it goes off it starts the always-on display, when it comes on it
 * starts the lock screen. A 1x1 invisible overlay window (permission "display over other apps") is what
 * lets Android allow a background service to open an activity.
 */
class LockService : Service() {

    private var overlay: View? = null
    private val handler = Handler(Looper.getMainLooper())

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> onScreenOff()
                Intent.ACTION_SCREEN_ON -> onScreenOn()
                Intent.ACTION_USER_PRESENT -> LockActivity.finishCurrent(onlyIfOlderThanMs = 1500L)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        ensureOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureOverlay()
        return START_STICKY
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        removeOverlay()
        super.onDestroy()
    }

    private fun settings() = LauncherSettings(getSharedPreferences("launcher", MODE_PRIVATE))

    private fun onScreenOff() {
        val s = settings()
        if (!s.lockEnabled.value && !s.aodEnabled.value) return
        val mode = LockState.mode.value
        if (mode == LockMode.AOD) {
            // the AOD keeps the screen awake, so an "off" while it is shown means the power button: really turn off
            LockState.mode.value = LockMode.SLEEP
            return
        }
        if (s.aodEnabled.value) {
            LockState.pendingAod = true
            LockState.aodExpired = false
            handler.postDelayed({ LockState.pendingAod = false }, 4000L)
            launch(LockMode.AOD)
        } else if (mode != LockMode.NONE) {
            LockState.mode.value = LockMode.SLEEP
        }
    }

    private fun onScreenOn() {
        val s = settings()
        if (LockState.mode.value == LockMode.AOD || LockState.pendingAod) return // our own wake-up for the AOD
        if (s.lockEnabled.value) {
            launch(LockMode.LOCK)
        } else if (LockState.mode.value != LockMode.NONE) {
            LockActivity.finishCurrent()
        }
    }

    private fun launch(mode: LockMode) {
        ensureOverlay()
        LockActivity.show(this, mode)
    }

    // ---------- invisible overlay (lets the service start activities from the background) ----------
    private fun ensureOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return
        try {
            val v = View(this)
            val lp = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            getSystemService(WindowManager::class.java).addView(v, lp)
            overlay = v
        } catch (_: Throwable) {}
    }

    private fun removeOverlay() {
        val v = overlay ?: return
        try { getSystemService(WindowManager::class.java).removeView(v) } catch (_: Throwable) {}
        overlay = null
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.lock_service_title), NotificationManager.IMPORTANCE_MIN)
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle(getString(R.string.lock_service_title))
            .setContentText(getString(R.string.lock_service_text))
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    companion object {
        private const val CHANNEL = "lock_service"
        private const val NOTIF_ID = 4711

        fun start(ctx: Context) {
            try { ContextCompat.startForegroundService(ctx, Intent(ctx, LockService::class.java)) } catch (_: Throwable) {}
        }

        fun stop(ctx: Context) {
            try { ctx.stopService(Intent(ctx, LockService::class.java)) } catch (_: Throwable) {}
        }

        /** Opens "Display over other apps" for this app when the permission is still missing. */
        fun requestOverlayIfNeeded(ctx: Context) {
            if (Settings.canDrawOverlays(ctx)) return
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Throwable) {}
        }

        /** Runs the service only while the lock screen or the always-on display is switched on. */
        fun sync(ctx: Context, s: LauncherSettings) {
            if (s.lockEnabled.value || s.aodEnabled.value) start(ctx) else stop(ctx)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val s = LauncherSettings(context.getSharedPreferences("launcher", Context.MODE_PRIVATE))
        LockService.sync(context, s)
    }
}
