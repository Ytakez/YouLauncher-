package com.youlauncher.app

import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

private val EmphasizedOpen = CubicBezierEasing(0.2f, 0f, 0f, 1f)

/**
 * App open / close animation, Meizu / Xiaomi style: a circle grows out of the tapped icon, from the
 * point the finger touched, until it covers the whole screen. The app icon sits in the middle and
 * dissolves at the end. Closing shrinks the circle back into the icon.
 *
 * [progress] is hoisted so the home screen can scale back / dim in sync.
 */
@Composable
fun LaunchOverlay(vm: LauncherViewModel, progress: Animatable<Float, AnimationVector1D>) {
    val anim by vm.launchAnim.collectAsStateWithLifecycle()
    val themed by vm.settings.themedIcons.collectAsStateWithLifecycle()
    val shape = LocalIconShape.current
    val blurOn by vm.settings.blurAnim.collectAsStateWithLifecycle()
    val speed by vm.settings.animSpeed.collectAsStateWithLifecycle()
    var last by remember { mutableStateOf<LaunchAnim?>(null) }

    LaunchedEffect(anim?.id) {
        val a = anim
        if (a != null) {
            last = a
            progress.snapTo(0f)
            progress.animateTo(1f, tween(durationMillis = (420 * animSpeedFactor(speed)).toInt(), easing = EmphasizedOpen))
            vm.commitLaunch(a)
        } else {
            progress.animateTo(
                0f,
                spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = 420f)
            )
        }
    }

    val a = last ?: return
    val p = progress.value.coerceIn(0f, 1f)
    if (p <= 0.001f) return
    val surface = MaterialTheme.colorScheme.surface
    // the circle takes a soft tint of the primary container, then settles into the surface colour
    val cardTint = MaterialTheme.colorScheme.primaryContainer

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val wPx = with(density) { maxWidth.toPx() }
        val hPx = with(density) { maxHeight.toPx() }

        // the tap point: the centre of the tapped icon
        val cx = a.rect.center.x
        val cy = a.rect.center.y
        val iconPx = a.rect.width
        val iconDp = with(density) { iconPx.toDp() }
        val icon = rememberAppIcon(a.key, themed, iconDp)

        // closing = the user is returning home: the home icon is already there, so the circle
        // shrinks back and dissolves into it without drawing its own icon
        val closing = anim == null

        // radius: from the icon to the farthest screen corner
        val startR = iconPx / 2f
        val fullR = hypot(max(cx, wPx - cx), max(cy, hPx - cy))
        val r = lerp(startR, fullR, p)

        val circleAlpha = if (closing) (p / 0.5f).coerceIn(0f, 1f) else (p * 5f).coerceIn(0f, 1f)
        val cardColor = lerp(cardTint, surface, ((p - 0.25f) / 0.6f).coerceIn(0f, 1f))
        val iconScale = 1f + p * 0.18f
        val iconAlpha = if (closing) 0f else (1f - ((p - 0.45f) / 0.4f)).coerceIn(0f, 1f)

        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    // soft, frosted edge of the circle while it moves
                    if (blurOn && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val br = sin(p * PI.toFloat()) * 8f * this.density
                        renderEffect = if (br > 0.5f) BlurEffect(br, br, TileMode.Decal) else null
                    }
                }
                .drawBehind {
                    drawCircle(
                        color = cardColor.copy(alpha = circleAlpha),
                        radius = r,
                        center = Offset(cx, cy)
                    )
                    // thin light rim that fades out as the circle covers the screen
                    drawCircle(
                        color = Color.White.copy(alpha = 0.3f * circleAlpha * (1f - p)),
                        radius = r,
                        center = Offset(cx, cy),
                        style = Stroke(1.5.dp.toPx())
                    )
                }
        )

        icon?.let {
            Image(
                bitmap = it,
                contentDescription = null,
                modifier = Modifier
                    .offset { IntOffset((cx - iconPx / 2f).roundToInt(), (cy - iconPx / 2f).roundToInt()) }
                    .size(iconDp)
                    .clip(shape)
                    .graphicsLayer {
                        scaleX = iconScale
                        scaleY = iconScale
                        alpha = iconAlpha
                    }
            )
        }
    }
}
