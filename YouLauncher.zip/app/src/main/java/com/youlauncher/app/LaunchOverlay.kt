package com.youlauncher.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp as colorLerp
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.util.lerp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.min
import kotlin.math.roundToInt

/** The app is started while the surface is still growing, so its own fade-in overlaps the animation. */
private const val START_APP_AT = 0.3f

/**
 * Built-in Material You launch / close animation (independent of system animations).
 *
 * Driven by critically damped springs (Material 3 Expressive "spatial" motion): no fixed duration,
 * natural acceleration, never overshoots. The speed slider in settings scales the spring stiffness.
 *
 * Open: the tapped icon grows into a surface that fills the screen (its tone slides from the icon's
 * container color to the surface color); the app starts a little earlier and cross-fades in.
 * Close: when the user comes back, the surface collapses smoothly into the icon.
 *
 * Everything that changes every frame (position, size, corners, alpha) is read in the layout / draw phase,
 * so the overlay is not recomposed on each frame - that is what makes it smooth.
 */
@Composable
fun LaunchOverlay(vm: LauncherViewModel, progress: Animatable<Float, AnimationVector1D>) {
    val anim by vm.launchAnim.collectAsStateWithLifecycle()
    val themed by vm.settings.themedIcons.collectAsStateWithLifecycle()
    val shape = LocalIconShape.current
    var last by remember { mutableStateOf<LaunchAnim?>(null) }

    LaunchedEffect(anim?.id) {
        val a = anim
        if (a != null) {
            last = a
            progress.snapTo(0f)
            val speed = vm.settings.animSpeed.value.coerceIn(0.5f, 2f)
            val k = speed * speed
            coroutineScope {
                launch {
                    snapshotFlow { progress.value }.first { it >= START_APP_AT }
                    vm.commitLaunch(a)
                }
                progress.animateTo(1f, spring(dampingRatio = 1f, stiffness = 240f * k, visibilityThreshold = 0.001f))
            }
        } else {
            val speed = vm.settings.animSpeed.value.coerceIn(0.5f, 2f)
            progress.animateTo(0f, spring(dampingRatio = 1f, stiffness = 260f * speed * speed, visibilityThreshold = 0.001f))
        }
    }

    val a = last ?: return
    val surface = MaterialTheme.colorScheme.surface
    val container = MaterialTheme.colorScheme.secondaryContainer

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val wPx = with(density) { maxWidth.toPx() }
        val hPx = with(density) { maxHeight.toPx() }
        val iconDp = with(density) { a.rect.width.toDp() }
        val icon = rememberAppIcon(a.key, themed, iconDp)
        val startRadius = a.rect.width / 2f

        Box(
            Modifier
                .graphicsLayer { alpha = if (progress.value <= 0.001f) 0f else 1f }
                .offset {
                    val p = progress.value.coerceIn(0f, 1f)
                    IntOffset(lerp(a.rect.left, 0f, p).roundToInt(), lerp(a.rect.top, 0f, p).roundToInt())
                }
                .layout { measurable, _ ->
                    val p = progress.value.coerceIn(0f, 1f)
                    val w = lerp(a.rect.width, wPx, p).roundToInt().coerceAtLeast(1)
                    val h = lerp(a.rect.height, hPx, p).roundToInt().coerceAtLeast(1)
                    val placeable = measurable.measure(Constraints.fixed(w, h))
                    layout(w, h) { placeable.place(0, 0) }
                }
                .drawBehind {
                    val p = progress.value.coerceIn(0f, 1f)
                    val rad = min(
                        lerp(startRadius, 0f, FastOutSlowInEasing.transform(p)),
                        min(size.width, size.height) / 2f
                    )
                    drawRoundRect(
                        color = colorLerp(container, surface, FastOutSlowInEasing.transform(p))
                            .copy(alpha = (p * 4f).coerceIn(0f, 1f)),
                        cornerRadius = CornerRadius(rad, rad)
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            icon?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    modifier = Modifier
                        .size(iconDp)
                        .clip(shape)
                        .graphicsLayer {
                            val p = progress.value.coerceIn(0f, 1f)
                            val s = 1f + p * 0.5f
                            scaleX = s
                            scaleY = s
                            alpha = (1f - p * 2.5f).coerceIn(0f, 1f)
                        }
                )
            }
        }
    }
}
