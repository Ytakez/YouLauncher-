package com.youlauncher.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import android.os.Build
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.roundToInt

private val EmphasizedOpen = CubicBezierEasing(0.2f, 0f, 0f, 1f)

/**
 * Built-in Material You launch / close animation. It does not depend on the phone's system
 * animations, so it works everywhere.
 *
 * Open: the tapped icon (in the chosen shape) grows into a rounded surface that fills the screen
 * (corner radius shrinks to the screen corner and then to 0), the icon scales up and fades, then the app starts.
 * Close: when the user returns to the launcher the surface springs back into the icon.
 *
 * [progress] is hoisted so the home screen can scale back / dim in sync (Pixel-like depth effect).
 */
@Composable
fun LaunchOverlay(vm: LauncherViewModel, progress: Animatable<Float, AnimationVector1D>) {
    val anim by vm.launchAnim.collectAsStateWithLifecycle()
    val themed by vm.settings.themedIcons.collectAsStateWithLifecycle()
    val shape = LocalIconShape.current
    val blurOn by vm.settings.blurAnim.collectAsStateWithLifecycle()
    var last by remember { mutableStateOf<LaunchAnim?>(null) }

    LaunchedEffect(anim?.id) {
        val a = anim
        if (a != null) {
            last = a
            progress.snapTo(0f)
            progress.animateTo(1f, tween(durationMillis = 360, easing = EmphasizedOpen))
            vm.commitLaunch(a)
        } else {
            progress.animateTo(
                0f,
                spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = 420f)
            )
        }
    }

    val a = last ?: return
    val p = progress.value.coerceIn(0f, 1f)
    if (p <= 0.001f) return
    val surface = MaterialTheme.colorScheme.surface

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val wPx = with(density) { maxWidth.toPx() }
        val hPx = with(density) { maxHeight.toPx() }
        val l = lerp(a.rect.left, 0f, p)
        val t = lerp(a.rect.top, 0f, p)
        val r = lerp(a.rect.right, wPx, p)
        val b = lerp(a.rect.bottom, hPx, p)
        val iconDp = with(density) { a.rect.width.toDp() }
        val icon = rememberAppIcon(a.key, themed, iconDp)

        // corner radius: circle -> device-like corner (32dp) -> square
        val screenCorner = with(density) { 32.dp.toPx() }
        val maxR = min(r - l, b - t) / 2f
        val radius = min(
            maxR,
            if (p < 0.5f) lerp(maxR, screenCorner, p / 0.5f) else lerp(screenCorner, 0f, (p - 0.5f) / 0.5f)
        )
        val bgAlpha = (p * 5f).coerceIn(0f, 1f)

        Box(
            Modifier
                .offset { IntOffset(l.roundToInt(), t.roundToInt()) }
                .size(with(density) { (r - l).toDp() }, with(density) { (b - t).toDp() })
                .graphicsLayer {
                    // soft, frosted edge in the middle of the open / close motion
                    if (blurOn && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val br = sin(p * PI.toFloat()) * 10f * this.density
                        renderEffect = if (br > 0.5f) BlurEffect(br, br, TileMode.Decal) else null
                    }
                }
                .drawBehind {
                    drawRoundRect(
                        color = surface.copy(alpha = bgAlpha),
                        cornerRadius = CornerRadius(radius, radius)
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            icon?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    modifier = Modifier
                        .size(iconDp)
                        .clip(shape)
                        .graphicsLayer {
                            val s = 1f + p * 0.6f
                            scaleX = s
                            scaleY = s
                            alpha = (1f - p * 2.2f).coerceIn(0f, 1f)
                            // the icon melts into blur as it grows
                            if (blurOn && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                val ir = p * 18f * this.density
                                renderEffect = if (ir > 0.5f) BlurEffect(ir, ir, TileMode.Decal) else null
                            }
                        }
                )
            }
        }
    }
}
