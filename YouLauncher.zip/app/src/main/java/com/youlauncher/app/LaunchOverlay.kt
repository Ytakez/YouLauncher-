package com.youlauncher.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp as colorLerp
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.min
import kotlin.math.roundToInt

/** The app is started while the window is still growing, so its own fade-in overlaps the animation. */
private const val START_APP_AT = 0.45f

/** Corner radius of the "window" while it travels between the icon and the full screen. */
private const val WINDOW_CORNER_DP = 28f

/**
 * Pixel-style launch / close animation (independent of system animations).
 *
 * Open: the tapped icon turns into a small rounded app window that grows from the icon to the whole
 * screen. Its corners go from the icon shape to large window corners, stay large while it grows and
 * square off only at the very end. The launched app starts half way and fades in over the window.
 * Close: the same path in reverse - the window shrinks back into the icon and the icon reappears.
 *
 * Horizontal and vertical motion run on slightly different curves, so the window travels along a soft
 * arc instead of a straight line. Behind it the home screen blurs (see MainActivity).
 *
 * Both directions are driven by critically damped springs, so the motion is natural, never overshoots
 * and can be interrupted at any moment. The speed slider in settings scales the spring stiffness.
 *
 * Everything that changes every frame (position, size, corners, colour) is read in the layout / draw
 * phase, so the overlay is not recomposed on each frame.
 */
@Composable
fun LaunchOverlay(vm: LauncherViewModel, progress: Animatable<Float, AnimationVector1D>) {
    val anim by vm.launchAnim.collectAsStateWithLifecycle()
    val themed by vm.settings.themedIcons.collectAsStateWithLifecycle()
    val shape = LocalIconShape.current
    var last by remember { mutableStateOf<LaunchAnim?>(null) }

    LaunchedEffect(anim?.id) {
        val a = anim
        val speed = vm.settings.animSpeed.value.coerceIn(0.5f, 2f)
        val k = speed * speed
        if (a != null) {
            last = a
            progress.snapTo(0f)
            coroutineScope {
                launch {
                    snapshotFlow { progress.value }.first { it >= START_APP_AT }
                    vm.commitLaunch(a)
                }
                progress.animateTo(1f, spring(dampingRatio = 1f, stiffness = 320f * k, visibilityThreshold = 0.001f))
            }
        } else if (vm.skipCloseAnim) {
            vm.skipCloseAnim = false
            progress.snapTo(0f)
        } else {
            progress.animateTo(0f, spring(dampingRatio = 1f, stiffness = 340f * k, visibilityThreshold = 0.001f))
        }
    }

    val a = last ?: return
    val surface = MaterialTheme.colorScheme.surface
    val container = MaterialTheme.colorScheme.secondaryContainer

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val wPx = with(density) { maxWidth.toPx() }
        val hPx = with(density) { maxHeight.toPx() }
        val iconDp = with(density) { a.rect.width.toDp() }
        val icon = rememberAppIcon(a.key, themed, iconDp)
        val startRadius = a.rect.width / 2f
        val windowCorner = with(density) { WINDOW_CORNER_DP.dp.toPx() }

        Box(
            Modifier
                .graphicsLayer { alpha = if (progress.value <= 0.001f) 0f else 1f }
                .offset {
                    val p = progress.value.coerceIn(0f, 1f)
                    val xp = FastOutSlowInEasing.transform(p)
                    IntOffset(lerp(a.rect.left, 0f, xp).roundToInt(), lerp(a.rect.top, 0f, p).roundToInt())
                }
                .layout { measurable, _ ->
                    val p = progress.value.coerceIn(0f, 1f)
                    val xp = FastOutSlowInEasing.transform(p)
                    val w = lerp(a.rect.width, wPx, xp).roundToInt().coerceAtLeast(1)
                    val h = lerp(a.rect.height, hPx, p).roundToInt().coerceAtLeast(1)
                    val placeable = measurable.measure(Constraints.fixed(w, h))
                    layout(w, h) { placeable.place(0, 0) }
                }
                .drawBehind {
                    val p = progress.value.coerceIn(0f, 1f)
                    val wanted = when {
                        p < 0.3f -> lerp(startRadius, windowCorner, FastOutSlowInEasing.transform(p / 0.3f))
                        p < 0.85f -> windowCorner
                        else -> lerp(windowCorner, 0f, (p - 0.85f) / 0.15f)
                    }
                    val rad = min(wanted, min(size.width, size.height) / 2f)
                    val tone = FastOutSlowInEasing.transform((p * 1.6f).coerceIn(0f, 1f))
                    drawRoundRect(
                        color = colorLerp(container, surface, tone).copy(alpha = (p * 4f).coerceIn(0f, 1f)),
                        cornerRadius = CornerRadius(rad, rad)
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            icon?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    modifier = Modifier
                        .size(iconDp)
                        .clip(shape)
                        .graphicsLayer {
                            val p = progress.value.coerceIn(0f, 1f)
                            val s = 1f + p * 0.5f
                            scaleX = s
                            scaleY = s
                            alpha = (1f - p * 2.5f).coerceIn(0f, 1f)
                        }
                )
            }
        }
    }
}
