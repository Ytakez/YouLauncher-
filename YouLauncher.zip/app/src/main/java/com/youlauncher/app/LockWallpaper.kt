package com.youlauncher.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.LruCache
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Wallpapers of the lock screen: the built-in generated ones or a photo copied from the gallery. */
object LockWall {
    private val cache = object : LruCache<String, Bitmap>(3) {}

    fun load(ctx: Context, id: String, w: Int, h: Int): Bitmap? {
        val key = "$id|$w|$h"
        cache.get(key)?.let { return it }
        val bmp = try { build(ctx, id, w, h) } catch (_: Throwable) { null }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }

    private fun build(ctx: Context, id: String, w: Int, h: Int): Bitmap? {
        if (id.startsWith("gallery")) {
            val f = File(ctx.filesDir, "lock_wall.jpg")
            if (f.exists()) return BitmapFactory.decodeFile(f.path)
        }
        val spec = WallpaperSpec.all.firstOrNull { it.id == id } ?: WallpaperSpec.all.first()
        return spec.render(w, h)
    }

    /** Copies a picked photo into the app (scaled down) so it keeps working without any storage permission. */
    fun import(ctx: Context, uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val raw = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false
            val longest = max(raw.width, raw.height)
            val bmp = if (longest > 1600) {
                val k = 1600f / longest
                Bitmap.createScaledBitmap(raw, (raw.width * k).toInt(), (raw.height * k).toInt(), true)
            } else raw
            File(ctx.filesDir, "lock_wall.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            true
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * The main subject of the photo on a transparent background (ML Kit subject segmentation, needs Google Play
     * services). Same size as the wallpaper, so it can be drawn exactly over it. Cached on disk. Null if nothing was found.
     */
    suspend fun cutout(ctx: Context, id: String, w: Int, h: Int): Bitmap? {
        val f = File(ctx.cacheDir, "cut_${id.hashCode()}_${w}x$h.png")
        if (f.exists()) return try { BitmapFactory.decodeFile(f.path) } catch (_: Throwable) { null }
        val base = load(ctx, id, w, h) ?: return null
        val fg = segment(base) ?: return null
        try { f.outputStream().use { fg.compress(Bitmap.CompressFormat.PNG, 100, it) } } catch (_: Throwable) {}
        return fg
    }

    private suspend fun segment(bmp: Bitmap): Bitmap? = suspendCancellableCoroutine { c ->
        try {
            val opts = SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
            SubjectSegmentation.getClient(opts)
                .process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { r -> if (c.isActive) c.resume(r.foregroundBitmap) }
                .addOnFailureListener { if (c.isActive) c.resume(null) }
        } catch (_: Throwable) {
            if (c.isActive) c.resume(null)
        }
    }

    fun thumb(ctx: Context, id: String): Bitmap? = try {
        if (id.startsWith("gallery")) {
            val f = File(ctx.filesDir, "lock_wall.jpg")
            if (f.exists()) BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 8 }) else null
        } else {
            (WallpaperSpec.all.firstOrNull { it.id == id } ?: WallpaperSpec.all.first()).render(108, 192)
        }
    } catch (_: Throwable) {
        null
    }
}

@Composable
fun rememberLockWallpaper(id: String): ImageBitmap? {
    val ctx = LocalContext.current.applicationContext
    val dm = ctx.resources.displayMetrics
    val scale = minOf(1f, 1080f / dm.widthPixels.coerceAtLeast(1))
    val w = (dm.widthPixels * scale).toInt().coerceAtLeast(240)
    val h = (dm.heightPixels * scale).toInt().coerceAtLeast(400)
    val state = produceState<ImageBitmap?>(null, id) {
        value = withContext(Dispatchers.IO) { LockWall.load(ctx, id, w, h)?.asImageBitmap() }
    }
    return state.value
}

@Composable
fun rememberLockCutout(id: String, enabled: Boolean): ImageBitmap? {
    val ctx = LocalContext.current.applicationContext
    val dm = ctx.resources.displayMetrics
    val scale = minOf(1f, 1080f / dm.widthPixels.coerceAtLeast(1))
    val w = (dm.widthPixels * scale).toInt().coerceAtLeast(240)
    val h = (dm.heightPixels * scale).toInt().coerceAtLeast(400)
    val state = produceState<ImageBitmap?>(null, id, enabled) {
        value = if (!enabled) null else withContext(Dispatchers.IO) { LockWall.cutout(ctx, id, w, h)?.asImageBitmap() }
    }
    return state.value
}

@Composable
fun rememberWallThumb(id: String): ImageBitmap? {
    val ctx = LocalContext.current.applicationContext
    val state = produceState<ImageBitmap?>(null, id) {
        value = withContext(Dispatchers.IO) { LockWall.thumb(ctx, id)?.asImageBitmap() }
    }
    return state.value
}

/** Organic rounded blob the photo is cut into (the "shaped wallpaper" look). */
val BlobShape: Shape = GenericShape { size, _ ->
    val cx = size.width / 2f
    val cy = size.height / 2f
    val n = 180
    for (i in 0..n) {
        val t = 2.0 * Math.PI * i / n
        val r = 0.88 + 0.06 * cos(3 * t + 0.6) + 0.035 * sin(5 * t + 1.2) + 0.02 * cos(2 * t)
        val x = (cx + cx * r * cos(t)).toFloat()
        val y = (cy + cy * r * sin(t)).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}
