package com.youlauncher.app

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private const val PAGES = 4

/**
 * First launch only. Welcome screen with a big arrow, then a few quick choices (icon shape, theme),
 * then a short finish screen. Anything chosen here can be changed later in settings.
 */
@Composable
fun OnboardingFlow(vm: LauncherViewModel) {
    val s = vm.settings
    var page by remember { mutableIntStateOf(0) }
    val cs = MaterialTheme.colorScheme
    val last = page == PAGES - 1

    fun finish() = s.setOnboarded(true)
    fun next() {
        if (page < PAGES - 1) page++ else finish()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(cs.surface)
            .windowInsetsPadding(WindowInsets.systemBars)
            .padding(horizontal = 28.dp, vertical = 24.dp)
    ) {
        AnimatedContent(
            targetState = page,
            transitionSpec = {
                (slideInHorizontally(tween(340)) { it / 5 } + fadeIn(tween(280))) togetherWith
                    (slideOutHorizontally(tween(240)) { -it / 5 } + fadeOut(tween(160)))
            },
            label = "onboardingPage",
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 110.dp)
        ) { p ->
            when (p) {
                0 -> WelcomePage()
                1 -> ShapePage(s)
                2 -> ThemePage(s)
                else -> DonePage()
            }
        }

        // footer: page dots on the left, the arrow (or a button on the last page) on the right
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                repeat(PAGES) { i ->
                    val active = i == page
                    Box(
                        Modifier
                            .height(8.dp)
                            .width(if (active) 24.dp else 8.dp)
                            .clip(CircleShape)
                            .background(if (active) cs.primary else cs.outlineVariant)
                    )
                }
            }

            if (last) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(28.dp))
                        .background(cs.primary)
                        .clickable { finish() }
                        .padding(horizontal = 28.dp, vertical = 18.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        stringResource(R.string.ob_start),
                        color = cs.onPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            } else {
                // the big arrow: Pixel-like round button
                Box(
                    Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(cs.primary)
                        .clickable { next() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Rounded.ArrowForward,
                        contentDescription = stringResource(R.string.ob_next),
                        tint = cs.onPrimary,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun WelcomePage() {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
        Box(
            Modifier
                .size(96.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(cs.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "YL",
                color = cs.onPrimaryContainer,
                fontWeight = FontWeight.Black,
                style = MaterialTheme.typography.headlineMedium
            )
        }
        Spacer(Modifier.height(28.dp))
        Text(
            stringResource(R.string.ob_welcome_title),
            color = cs.onSurface,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.displaySmall
        )
        Spacer(Modifier.height(12.dp))
        Text(
            stringResource(R.string.ob_welcome_text),
            color = cs.onSurfaceVariant,
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

@Composable
private fun ShapePage(s: LauncherSettings) {
    val cs = MaterialTheme.colorScheme
    val selected by s.iconShape.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text(
            stringResource(R.string.ob_shape_title),
            color = cs.onSurface,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.headlineLarge
        )
        Spacer(Modifier.height(10.dp))
        Text(
            stringResource(R.string.ob_shape_text),
            color = cs.onSurfaceVariant,
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(Modifier.height(20.dp))
        IconShapeOption.values().forEach { option ->
            val on = option == selected
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(if (on) cs.primaryContainer else cs.surfaceContainerHigh)
                    .clickable { s.setIconShape(option) }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(option.toShape())
                        .background(cs.primary)
                )
                Spacer(Modifier.width(16.dp))
                Text(
                    stringResource(option.labelRes),
                    color = if (on) cs.onPrimaryContainer else cs.onSurface,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                    modifier = Modifier.weight(1f)
                )
                if (on) Icon(Icons.Rounded.Check, null, tint = cs.onPrimaryContainer)
            }
        }
    }
}

@Composable
private fun ThemePage(s: LauncherSettings) {
    val cs = MaterialTheme.colorScheme
    val selected by s.themeMode.collectAsStateWithLifecycle()
    val options = listOf(
        ThemeMode.SYSTEM to R.string.ob_theme_system,
        ThemeMode.LIGHT to R.string.ob_theme_light,
        ThemeMode.DARK to R.string.ob_theme_dark
    )
    Column(Modifier.fillMaxSize()) {
        Text(
            stringResource(R.string.ob_theme_title),
            color = cs.onSurface,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.headlineLarge
        )
        Spacer(Modifier.height(10.dp))
        Text(
            stringResource(R.string.ob_theme_text),
            color = cs.onSurfaceVariant,
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(Modifier.height(20.dp))
        options.forEach { (mode, label) ->
            val on = mode == selected
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(if (on) cs.primaryContainer else cs.surfaceContainerHigh)
                    .clickable { s.setThemeMode(mode) }
                    .padding(horizontal = 20.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    stringResource(label),
                    color = if (on) cs.onPrimaryContainer else cs.onSurface,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                    modifier = Modifier.weight(1f)
                )
                if (on) Icon(Icons.Rounded.Check, null, tint = cs.onPrimaryContainer)
            }
        }
    }
}

@Composable
private fun DonePage() {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
        Box(
            Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(cs.tertiaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Check, null, tint = cs.onTertiaryContainer, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(28.dp))
        Text(
            stringResource(R.string.ob_done_title),
            color = cs.onSurface,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Start,
            style = MaterialTheme.typography.displaySmall
        )
        Spacer(Modifier.height(12.dp))
        Text(
            stringResource(R.string.ob_done_text),
            color = cs.onSurfaceVariant,
            style = MaterialTheme.typography.bodyLarge
        )
    }
}
