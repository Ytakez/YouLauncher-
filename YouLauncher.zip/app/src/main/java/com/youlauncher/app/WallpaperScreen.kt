package com.youlauncher.app

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.graphics.ColorUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Gradient "mesh" wallpaper: base gradient + big soft radial blobs. Same seed => same picture at any size. */
class WpPreset(val nameRes: Int, val colors: IntArray, val seed: Int)

private fun c(v: Long): Int = v.toInt()

private val StaticPresets = listOf(
    WpPreset(R.string.wp_aurora, intArrayOf(c(0xFF0B1B2B), c(0xFF123B3A), c(0xFF2EE6A6), c(0xFF4D7CFF), c(0xFF9B5CFF)), 11),
    WpPreset(R.string.wp_dusk, intArrayOf(c(0xFF2B1B3D), c(0xFF5B2A4A), c(0xFFFF7A59), c(0xFFFFB86B), c(0xFFB05BFF)), 23),
    WpPreset(R.string.wp_ocean, intArrayOf(c(0xFF021B33), c(0xFF0B4F6C), c(0xFF18B8E8), c(0xFF2D6BFF), c(0xFF7FE7DC)), 37),
    WpPreset(R.string.wp_sunrise, intArrayOf(c(0xFFFFE3C2), c(0xFFFFC2A8), c(0xFFFF9A76), c(0xFFFFD36E), c(0xFFFF6F91)), 41),
    WpPreset(R.string.wp_mint, intArrayOf(c(0xFFE3F6EC), c(0xFFC8EBDA), c(0xFF7ED6A8), c(0xFFB4F0D0), c(0xFF6AC0D8)), 53),
    WpPreset(R.string.wp_lavender, intArrayOf(c(0xFFEDE7FF), c(0xFFD9CFFF), c(0xFFB39DFF), c(0xFFFFB3D9), c(0xFF9AD0FF)), 67),
    WpPreset(R.string.wp_berry, intArrayOf(c(0xFF3A0F2B), c(0xFF1E0A30), c(0xFFE0408F), c(0xFF8E44E8), c(0xFFFF7BAC)), 79),
    WpPreset(R.string.wp_mono, intArrayOf(c(0xFF101214), c(0xFF1E2226), c(0xFF3C4650), c(0xFF56626E), c(0xFF2A323A)), 97)
)

object WallpaperArt {
    fun render(w: Int, h: Int, p: WpPreset): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = LinearGradient(0f, 0f, w * 0.4f, h.toFloat(), p.colors[0], p.colors[1], Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        val rnd = java.util.Random(p.seed.toLong())
        for (i in 0 until 6) {
            val color = p.colors[2 + i % (p.colors.size - 2)]
            val cx = rnd.nextFloat() * w
            val cy = rnd.nextFloat() * h
            val r = w * (0.55f + rnd.nextFloat() * 0.6f)
            paint.shader = RadialGradient(
                cx, cy, r,
                ColorUtils.setAlphaComponent(color, 210),
                ColorUtils.setAlphaComponent(color, 0),
                Shader.TileMode.CLAMP
            )
            cv.drawCircle(cx, cy, r, paint)
        }
        return bmp
    }
}

/** target: 0 = home + lock, 1 = home, 2 = lock */
private suspend fun applyPreset(ctx: Context, p: WpPreset, target: Int): Boolean = withContext(Dispatchers.IO) {
    try {
        val dm = ctx.resources.displayMetrics
        val bmp = WallpaperArt.render(dm.widthPixels, dm.heightPixels, p)
        val flags = when (target) {
            1 -> WallpaperManager.FLAG_SYSTEM
            2 -> WallpaperManager.FLAG_LOCK
            else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
        }
        WallpaperManager.getInstance(ctx).setBitmap(bmp, null, true, flags)
        true
    } catch (_: Throwable) {
        false
    }
}

@Composable
fun WallpaperScreen(vm: LauncherViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val scheme = MaterialTheme.colorScheme
    val presets = remember(scheme) {
        StaticPresets + listOf(
            WpPreset(
                R.string.wp_you,
                intArrayOf(
                    scheme.surface.toArgb(), scheme.primaryContainer.toArgb(),
                    scheme.primary.toArgb(), scheme.tertiary.toArgb(), scheme.secondary.toArgb()
                ), 101
            ),
            WpPreset(
                R.string.wp_you_dark,
                intArrayOf(
                    scheme.inverseSurface.toArgb(), scheme.secondary.toArgb(),
                    scheme.tertiary.toArgb(), scheme.primary.toArgb(), scheme.inversePrimary.toArgb()
                ), 131
            )
        )
    }
    var target by remember { mutableIntStateOf(0) }
    val okMsg = stringResource(R.string.wp_done)
    val failMsg = stringResource(R.string.wp_fail)

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
            PageTopBar(stringResource(R.string.wallpaper), onBack = vm::closeOverlay)

            Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                Text(stringResource(R.string.wp_apply_to), style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(bottom = 8.dp))
                val opts = listOf(
                    stringResource(R.string.wp_both), stringResource(R.string.wp_home), stringResource(R.string.wp_lock)
                )
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    opts.forEachIndexed { i, label ->
                        SegmentedButton(
                            selected = target == i,
                            onClick = { target = i },
                            shape = SegmentedButtonDefaults.itemShape(index = i, count = opts.size),
                            label = { Text(label, maxLines = 1) }
                        )
                    }
                }
                TextButton(onClick = vm::openWallpaperPicker) { Text(stringResource(R.string.wp_gallery)) }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(presets, key = { it.nameRes }) { p ->
                    val preview: ImageBitmap? by produceState<ImageBitmap?>(null, p) {
                        value = withContext(Dispatchers.Default) { WallpaperArt.render(216, 400, p).asImageBitmap() }
                    }
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(0.54f)
                            .clip(RoundedCornerShape(28.dp))
                            .clickable {
                                scope.launch {
                                    val ok = applyPreset(ctx, p, target)
                                    Toast.makeText(ctx, if (ok) okMsg else failMsg, Toast.LENGTH_SHORT).show()
                                }
                            }
                    ) {
                        preview?.let {
                            Image(bitmap = it, contentDescription = null, contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize())
                        }
                        Text(
                            stringResource(p.nameRes),
                            color = Color.White,
                            style = MaterialTheme.typography.titleSmall.copy(
                                shadow = Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 2f), 8f)
                            ),
                            modifier = Modifier.align(Alignment.BottomStart).padding(16.dp)
                        )
                    }
                }
            }
        }
    }
}
