package com.youlauncher.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.max
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------------------------
// Gestures: one detector for the whole home area (long-press -> lift -> drag -> drop / menu)
// ---------------------------------------------------------------------------------------------

/**
 * Runs in the Initial pass so children (clickable icons, pager) still get normal taps and swipes.
 * After a long press it consumes everything, so the pager does not scroll while an icon is dragged.
 *  - [onLongPress] returns true when an item was lifted (then drag events follow), false otherwise.
 *  - [onEnd] gets `true` when the finger actually moved (drop), `false` for a plain long press (menu).
 */
suspend fun PointerInputScope.detectLauncherGestures(
    onLongPress: (Offset) -> Boolean,
    onDrag: (Offset) -> Unit,
    onEnd: (Boolean) -> Unit
) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        val timedOut = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
            var go = true
            while (go) {
                val ev = awaitPointerEvent(PointerEventPass.Initial)
                val c = ev.changes.firstOrNull { it.id == down.id }
                if (c == null || !c.pressed ||
                    (c.position - down.position).getDistance() > viewConfiguration.touchSlop
                ) go = false
            }
        } == null
        if (!timedOut) return@awaitEachGesture
        if (!onLongPress(down.position)) return@awaitEachGesture

        var last = down.position
        var moved = 0f
        while (true) {
            val ev = awaitPointerEvent(PointerEventPass.Initial)
            val c = ev.changes.firstOrNull { it.id == down.id }
            ev.changes.forEach { it.consume() }
            if (c == null || !c.pressed) {
                onEnd(moved > 16f)
                break
            }
            moved += (c.position - last).getDistance()
            last = c.position
            onDrag(c.position)
        }
    }
}

sealed interface DropTarget {
    /** App dropped on an app (-> new folder) or on a folder (-> added to it). */
    data class Merge(val target: HomeItem) : DropTarget

    /** Item placed on this cell (the ViewModel moves it to the nearest free one if it is taken). */
    data class Place(val col: Int, val row: Int, val span: Int) : DropTarget
}

fun computeDrop(
    dragged: HomeItem,
    items: List<HomeItem>,
    m: HomeMetrics,
    finger: Offset,
    grab: Offset,
    page: Int,
    visible: (HomeItem) -> Boolean
): DropTarget {
    if (!dragged.isFolder) {
        val over = items.firstOrNull { o ->
            o.id != dragged.id && o.page == page && o.col >= 0 && visible(o) && m.rect(o).contains(finger)
        }
        if (over != null) return DropTarget.Merge(over)
    }
    val s = dragged.spanFor(m.cols, m.rows)
    val tl = finger - grab
    val minRow = if (page == 0) m.blockedRows else 0
    val col = ((tl.x - m.padX) / m.cellW).roundToInt().coerceIn(0, max(0, m.cols - s))
    val row = ((tl.y - m.topPad) / m.cellH).roundToInt().coerceIn(minRow, max(minRow, m.rows - s))
    return DropTarget.Place(col, row, s)
}

// ---------------------------------------------------------------------------------------------
// Folder visuals
// ---------------------------------------------------------------------------------------------

@Composable
private fun IconImg(app: AppInfo, themed: Boolean, modifier: Modifier = Modifier) {
    val bmp = rememberAppIcon(app.key, themed, 56.dp)
    Box(modifier) {
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = null,
                modifier = Modifier.fillMaxSize().clip(LocalIconShape.current)
            )
        }
    }
}

@Composable
private fun MiniGrid(apps: List<AppInfo>, n: Int, themed: Boolean, gap: Dp) {
    Column(Modifier.fillMaxSize()) {
        repeat(n) { r ->
            Row(Modifier.weight(1f).fillMaxWidth()) {
                repeat(n) { c ->
                    Box(Modifier.weight(1f).fillMaxHeight().padding(gap)) {
                        val app = apps.getOrNull(r * n + c)
                        if (app != null) IconImg(app, themed, Modifier.fillMaxSize())
                    }
                }
            }
        }
    }
}

/**
 * Folder preview tile.
 *  - NORMAL: 3x3 grid of small icons.
 *  - LARGE / XXL: big icons; when there are more apps than slots the last slot becomes a 2x2 cluster of small ones.
 */
@Composable
fun FolderTile(side: Dp, size: FolderSize, apps: List<AppInfo>, themed: Boolean, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(side * 0.26f)
    Box(
        modifier
            .size(side)
            .clip(shape)
            .background(Color.White.copy(alpha = 0.22f))
            .padding(side * 0.07f)
    ) {
        if (size == FolderSize.NORMAL) {
            MiniGrid(apps.take(9), 3, themed, 1.5.dp)
        } else {
            val n = size.span
            val total = n * n
            val showMini = apps.size > total
            val bigCount = if (showMini) total - 1 else minOf(apps.size, total)
            val mini = apps.drop(bigCount).take(4)
            Column(Modifier.fillMaxSize()) {
                repeat(n) { r ->
                    Row(Modifier.weight(1f).fillMaxWidth()) {
                        repeat(n) { c ->
                            val idx = r * n + c
                            Box(Modifier.weight(1f).fillMaxHeight().padding(3.dp)) {
                                when {
                                    idx < bigCount -> IconImg(apps[idx], themed, Modifier.fillMaxSize())
                                    showMini && idx == total - 1 -> MiniGrid(mini, 2, themed, 1.dp)
                                    else -> Unit
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** A folder on the home grid: tile + name, fills the cells given by its size. Tap opens it. */
@Composable
fun FolderVisual(
    folder: HomeItem,
    apps: List<AppInfo>,
    span: Int,
    cellW: Dp,
    cellH: Dp,
    iconSize: Dp,
    showLabel: Boolean,
    themed: Boolean,
    onClick: () -> Unit
) {
    val labelH = if (showLabel) 22.dp else 0.dp
    val top = if (span == 1) 8.dp else 4.dp
    val side = if (span == 1) iconSize else minOf(cellW * span, cellH * span - labelH - top) - 8.dp
    val interaction = remember { MutableInteractionSource() }
    Column(
        Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(24.dp))
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(top))
        FolderTile(side, folder.size, apps, themed)
        if (showLabel) {
            Spacer(Modifier.height(4.dp))
            val base = MaterialTheme.typography.labelMedium
            Text(
                text = folder.name,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 4.dp),
                style = base.copy(shadow = Shadow(Color.Black.copy(alpha = 0.55f), Offset(0f, 2f), 6f))
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Opened folder
// ---------------------------------------------------------------------------------------------

@Composable
fun FolderPopup(
    folder: HomeItem,
    apps: List<AppInfo>,
    themed: Boolean,
    onRename: (String) -> Unit,
    onClose: () -> Unit,
    onLaunch: (String, Rect) -> Unit,
    menuFor: (AppInfo) -> List<MenuAction>
) {
    var name by remember(folder.id) { mutableStateOf(folder.name) }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.45f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() }
        )
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .pointerInput(Unit) { detectTapGestures { } },
            shape = RoundedCornerShape(32.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh
        ) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 16.dp)) {
                BasicTextField(
                    value = name,
                    onValueChange = { name = it; onRename(it) },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.titleLarge.copy(
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    ),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                )
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.heightIn(max = 380.dp)
                ) {
                    items(apps, key = { it.key }) { app ->
                        AppIcon(
                            app = app,
                            labelColor = MaterialTheme.colorScheme.onSurface,
                            iconSize = 52.dp,
                            themed = themed,
                            menu = { menuFor(app) },
                            onLaunch = { r -> onLaunch(app.key, r) }
                        )
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Folder editor: name, preview and size picker
// ---------------------------------------------------------------------------------------------

@Composable
private fun SizeGlyph(size: FolderSize) {
    val color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.30f)
    val n = if (size == FolderSize.NORMAL) 3 else size.span
    val mini = size != FolderSize.NORMAL
    Column(Modifier.fillMaxSize()) {
        repeat(n) { r ->
            Row(Modifier.weight(1f).fillMaxWidth()) {
                repeat(n) { c ->
                    Box(Modifier.weight(1f).fillMaxHeight().padding(if (size == FolderSize.NORMAL) 1.5.dp else 2.dp)) {
                        if (mini && r == n - 1 && c == n - 1) {
                            Column(Modifier.fillMaxSize()) {
                                repeat(2) {
                                    Row(Modifier.weight(1f).fillMaxWidth()) {
                                        repeat(2) {
                                            Box(
                                                Modifier
                                                    .weight(1f)
                                                    .fillMaxHeight()
                                                    .padding(1.dp)
                                                    .clip(RoundedCornerShape(3.dp))
                                                    .background(color)
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(if (size == FolderSize.NORMAL) 3.dp else 8.dp))
                                    .background(color)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SizeOption(size: FolderSize, selected: Boolean, label: String, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(22.dp)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Box(
            Modifier
                .size(84.dp)
                .clip(shape)
                .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                .then(if (selected) Modifier.border(2.5.dp, primary, shape) else Modifier)
                .padding(16.dp)
        ) { SizeGlyph(size) }
        Spacer(Modifier.height(8.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) primary else MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun FolderEditSheet(
    folder: HomeItem,
    apps: List<AppInfo>,
    themed: Boolean,
    onCancel: () -> Unit,
    onApply: (String, FolderSize) -> Unit
) {
    var name by remember(folder.id) { mutableStateOf(folder.name) }
    var size by remember(folder.id) { mutableStateOf(folder.size) }
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onCancel() }
        )
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .pointerInput(Unit) { detectTapGestures { } },
            shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
            color = MaterialTheme.colorScheme.surfaceContainer
        ) {
            Column(Modifier.navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp)) {
                Box(
                    Modifier
                        .align(Alignment.CenterHorizontally)
                        .size(width = 36.dp, height = 4.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f))
                )
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onCancel) {
                        Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.cancel))
                    }
                    BasicTextField(
                        value = name,
                        onValueChange = { name = it },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.titleLarge.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        ),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                    )
                    IconButton(onClick = { onApply(name, size) }) {
                        Icon(Icons.Rounded.Check, contentDescription = stringResource(R.string.apply))
                    }
                }
                Spacer(Modifier.height(16.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.tertiary
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    val side = when (size) {
                        FolderSize.NORMAL -> 96.dp
                        FolderSize.LARGE -> 150.dp
                        FolderSize.XXL -> 180.dp
                    }
                    FolderTile(side, size, apps, themed)
                }
                Spacer(Modifier.height(24.dp))
                Text(
                    stringResource(R.string.folder_size),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    SizeOption(FolderSize.NORMAL, size == FolderSize.NORMAL, stringResource(R.string.folder_size_normal)) { size = FolderSize.NORMAL }
                    SizeOption(FolderSize.LARGE, size == FolderSize.LARGE, stringResource(R.string.folder_size_large)) { size = FolderSize.LARGE }
                    SizeOption(FolderSize.XXL, size == FolderSize.XXL, stringResource(R.string.folder_size_xxl)) { size = FolderSize.XXL }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}
