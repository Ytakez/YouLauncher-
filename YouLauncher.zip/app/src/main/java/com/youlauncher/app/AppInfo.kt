package com.youlauncher.app

import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.os.Build
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlin.math.roundToInt

/** key = flattened ComponentName ("pkg/Activity"). */
data class AppInfo(val label: String, val key: String) {
    val packageName: String get() = key.substringBefore('/')
}

object IconCache {
    private val cache = LruCache<String, ImageBitmap>(400)

    fun cacheKey(key: String, themed: Boolean, bg: Int, fg: Int, px: Int) =
        "$key|${if (themed) "t" else "n"}|$bg|$fg|$px"

    fun get(ck: String): ImageBitmap? = cache.get(ck)

    /**
     * Renders the icon as an UNMASKED square (the launcher clips it to the shape the user picked).
     * Adaptive icons: background + foreground layers are drawn without the system mask, so any
     * shape (circle, squircle, flower...) works on every OEM, even if the phone only has squares.
     * Legacy (non-adaptive) icons are placed on a tonal tile like Pixel does.
     */
    fun load(pm: PackageManager, key: String, themed: Boolean, bg: Int, fg: Int, px: Int): ImageBitmap? {
        val ck = cacheKey(key, themed, bg, fg, px)
        cache.get(ck)?.let { return it }
        return try {
            val cn = ComponentName.unflattenFromString(key) ?: return null
            val d = pm.getActivityIcon(cn)
            val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            if (d is AdaptiveIconDrawable) {
                // adaptive layers are 108dp, only the central 72dp is visible -> bleed 25% on each side
                val pad = (px * 0.25f).roundToInt()
                val mono = if (themed && Build.VERSION.SDK_INT >= 33) d.monochrome else null
                if (mono != null) {
                    c.drawColor(bg)
                    val m = mono.mutate()
                    m.setTint(fg)
                    m.setBounds(-pad, -pad, px + pad, px + pad)
                    m.draw(c)
                } else {
                    d.background?.let { it.setBounds(-pad, -pad, px + pad, px + pad); it.draw(c) }
                    d.foreground?.let { it.setBounds(-pad, -pad, px + pad, px + pad); it.draw(c) }
                }
            } else {
                c.drawColor(bg)
                val inset = (px * 0.17f).roundToInt()
                d.setBounds(inset, inset, px - inset, px - inset)
                d.draw(c)
            }
            val img = bmp.asImageBitmap()
            cache.put(ck, img)
            img
        } catch (e: Exception) {
            null
        }
    }
}
