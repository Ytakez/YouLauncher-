package com.youlauncher.app

import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.AdaptiveIconDrawable
import android.os.Build
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.ColorUtils
import kotlin.math.roundToInt

/** key = flattened ComponentName ("pkg/Activity"). */
data class AppInfo(val label: String, val key: String) {
    val packageName: String get() = key.substringBefore('/')
}

/**
 * Material You color for ALL icons. [seed] is a single ARGB color (0 = off): the launcher builds
 * a tonal tile (container) and glyph color from it, like Android's themed icons, but for every app.
 * Compose state, so icons redraw as soon as it changes.
 */
object IconTheme {
    var seed by mutableStateOf(0)
}

object IconCache {
    private val cache = LruCache<String, ImageBitmap>(400)

    fun cacheKey(key: String, themed: Boolean, bg: Int, fg: Int, px: Int, seed: Int = 0, night: Boolean = false) =
        "$key|${if (themed) "t" else "n"}|$bg|$fg|$px|$seed|${if (night) 1 else 0}"

    fun get(ck: String): ImageBitmap? = cache.get(ck)

    /** Tile / glyph colors derived from the seed (HSL approximation of Material tonal palettes). */
    private fun tones(seed: Int, night: Boolean): Pair<Int, Int> {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(seed, hsl)
        val h = hsl[0]
        val s = hsl[1].coerceIn(0.3f, 0.75f).let { if (hsl[1] < 0.08f) hsl[1] else it }
        val container = ColorUtils.HSLToColor(floatArrayOf(h, s, if (night) 0.30f else 0.87f))
        val glyph = ColorUtils.HSLToColor(floatArrayOf(h, s, if (night) 0.88f else 0.25f))
        return container to glyph
    }

    /**
     * Renders the icon as an UNMASKED square (the launcher clips it to the shape the user picked).
     * With [seed] != 0 every icon is recolored: tonal tile + single-color glyph (Material You).
     */
    fun load(
        pm: PackageManager, key: String, themed: Boolean, bg: Int, fg: Int, px: Int,
        seed: Int = 0, night: Boolean = false
    ): ImageBitmap? {
        val ck = cacheKey(key, themed, bg, fg, px, seed, night)
        cache.get(ck)?.let { return it }
        return try {
            val cn = ComponentName.unflattenFromString(key) ?: return null
            val d = pm.getActivityIcon(cn)
            val (tile, glyph) = if (seed != 0) tones(seed, night) else (bg to fg)
            val recolor = seed != 0
            val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            var needDuotone = false
            if (d is AdaptiveIconDrawable) {
                // adaptive layers are 108dp, only the central 72dp is visible -> bleed 25% on each side
                val pad = (px * 0.25f).roundToInt()
                val mono = if ((themed || recolor) && Build.VERSION.SDK_INT >= 33) d.monochrome else null
                if (mono != null) {
                    c.drawColor(tile)
                    val m = mono.mutate()
                    m.setTint(glyph)
                    m.setBounds(-pad, -pad, px + pad, px + pad)
                    m.draw(c)
                } else if (recolor) {
                    // no monochrome layer: use the shape of the foreground as a mask and tint it
                    val layer = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
                    d.foreground?.let { it.setBounds(-pad, -pad, px + pad, px + pad); it.draw(Canvas(layer)) }
                    if (coverage(layer) > 0.85f) {
                        // opaque foreground (a full picture): fall back to a tonal duotone of the whole icon
                        d.background?.let { it.setBounds(-pad, -pad, px + pad, px + pad); it.draw(c) }
                        d.foreground?.let { it.setBounds(-pad, -pad, px + pad, px + pad); it.draw(c) }
                        needDuotone = true
                    } else {
                        c.drawColor(tile)
                        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            colorFilter = PorterDuffColorFilter(glyph, PorterDuff.Mode.SRC_IN)
                        }
                        c.drawBitmap(layer, 0f, 0f, p)
                    }
                } else {
                    d.background?.let { it.setBounds(-pad, -pad, px + pad, px + pad); it.draw(c) }
                    d.foreground?.let { it.setBounds(-pad, -pad, px + pad, px + pad); it.draw(c) }
                }
            } else {
                c.drawColor(if (recolor) tile else bg)
                val inset = (px * 0.17f).roundToInt()
                d.setBounds(inset, inset, px - inset, px - inset)
                d.draw(c)
                needDuotone = recolor
            }
            val out = if (needDuotone) duotone(bmp, glyph, tile) else bmp
            val img = out.asImageBitmap()
            cache.put(ck, img)
            img
        } catch (e: Exception) {
            null
        }
    }

    /** Share of mostly-opaque pixels (sampled). */
    private fun coverage(b: Bitmap): Float {
        var opaque = 0
        var total = 0
        val step = (b.width / 24).coerceAtLeast(1)
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                total++
                if ((b.getPixel(x, y) ushr 24) > 128) opaque++
                x += step
            }
            y += step
        }
        return if (total == 0) 0f else opaque.toFloat() / total
    }

    /** Maps brightness onto a gradient dark -> light. */
    private fun duotone(src: Bitmap, dark: Int, light: Int): Bitmap {
        fun ch(c: Int, shift: Int) = ((c shr shift) and 0xFF) / 255f
        val dr = ch(dark, 16); val dg = ch(dark, 8); val db = ch(dark, 0)
        val lr = ch(light, 16); val lg = ch(light, 8); val lb = ch(light, 0)
        val cr = 0.299f; val cg = 0.587f; val cb = 0.114f
        val m = ColorMatrix(floatArrayOf(
            (lr - dr) * cr, (lr - dr) * cg, (lr - dr) * cb, 0f, dr * 255f,
            (lg - dg) * cr, (lg - dg) * cg, (lg - dg) * cb, 0f, dg * 255f,
            (lb - db) * cr, (lb - db) * cg, (lb - db) * cb, 0f, db * 255f,
            0f, 0f, 0f, 1f, 0f
        ))
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { colorFilter = ColorMatrixColorFilter(m) }
        Canvas(out).drawBitmap(src, 0f, 0f, p)
        return out
    }
}
