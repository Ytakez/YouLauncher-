package com.youlauncher.app

import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlin.math.roundToInt

/** key = flattened ComponentName ("pkg/Activity"). */
data class AppInfo(val label: String, val key: String) {
    val packageName: String get() = key.substringBefore('/')
}

object IconCache {
    private val cache = LruCache<String, ImageBitmap>(400)

    fun cacheKey(key: String, recolor: Boolean, bg: Int, fg: Int, px: Int, dark: Boolean) =
        "$key|${if (recolor) "t" else "n"}|$bg|$fg|$px|${if (dark) "d" else "l"}"

    fun get(ck: String): ImageBitmap? = cache.get(ck)

    /** The icon exactly as the app drew it, as an UNMASKED square (the launcher clips it to the chosen shape). */
    private fun renderOriginal(d: Drawable, px: Int): Bitmap {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (d is AdaptiveIconDrawable) {
            // adaptive layers are 108dp, only the central 72dp is visible -> bleed 25% on each side
            val pad = (px * 0.25f).roundToInt()
            d.background?.let { it.setBounds(-pad, -pad, px + pad, px + pad); it.draw(c) }
            d.foreground?.let { it.setBounds(-pad, -pad, px + pad, px + pad); it.draw(c) }
        } else {
            d.setBounds(0, 0, px, px)
            d.draw(c)
            val e = (px * 0.10f).roundToInt()
            val a = intArrayOf(
                android.graphics.Color.alpha(bmp.getPixel(e, px / 2)),
                android.graphics.Color.alpha(bmp.getPixel(px - 1 - e, px / 2)),
                android.graphics.Color.alpha(bmp.getPixel(px / 2, e)),
                android.graphics.Color.alpha(bmp.getPixel(px / 2, px - 1 - e))
            )
            if (a.any { it < 200 }) {
                // glyph-only icon (transparent edges): neutral white tile, like Pixel, so it stays visible
                bmp.eraseColor(android.graphics.Color.TRANSPARENT)
                c.drawColor(android.graphics.Color.WHITE)
                val inset = (px * 0.17f).roundToInt()
                d.setBounds(inset, inset, px - inset, px - inset)
                d.draw(c)
            }
        }
        return bmp
    }

    /**
     * recolor = false: original icon.
     * recolor = true: apps with a monochrome layer (Android 13+) get a tile + tinted glyph,
     * all other apps are repainted two-tone, so EVERY icon matches the chosen palette.
     */
    fun load(pm: PackageManager, key: String, recolor: Boolean, bg: Int, fg: Int, px: Int, dark: Boolean): ImageBitmap? {
        val ck = cacheKey(key, recolor, bg, fg, px, dark)
        cache.get(ck)?.let { return it }
        return try {
            val cn = ComponentName.unflattenFromString(key) ?: return null
            val d = pm.getActivityIcon(cn)
            val mono = if (recolor && Build.VERSION.SDK_INT >= 33 && d is AdaptiveIconDrawable) d.monochrome else null
            val bmp: Bitmap = if (mono != null) {
                val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
                val c = Canvas(out)
                val pad = (px * 0.25f).roundToInt()
                c.drawColor(bg)
                val m = mono.mutate()
                m.setTint(fg)
                m.setBounds(-pad, -pad, px + pad, px + pad)
                m.draw(c)
                out
            } else {
                val orig = renderOriginal(d, px)
                if (recolor) duotone(orig, if (dark) bg else fg, if (dark) fg else bg) else orig
            }
            val img = bmp.asImageBitmap()
            cache.put(ck, img)
            img
        } catch (e: Exception) {
            null
        }
    }
}
