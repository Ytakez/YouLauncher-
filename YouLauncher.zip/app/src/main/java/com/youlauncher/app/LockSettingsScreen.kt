package com.youlauncher.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LockSettingsScreen(vm: LauncherViewModel) {
    val ctx = LocalContext.current
    val s = vm.settings
    val scope = rememberCoroutineScope()
    val cfg = rememberLockConfig(s)
    val enabled by s.lockEnabled.collectAsStateWithLifecycle()
    val aodOn by s.aodEnabled.collectAsStateWithLifecycle()
    val aodDur by s.aodDuration.collectAsStateWithLifecycle()
    val notifs by NotificationDots.items.collectAsStateWithLifecycle()

    var tab by remember { mutableIntStateOf(1) }      // 0 wallpaper, 1 time style, 2 colour
    var side by remember { mutableIntStateOf(0) }     // 0 left shortcut, 1 right shortcut
    var refresh by remember { mutableIntStateOf(0) }  // re-check permissions when coming back from system settings
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refresh++ }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { LockWall.import(ctx.applicationContext, uri) }
            if (ok) { s.setLockWall("gallery@" + System.currentTimeMillis()); s.setLockShape(true) }
        }
    }
    val askNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.systemBars)
                .verticalScroll(rememberScrollState())
        ) {
            PageTopBar(stringResource(R.string.lock_title), onBack = vm::closeOverlay)

            Group {
                SwitchRow(stringResource(R.string.lock_enable), stringResource(R.string.lock_enable_hint), enabled) {
                    s.setLockEnabled(it); LockService.sync(ctx, s); if (it) LockService.requestOverlayIfNeeded(ctx)
                }
            }

            Group {
                SwitchRow(stringResource(R.string.lock_swipe), stringResource(R.string.lock_swipe_hint), cfg.swipe, s::setLockSwipe)
            }

            // ---- live preview: lock screen on the left, always-on display on the right ----
            Row(
                Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally)
            ) {
                LockPreview(cfg, notifs, aod = 0f, width = 170.dp)
                LockPreview(cfg, notifs, aod = 1f, width = 120.dp)
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally)
            ) {
                Text(stringResource(R.string.lock_title_short), Modifier.width(170.dp), textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("AOD", Modifier.width(120.dp), textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(16.dp))

            Group {
                ChoiceRow(
                    title = null,
                    options = listOf(
                        0 to stringResource(R.string.lock_tab_wallpaper),
                        1 to stringResource(R.string.lock_tab_time),
                        2 to stringResource(R.string.lock_tab_color)
                    ),
                    selected = tab,
                    onSelect = { tab = it }
                )
                when (tab) {
                    0 -> {
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(width = 64.dp, height = 96.dp).clip(RoundedCornerShape(18.dp))
                                    .background(MaterialTheme.colorScheme.secondaryContainer)
                                    .clickable { pickPhoto.launch("image/*") },
                                contentAlignment = Alignment.Center
                            ) { Text("+", style = MaterialTheme.typography.headlineMedium) }
                            if (cfg.wall.startsWith("gallery")) {
                                WallTile(cfg.wall, true) { }
                            }
                            WallpaperSpec.all.forEach { spec ->
                                val sel = cfg.wall == spec.id || (cfg.wall.isEmpty() && spec === WallpaperSpec.all.first())
                                WallTile(spec.id, sel) { s.setLockWall(spec.id) }
                            }
                        }
                        SwitchRow(stringResource(R.string.lock_shape), stringResource(R.string.lock_shape_hint), cfg.shape, s::setLockShape)
                        SwitchRow(stringResource(R.string.lock_bubble), stringResource(R.string.lock_bubble_hint), cfg.bubble, s::setLockBubble)
                        SwitchRow(stringResource(R.string.lock_depth), stringResource(R.string.lock_depth_hint), cfg.depth, s::setLockDepth)
                    }

                    1 -> {
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            LockClockStyle.entries.forEach { st ->
                                StyleTile(st, st == cfg.clock) { s.setLockClock(st) }
                            }
                        }
                        Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                            Text(stringResource(R.string.lock_weight), style = MaterialTheme.typography.bodyLarge)
                            Slider(
                                value = cfg.weight.toFloat(),
                                onValueChange = { s.setLockWeight(it.roundToInt()) },
                                valueRange = 0f..4f,
                                steps = 3
                            )
                        }
                    }

                    else -> Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        LockColor.entries.forEach { c ->
                            val sel = c == cfg.color
                            Box(
                                Modifier.size(46.dp).clip(CircleShape).background(c.clock)
                                    .border(
                                        if (sel) 3.dp else 1.dp,
                                        if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                        CircleShape
                                    )
                                    .clickable { s.setLockColor(c) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (sel) Icon(Icons.Rounded.Check, null, tint = if (c == LockColor.BLACK) Color.White else Color(0xFF1B1F2A))
                            }
                        }
                    }
                }
            }

            // ---- shortcuts ----
            SectionTitle(stringResource(R.string.lock_shortcuts))
            Group {
                ChoiceRow(
                    title = null,
                    options = listOf(0 to stringResource(R.string.lock_left), 1 to stringResource(R.string.lock_right)),
                    selected = side,
                    onSelect = { side = it }
                )
                val current = if (side == 0) cfg.left else cfg.right
                FlowRow(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LockShortcut.entries.forEach { sc ->
                        val sel = sc == current
                        Column(
                            Modifier.width(78.dp).clip(RoundedCornerShape(16.dp))
                                .clickable { if (side == 0) s.setLockLeft(sc) else s.setLockRight(sc) }
                                .padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier.size(48.dp).clip(CircleShape)
                                    .background(
                                        if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                ShortcutGlyph(
                                    sc,
                                    if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSecondaryContainer,
                                    Modifier.size(24.dp)
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                stringResource(sc.labelRes), style = TextStyle(fontSize = 11.sp),
                                textAlign = TextAlign.Center, maxLines = 1
                            )
                        }
                    }
                }
            }

            // ---- notifications on the lock screen ----
            SectionTitle(stringResource(R.string.notifications))
            Group {
                SwitchRow(stringResource(R.string.lock_notif_show), null, cfg.notifOn, s::setLockNotifOn)
                ChoiceRow(
                    title = null,
                    options = listOf(
                        LockNotifLayout.MINIMAL to stringResource(R.string.lock_notif_minimal),
                        LockNotifLayout.COMPACT to stringResource(R.string.lock_notif_compact),
                        LockNotifLayout.FULL to stringResource(R.string.lock_notif_full)
                    ),
                    selected = cfg.notifLayout,
                    onSelect = s::setLockNotifLayout
                )
                SwitchRow(stringResource(R.string.lock_hide_text), stringResource(R.string.lock_hide_text_hint), cfg.hideText, s::setLockHideText)
            }

            // ---- always-on display ----
            SectionTitle(stringResource(R.string.aod_title))
            Group {
                SwitchRow(stringResource(R.string.aod_enable), stringResource(R.string.aod_enable_hint), aodOn) {
                    s.setAodEnabled(it); LockService.sync(ctx, s); if (it) LockService.requestOverlayIfNeeded(ctx)
                }
                ChoiceRow(
                    title = stringResource(R.string.aod_duration),
                    options = listOf(
                        AodDuration.S15 to stringResource(R.string.aod_15s),
                        AodDuration.S60 to stringResource(R.string.aod_1m),
                        AodDuration.M5 to stringResource(R.string.aod_5m),
                        AodDuration.FOREVER to stringResource(R.string.aod_forever)
                    ),
                    selected = aodDur,
                    onSelect = s::setAodDuration
                )
                SwitchRow(stringResource(R.string.aod_notif), null, cfg.aodNotif, s::setAodNotif)
                Text(
                    stringResource(R.string.aod_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 16.dp)
                )
            }

            // ---- permissions ----
            SectionTitle(stringResource(R.string.lock_permissions))
            Group {
                @Suppress("UNUSED_EXPRESSION") refresh
                val overlayOk = Settings.canDrawOverlays(ctx)
                val listenerOk = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
                val batteryOk = try {
                    ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
                } catch (_: Throwable) { false }
                val postOk = Build.VERSION.SDK_INT < 33 ||
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
                    android.content.pm.PackageManager.PERMISSION_GRANTED

                PermRow(stringResource(R.string.perm_overlay), stringResource(R.string.perm_overlay_hint), overlayOk) {
                    try {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Throwable) {}
                }
                PermRow(stringResource(R.string.perm_listener), stringResource(R.string.perm_listener_hint), listenerOk) {
                    vm.openNotificationAccess()
                }
                PermRow(stringResource(R.string.perm_battery), stringResource(R.string.perm_battery_hint), batteryOk) {
                    try {
                        ctx.startActivity(
                            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Throwable) {}
                }
                if (Build.VERSION.SDK_INT >= 33) {
                    PermRow(stringResource(R.string.perm_post), stringResource(R.string.perm_post_hint), postOk) {
                        askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }

            // ---- test ----
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(onClick = { LockActivity.show(ctx, LockMode.LOCK) }, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.lock_try), maxLines = 1)
                }
                OutlinedButton(onClick = { LockActivity.show(ctx, LockMode.AOD) }, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.aod_try), maxLines = 1)
                }
            }
            Text(
                stringResource(R.string.lock_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 28.dp, end = 28.dp, bottom = 32.dp)
            )
        }
    }
}

@Composable
private fun WallTile(id: String, selected: Boolean, onClick: () -> Unit) {
    val bmp = rememberWallThumb(id)
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier.size(width = 64.dp, height = 96.dp).clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(if (selected) 3.dp else 0.dp, MaterialTheme.colorScheme.primary, shape)
            .clickable(onClick = onClick)
    ) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

@Composable
private fun StyleTile(style: LockClockStyle, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    val ink = MaterialTheme.colorScheme.onSurface
    val sample = when (style) {
        LockClockStyle.STACKED -> "07\n38"
        LockClockStyle.NUMERALS -> "12\n9 3\n6"
        LockClockStyle.DIGITAL -> "07:38"
        LockClockStyle.OUTLINE -> "0738"
        LockClockStyle.VERTICAL -> "07 38\nSAT"
    }
    Box(
        Modifier.size(72.dp).clip(shape)
            .background(MaterialTheme.colorScheme.surfaceContainerHighest)
            .border(if (selected) 3.dp else 0.dp, MaterialTheme.colorScheme.primary, shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            sample, color = ink, textAlign = TextAlign.Center,
            style = TextStyle(
                fontSize = if (style == LockClockStyle.DIGITAL || style == LockClockStyle.OUTLINE) 15.sp else 17.sp,
                lineHeight = 16.sp,
                fontWeight = if (style == LockClockStyle.OUTLINE) FontWeight.Light else FontWeight.Black
            )
        )
    }
}

@Composable
private fun PermRow(title: String, hint: String, granted: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = !granted, onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (granted) {
            Icon(Icons.Rounded.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        } else {
            Text(stringResource(R.string.perm_grant), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
        }
    }
}
